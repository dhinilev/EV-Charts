/* EV Charts — screen logic. */
(function () {
  'use strict';

  const D = window.EVData;
  const $ = (id) => document.getElementById(id);

  const TF = {
    '1m': { minutes: 1, chartType: 'MINUTE', days: 4 },
    '3m': { minutes: 3, chartType: 'MINUTE', days: 7 },
    '5m': { minutes: 5, chartType: 'MINUTE', days: 12 },
    '15m': { minutes: 15, chartType: 'MINUTE', days: 25 },
    '30m': { minutes: 30, chartType: 'MINUTE', days: 30 },
    '1h': { minutes: 60, chartType: 'MINUTE', days: 30 },
    'D': { daily: true, chartType: 'DAY', days: 730 },
    'W': { daily: true, weekly: true, chartType: 'DAY', days: 1900 },
  };
  const REFRESH_MS = 20000;

  /* ---------- tiny storage helper (WebView storage can be unavailable) ---------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem('evc.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('evc.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
  };

  const S = {
    status: null,
    mode: store.get('mode', 'index'),
    tf: store.get('tf', '5m'),
    ind: Object.assign({ ema9: true, ema21: true, vwap: false, pdl: true, vol: true, bs: true, strip: true }, store.get('ind', {})),
    inst: { index: null, option: null, stock: null },
    indices: [],
    opt: { und: store.get('opt.und', 'NIFTY'), expiry: null, side: store.get('opt.side', 'CE'), chain: null, strikeIdx: -1, spot: null },
    recents: store.get('recents', []),
    raw: [],
    bars: [],
    flowMin: new Map(),   // minute -> [buyQty, sellQty] from the live feed
    flowKey: null,        // scripId whose trades are being split
    flowBars: [],
    book: null,           // pending buy / sell quantity in the order book
    futRaw: [],           // index future candles (for the OI strip on index charts)
    strip: null,
    feedStatus: '',
    reqSeq: 0,
    refreshTimer: null,
    loading: false,
    masterBusy: false,
  };

  /* ---------- chart ---------- */
  const chart = new window.EVChart($('chart'), { onCrosshair: showOhlc });
  setInterval(() => { // show the "Latest" button when scrolled into the past
    $('latestBtn').classList.toggle('show', chart.rightOffset < -3);
  }, 400);
  $('latestBtn').onclick = () => chart.goLatest();

  /* ---------- formatting ---------- */
  const fmt = (v, dec) => (v == null || !isFinite(v)) ? '—'
    : v.toLocaleString('en-IN', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  const decFor = (p) => (p < 1000 ? 2 : p < 10000 ? 2 : 1);
  const fmtVol = (v) => v >= 1e7 ? (v / 1e7).toFixed(2) + ' Cr' : v >= 1e5 ? (v / 1e5).toFixed(2) + ' L' : v >= 1e3 ? (v / 1e3).toFixed(1) + ' K' : String(v);

  let toastTimer = null;
  function toast(msg, ms = 2600) {
    const t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), ms);
  }

  function overlay(text, spin) {
    const o = $('overlay');
    if (!text) { o.classList.remove('show'); return; }
    $('overlayText').textContent = text;
    $('overlaySpin').style.display = spin ? '' : 'none';
    o.classList.add('show');
  }

  /* ---------- status / banner ---------- */
  async function refreshStatus() {
    try { S.status = await EV.call('status'); } catch (e) { S.status = null; }
    const st = S.status || {};
    const on = !!st.loggedIn;
    updateConn();
    $('stSession').textContent = !st.hasKeys ? 'API key not set' : on ? `Logged in (${st.loginDate || 'today'})` : 'Not logged in';
    const m = st.master || {};
    $('stMaster').textContent = m.ready ? `${(m.count || 0).toLocaleString('en-IN')} instruments · ${m.date}` : 'Not downloaded';
    if (st.apiKey && !$('apiKey').value) $('apiKey').value = st.apiKey;
    if (!$('redirectUrl').value) $('redirectUrl').value = st.redirectUrl || 'https://evcharts.app/callback';
    $('logoutBtn').disabled = !on;
    $('masterBtn').disabled = !on || S.masterBusy;
    updateBanner();
    return st;
  }

  function updateBanner() {
    const st = S.status || {};
    let text = '', btn = '', action = null;
    if (!st.hasKeys) { text = 'Add your HDFC Sky API key and secret to start.'; btn = 'Settings'; action = openSheet; }
    else if (!st.loggedIn) { text = 'Login to HDFC Sky to load charts. Sessions last one trading day.'; btn = 'Login'; action = doLogin; }
    else if (!(st.master || {}).ready) { text = S.masterBusy ? 'Downloading today\'s contract list…' : 'Download today\'s contract list (about 17 MB).'; btn = 'Download'; action = downloadMaster; }
    $('banner').classList.toggle('show', !!text);
    $('bannerText').textContent = text;
    $('bannerBtn').textContent = btn;
    $('bannerBtn').disabled = S.masterBusy;
    $('bannerBtn').onclick = action;
  }

  function ready() {
    const st = S.status || {};
    return st.loggedIn && (st.master || {}).ready;
  }

  /* ---------- login / master ---------- */
  async function doLogin() {
    try { await EV.call('login'); } catch (e) { toast(e.message); }
  }

  EV.on('login', async (res) => {
    if (res && res.ok) {
      toast('Logged in to HDFC Sky');
      const st = await refreshStatus();
      const today = D.ymd(D.istNow());
      if (!(st.master || {}).ready || st.master.date !== today) await downloadMaster();
      else await boot();
    } else {
      toast((res && res.error) || 'Login was not completed', 4000);
      refreshStatus();
    }
  });

  EV.on('master', (p) => {
    $('masterProg').classList.add('show');
    $('masterProg').firstElementChild.style.width = (p.pct || 0) + '%';
    if (p.stage) $('bannerText').textContent = p.stage;
  });

  async function downloadMaster() {
    if (S.masterBusy) return;
    S.masterBusy = true;
    updateBanner();
    overlay('Downloading contract list…', true);
    try {
      const r = await EV.call('downloadMaster');
      toast(`Contract list ready · ${(r.count || 0).toLocaleString('en-IN')} instruments`);
    } catch (e) {
      toast('Contract list failed: ' + e.message, 5000);
    } finally {
      S.masterBusy = false;
      $('masterProg').classList.remove('show');
      overlay('');
      await refreshStatus();
      if (ready()) boot();
    }
  }

  /* ---------- settings sheet ---------- */
  function openSheet() { refreshStatus(); $('sheet').classList.add('show'); $('sheetBg').classList.add('show'); }
  function closeSheet() { $('sheet').classList.remove('show'); $('sheetBg').classList.remove('show'); }
  $('settingsBtn').onclick = openSheet;
  $('sheetBg').onclick = closeSheet;
  $('loginBtn').onclick = () => { closeSheet(); doLogin(); };
  $('logoutBtn').onclick = async () => { await EV.call('logout'); stopRefresh(); toast('Logged out'); refreshStatus(); };
  $('masterBtn').onclick = () => { closeSheet(); downloadMaster(); };
  $('saveBtn').onclick = async () => {
    const apiKey = $('apiKey').value.trim();
    const apiSecret = $('apiSecret').value.trim();
    const redirectUrl = $('redirectUrl').value.trim();
    if (!apiKey || !redirectUrl) { toast('API key and redirect URL are required'); return; }
    if (!/^https?:\/\//i.test(redirectUrl)) { toast('Redirect URL must start with https://'); return; }
    try {
      await EV.call('saveSettings', { apiKey, apiSecret, redirectUrl });
      $('apiSecret').value = '';
      toast('Keys saved');
      const st = await refreshStatus();
      if (st.hasKeys && !st.loggedIn) { closeSheet(); doLogin(); }
    } catch (e) { toast(e.message, 4000); }
  };

  /* ---------- tabs ---------- */
  function setMode(mode, load = true) {
    S.mode = mode;
    store.set('mode', mode);
    document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
    $('pickIndex').hidden = mode !== 'index';
    $('pickOption').hidden = mode !== 'option';
    $('pickStock').hidden = mode !== 'stock';
    if (!load || !ready()) return;
    if (mode === 'index') setupIndex();
    if (mode === 'option') setupOptions();
    if (mode === 'stock') setupStocks();
  }
  document.querySelectorAll('#tabs button').forEach((b) => { b.onclick = () => setMode(b.dataset.mode); });

  /* ---------- index ---------- */
  async function setupIndex() {
    if (!S.indices.length) {
      try { S.indices = await EV.call('indices'); } catch (e) { toast(e.message); return; }
    }
    const chips = $('indexChips');
    chips.innerHTML = '';
    const saved = store.get('index.key', 'NIFTY');
    for (const ix of S.indices) {
      const b = document.createElement('button');
      b.className = 'chip';
      b.textContent = ix.label;
      b.dataset.key = ix.key;
      b.onclick = () => pickIndex(ix);
      chips.appendChild(b);
    }
    const ix = S.indices.find((i) => i.key === (S.inst.index && S.inst.index.key)) || S.indices.find((i) => i.key === saved) || S.indices[0];
    if (ix) pickIndex(ix);
  }

  function pickIndex(ix) {
    store.set('index.key', ix.key);
    document.querySelectorAll('#indexChips .chip').forEach((c) => c.classList.toggle('active', c.dataset.key === ix.key));
    const fut = ix.future || null;
    S.inst.index = {
      key: ix.key, title: ix.label, sub: `${ix.exchange} · Index` + (fut ? ` · flow from ${fut.symbol}` : ''),
      chartSymbols: ix.chartSymbols, exchange: ix.exchange, series: ix.series,
      ltpExchange: ix.ltpExchange, token: ix.token,
      flowKey: fut ? `${fut.exchange}_${fut.token}` : null, lot: fut ? (fut.lot || 1) : 1, unit: 'lots',
      oiSource: fut ? { chartSymbols: [fut.symbol], exchange: fut.exchange, series: fut.series } : null,
      stripKind: 'futures',
    };
    if (S.mode === 'index') loadChart();
  }

  /* ---------- options ---------- */
  let undList = null;
  async function setupOptions() {
    if (!undList) {
      try { undList = await EV.call('optionUnderlyings'); } catch (e) { toast(e.message); return; }
    }
    const chips = $('undChips');
    chips.innerHTML = '';
    for (const u of undList) {
      const b = document.createElement('button');
      b.className = 'chip'; b.textContent = u; b.dataset.u = u;
      b.onclick = () => pickUnderlying(u);
      chips.appendChild(b);
    }
    if (S.opt.chain && S.inst.option) { markUnd(); loadChart(); return; }
    pickUnderlying(undList.includes(S.opt.und) ? S.opt.und : undList[0]);
  }

  function markUnd() {
    document.querySelectorAll('#undChips .chip').forEach((c) => c.classList.toggle('active', c.dataset.u === S.opt.und));
  }

  async function pickUnderlying(u) {
    S.opt.und = u; store.set('opt.und', u); markUnd();
    const sel = $('expirySel');
    sel.innerHTML = '<option>Loading…</option>';
    let exps = [];
    try { exps = await EV.call('optionExpiries', { underlying: u }); } catch (e) { toast(e.message); return; }
    sel.innerHTML = '';
    const today = D.ymd(D.istNow());
    exps.forEach((x, i) => {
      const o = document.createElement('option');
      const d = new Date(x + 'T00:00:00Z');
      const label = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: '2-digit', timeZone: 'UTC' });
      o.value = x; o.textContent = label + (x === today ? '  · Expiry today' : i === 0 ? '  · Nearest' : '');
      sel.appendChild(o);
    });
    if (!exps.length) { sel.innerHTML = '<option>No expiries</option>'; return; }
    S.opt.expiry = exps[0];
    sel.value = exps[0];
    await loadChain(true);
  }

  $('expirySel').onchange = async (e) => { S.opt.expiry = e.target.value; await loadChain(false); };

  async function loadChain(goAtm) {
    const prevStrike = S.opt.chain && S.opt.strikeIdx >= 0 ? S.opt.chain.strikes[S.opt.strikeIdx].strike : null;
    try {
      S.opt.chain = await EV.call('optionChain', { underlying: S.opt.und, expiry: S.opt.expiry });
    } catch (e) { toast(e.message); return; }
    S.opt.spot = null;
    try {
      const sp = S.opt.chain.spot;
      if (sp) {
        const q = await EV.call('ltp', { items: [sp] });
        if (q && q[0] && q[0].ltp > 0) S.opt.spot = q[0].ltp;
      }
    } catch (e) { /* ATM falls back to the middle strike */ }
    const strikes = S.opt.chain.strikes;
    const atmIdx = atmIndex();
    let idx = atmIdx;
    if (!goAtm && prevStrike != null) {
      const k = strikes.findIndex((s) => s.strike === prevStrike);
      if (k >= 0) idx = k;
    }
    const sel = $('strikeSel');
    sel.innerHTML = '';
    strikes.forEach((s, i) => {
      const o = document.createElement('option');
      o.value = i;
      const tag = i === atmIdx ? '  · ATM' : '';
      o.textContent = fmt(s.strike, s.strike % 1 ? 1 : 0) + tag;
      sel.appendChild(o);
    });
    setStrike(idx);
  }

  function atmIndex() {
    const strikes = (S.opt.chain || {}).strikes || [];
    if (!strikes.length) return -1;
    if (!S.opt.spot) return Math.floor(strikes.length / 2);
    let best = 0;
    strikes.forEach((s, i) => { if (Math.abs(s.strike - S.opt.spot) < Math.abs(strikes[best].strike - S.opt.spot)) best = i; });
    return best;
  }

  function setStrike(idx) {
    const strikes = (S.opt.chain || {}).strikes || [];
    if (!strikes.length) return;
    idx = Math.max(0, Math.min(strikes.length - 1, idx));
    S.opt.strikeIdx = idx;
    $('strikeSel').value = String(idx);
    buildOptionInstrument();
  }

  function buildOptionInstrument() {
    const ch = S.opt.chain;
    const s = ch.strikes[S.opt.strikeIdx];
    const leg = S.opt.side === 'CE' ? s.ce : s.pe;
    if (!leg) { toast(`No ${S.opt.side} at this strike`); return; }
    const d = new Date(S.opt.expiry + 'T00:00:00Z');
    const exp = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', timeZone: 'UTC' });
    const spot = S.opt.spot ? ` · Spot ${fmt(S.opt.spot, 2)}` : '';
    S.inst.option = {
      title: `${S.opt.und} ${exp} ${fmt(s.strike, s.strike % 1 ? 1 : 0)} ${S.opt.side}`,
      sub: `${ch.exchange} · Lot ${ch.lot || '—'}${spot}`,
      chartSymbols: [leg.symbol], exchange: ch.exchange, series: ch.series,
      ltpExchange: ch.exchange, token: leg.token,
      flowKey: `${ch.exchange}_${leg.token}`, lot: ch.lot || 1, unit: 'lots', stripKind: 'option',
    };
    if (S.mode === 'option') loadChart();
  }

  $('strikeSel').onchange = (e) => setStrike(+e.target.value);
  $('strikeDown').onclick = () => setStrike(S.opt.strikeIdx - 1);
  $('strikeUp').onclick = () => setStrike(S.opt.strikeIdx + 1);
  $('atmBtn').onclick = () => setStrike(atmIndex());
  function setSide(side) {
    S.opt.side = side; store.set('opt.side', side);
    $('ceBtn').classList.toggle('active', side === 'CE');
    $('peBtn').classList.toggle('active', side === 'PE');
    if (S.opt.chain) buildOptionInstrument();
  }
  $('ceBtn').onclick = () => setSide('CE');
  $('peBtn').onclick = () => setSide('PE');
  setSide(S.opt.side);

  /* ---------- stocks ---------- */
  let searchTimer = null;
  function setupStocks() {
    renderRecents();
    if (S.inst.stock) loadChart();
    else if (S.recents.length) pickStock(S.recents[0]);
    else { clearChart('Search for a stock above'); setTimeout(() => $('stockInput').focus(), 50); }
  }

  $('stockInput').addEventListener('input', () => {
    clearTimeout(searchTimer);
    const q = $('stockInput').value.trim();
    if (q.length < 2) { $('stockResults').classList.remove('open'); return; }
    searchTimer = setTimeout(async () => {
      let list = [];
      try { list = await EV.call('searchStocks', { q }); } catch (e) { toast(e.message); return; }
      const box = $('stockResults');
      box.innerHTML = '';
      if (!list.length) box.innerHTML = '<button disabled><small>No match</small></button>';
      for (const it of list) {
        const b = document.createElement('button');
        b.innerHTML = `<b></b><small></small>`;
        b.firstChild.textContent = it.symbol;
        b.lastChild.textContent = it.name;
        b.onclick = () => { box.classList.remove('open'); $('stockInput').value = ''; $('stockInput').blur(); pickStock(it); };
        box.appendChild(b);
      }
      box.classList.add('open');
    }, 200);
  });
  document.addEventListener('pointerdown', (e) => {
    if (!e.target.closest('.search')) $('stockResults').classList.remove('open');
  });

  function renderRecents() {
    const box = $('recentChips');
    box.innerHTML = '';
    for (const it of S.recents) {
      const b = document.createElement('button');
      b.className = 'chip' + (S.inst.stock && S.inst.stock.key === it.symbol ? ' active' : '');
      b.textContent = it.symbol;
      b.onclick = () => pickStock(it);
      box.appendChild(b);
    }
  }

  function pickStock(it) {
    S.recents = [it].concat(S.recents.filter((r) => r.symbol !== it.symbol)).slice(0, 10);
    store.set('recents', S.recents);
    S.inst.stock = {
      key: it.symbol, title: it.symbol, sub: `${it.exchange} · ${it.name}`,
      chartSymbols: [it.symbol], exchange: it.exchange, series: it.series || 'EQ',
      ltpExchange: it.exchange, token: it.token,
      flowKey: `${it.exchange}_${it.token}`, lot: 1, unit: 'shares', stripKind: null,
    };
    renderRecents();
    if (S.mode === 'stock') loadChart();
  }

  /* ---------- timeframe + indicators ---------- */
  function markTf() {
    document.querySelectorAll('#tfBar button').forEach((b) => b.classList.toggle('active', b.dataset.tf === S.tf));
  }
  document.querySelectorAll('#tfBar button').forEach((b) => {
    b.onclick = () => { S.tf = b.dataset.tf; store.set('tf', S.tf); markTf(); loadChart(); };
  });
  markTf();

  function markInd() {
    document.querySelectorAll('#indBar button').forEach((b) => b.classList.toggle('active', !!S.ind[b.dataset.ind]));
  }
  document.querySelectorAll('#indBar button').forEach((b) => {
    b.onclick = () => {
      S.ind[b.dataset.ind] = !S.ind[b.dataset.ind]; store.set('ind', S.ind); markInd(); applyIndicators(); showOhlc(null);
      const inst = current();
      if (b.dataset.ind === 'strip' && S.ind.strip && inst && inst.oiSource && !S.futRaw.length) loadFutures(inst, S.reqSeq, false);
    };
  });
  markInd();

  function applyIndicators() {
    const bars = S.bars;
    const tf = TF[S.tf];
    const ov = [];
    const legend = [];
    const cs = getComputedStyle(document.documentElement);
    const col = (n) => cs.getPropertyValue(n).trim();
    if (S.ind.ema9) { ov.push({ values: D.ema(bars, 9), color: col('--ema1') }); legend.push(['EMA 9', col('--ema1')]); }
    if (S.ind.ema21) { ov.push({ values: D.ema(bars, 21), color: col('--ema2') }); legend.push(['EMA 21', col('--ema2')]); }
    const volOk = D.hasVolume(bars);
    if (S.ind.vwap && tf.minutes && volOk) { ov.push({ values: D.vwap(bars), color: col('--vwap'), breakDaily: true }); legend.push(['VWAP', col('--vwap')]); }
    chart.setOverlays(ov);

    const levels = [];
    if (S.ind.pdl && tf.minutes) {
      const pd = D.previousDayLevels(S.raw);
      if (pd) {
        levels.push({ value: pd.h, label: 'PDH', color: '#26a69a' });
        levels.push({ value: pd.l, label: 'PDL', color: '#ef5350' });
        levels.push({ value: pd.c, label: 'PDC', color: '#90a4ae' });
      }
    }
    chart.setLevels(levels);
    chart.setVolume(S.ind.vol && volOk);

    // buyers / sellers
    S.flowBars = D.flowPerBar(bars, S.flowMin, tf);
    chart.setFlow(S.flowBars, D.cumulativeDelta(bars, S.flowBars), S.ind.bs);

    // writers / buyers strip from OI
    S.strip = null;
    const inst = current();
    if (S.ind.strip && inst && inst.stripKind) {
      if (inst.oiSource) {
        if (S.futRaw.length) S.strip = D.oiBuildup(bars, D.resample(S.futRaw, tf));
      } else if (D.hasOi(bars)) {
        S.strip = D.oiBuildup(bars);
      }
    }
    chart.setStrip(S.strip);

    if (S.strip && S.strip.some(Boolean)) {
      const names = inst.stripKind === 'futures' ? STRIP_NAMES_FUT : STRIP_NAMES_OPT;
      for (const k of ['WA', 'WE', 'BA', 'BE']) legend.push([names[k], window.EVChart.STRIP_COLORS[k]]);
    }
    const lg = $('legend');
    lg.innerHTML = '';
    for (const [name, c] of legend) {
      const s = document.createElement('span');
      s.textContent = name; s.style.setProperty('--c', c);
      lg.appendChild(s);
    }
    if (S.ind.vwap && tf.minutes && !volOk) {
      const s = document.createElement('span'); s.textContent = 'VWAP needs volume (not for indices)'; s.style.setProperty('--c', 'transparent');
      lg.appendChild(s);
    }
  }

  const STRIP_NAMES_OPT = { WA: 'Writers +', WE: 'Writers −', BA: 'Buyers +', BE: 'Buyers −' };
  const STRIP_NAMES_FUT = { WA: 'Short build', WE: 'Short cover', BA: 'Long build', BE: 'Long unwind' };
  const STRIP_LONG_OPT = { WA: 'Writers adding', WE: 'Writers exiting', BA: 'Buyers adding', BE: 'Buyers exiting' };
  const STRIP_LONG_FUT = { WA: 'Short buildup', WE: 'Short covering', BA: 'Long buildup', BE: 'Long unwinding' };

  /* ---------- lots box (buyers / sellers of one candle) ---------- */
  function fmtQty(q, inst) {
    if (!inst || inst.unit !== 'lots') return fmtVol(Math.round(q));
    return Math.round(q / (inst.lot || 1)).toLocaleString('en-IN');
  }

  function showLots(idx) {
    const el = $('lotsBox');
    const inst = current();
    if (!inst || !S.bars.length) { el.innerHTML = ''; return; }
    const i = idx >= 0 ? idx : S.bars.length - 1;
    const parts = [];
    const f = S.flowBars[i];
    if (S.ind.bs && f && f.b + f.s > 0) {
      const d = f.b - f.s;
      const unit = inst.unit === 'lots' ? ' lots' : '';
      parts.push(`<span class="up">B ${fmtQty(f.b, inst)}</span> · <span class="down">S ${fmtQty(f.s, inst)}</span> · ` +
        `<b class="${d >= 0 ? 'up' : 'down'}">Δ ${d >= 0 ? '+' : '−'}${fmtQty(Math.abs(d), inst)}${unit}</b>`);
    } else if (S.ind.bs && inst.flowKey) {
      parts.push(`<span class="muted">B/S: ${S.flowMin.size ? 'no trades split in this candle' : 'collects live during market hours'}</span>`);
    }
    const k = S.strip && S.strip[i];
    if (k) {
      const names = inst.stripKind === 'futures' ? STRIP_LONG_FUT : STRIP_LONG_OPT;
      parts.push(`<span style="color:${window.EVChart.STRIP_COLORS[k.kind]}">${names[k.kind]} · OI ${k.dOi > 0 ? '+' : '−'}${fmtQty(Math.abs(k.dOi), inst)}${inst.unit === 'lots' ? ' lots' : ''}</span>`);
    }
    el.innerHTML = parts.join('<i class="dot"></i>');
    // order book pressure (live only)
    const bk = $('bookBar');
    if (S.book && S.book.buy + S.book.sell > 0 && S.ind.bs) {
      const pb = Math.round((S.book.buy / (S.book.buy + S.book.sell)) * 100);
      bk.classList.add('show');
      bk.querySelector('.bb').style.width = pb + '%';
      bk.querySelector('.bl').textContent = `Bids ${pb}%`;
      bk.querySelector('.sl').textContent = `${100 - pb}% Asks`;
    } else bk.classList.remove('show');
  }

  /* ---------- crosshair OHLC ---------- */
  function showOhlc(bar, i) {
    const el = $('ohlc');
    const b = bar || S.bars[S.bars.length - 1];
    if (!b) { el.innerHTML = ''; return; }
    const idx = bar ? i : S.bars.length - 1;
    const prev = S.bars[idx - 1];
    const dec = decFor(b.c);
    const chg = prev ? b.c - prev.c : b.c - b.o;
    const pct = prev ? (chg / prev.c) * 100 : (chg / b.o) * 100;
    const cls = chg >= 0 ? 'up' : 'down';
    let html = `O <b>${fmt(b.o, dec)}</b>H <b>${fmt(b.h, dec)}</b>L <b>${fmt(b.l, dec)}</b>C <b class="${cls}">${fmt(b.c, dec)}</b>` +
      `<span class="${cls}">${chg >= 0 ? '+' : ''}${fmt(chg, dec)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)</span>`;
    if (b.v > 0) html += ` &nbsp;V <b>${fmtVol(b.v)}</b>`;
    if (b.oi > 0) html += `OI <b>${fmtVol(b.oi)}</b>`;
    el.innerHTML = html;
    showLots(idx);
  }

  /* ---------- loading ---------- */
  function current() { return S.inst[S.mode]; }

  function clearChart(msg) {
    S.raw = []; S.bars = [];
    chart.emptyText = msg || 'No candles yet';
    chart.setData([], { intraday: true });
    $('qName').textContent = '—'; $('qSub').textContent = msg || ''; $('qLtp').textContent = '—'; $('qChg').textContent = '';
    $('ohlc').innerHTML = '';
  }

  function rangeFor(tf, short) {
    const now = D.istNow();
    const days = short ? (tf.daily ? 10 : 1) : tf.days;
    return { start: D.ymd(now - (days - 1) * 86400), end: D.ymd(now) };
  }

  async function fetchCandles(inst, tf, short) {
    const { start, end } = rangeFor(tf, short);
    const r = await EV.call('candles', {
      chartSymbols: inst.chartSymbols, exchange: inst.exchange, seriesType: inst.series,
      chartType: tf.chartType, start, end,
    });
    if (r && r.symbol && inst.chartSymbols[0] !== r.symbol) {
      // Remember which chart symbol worked so refreshes don't probe again.
      inst.chartSymbols = [r.symbol].concat(inst.chartSymbols.filter((s) => s !== r.symbol));
    }
    return D.parseRows((r && r.rows) || []);
  }

  function rebuild(keepView) {
    const tf = TF[S.tf];
    S.bars = D.resample(S.raw, tf);
    chart.opts.weekly = !!tf.weekly;
    chart.emptyText = 'No candles for this range';
    chart.setData(S.bars, { keepView, intraday: !!tf.minutes });
    applyIndicators();
    showOhlc(null);
  }

  async function loadChart() {
    const inst = current();
    if (!inst) return;
    if (!ready()) { updateBanner(); return; }
    const seq = ++S.reqSeq;
    const tf = TF[S.tf];
    $('qName').textContent = inst.title;
    $('qSub').textContent = inst.sub;
    $('qLtp').textContent = '—'; $('qChg').textContent = '';
    S.raw = []; S.bars = []; S.futRaw = []; S.book = null;
    if (S.flowKey !== inst.flowKey) { S.flowMin = new Map(); S.flowKey = inst.flowKey || null; }
    chart.setData([], { intraday: !!tf.minutes });
    overlay('Loading candles…', true);
    stopRefresh();
    try {
      const rows = await fetchCandles(inst, tf, false);
      if (seq !== S.reqSeq) return;
      S.raw = rows;
      rebuild(false);
      overlay(rows.length ? '' : 'No candles returned for this instrument and range.', false);
      startFlow(inst, seq);
      loadFutures(inst, seq, false);
    } catch (e) {
      if (seq !== S.reqSeq) return;
      handleError(e);
      return;
    }
    updateQuote(inst, seq);
    startRefresh();
  }

  async function updateQuote(inst, seq) {
    let ltp = null, prev = null;
    try {
      const q = await EV.call('ltp', { items: [{ exchange: inst.ltpExchange, token: inst.token, symbol: inst.chartSymbols[0] }] });
      if (q && q[0] && q[0].ltp > 0) { ltp = q[0].ltp; prev = q[0].prev_close || null; }
    } catch (e) { /* fall back to the last candle */ }
    if (seq !== S.reqSeq) return;
    const last = S.bars[S.bars.length - 1];
    if (ltp == null && last) ltp = last.c;
    if (ltp == null) return;
    const dec = decFor(ltp);
    $('qLtp').textContent = fmt(ltp, dec);
    if (prev) {
      const chg = ltp - prev, pct = (chg / prev) * 100;
      $('qChg').textContent = `${chg >= 0 ? '+' : ''}${fmt(chg, dec)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)`;
      $('qChg').className = 'q-chg ' + (chg >= 0 ? 'up' : 'down');
      $('qLtp').className = 'q-ltp ' + (chg >= 0 ? 'up' : 'down');
    } else {
      $('qChg').textContent = ''; $('qLtp').className = 'q-ltp';
    }
  }

  function handleError(e) {
    const msg = e.message || String(e);
    if (/AUTH|401|403|token|session/i.test(msg)) {
      overlay('Session expired. Please login to HDFC Sky again.', false);
      refreshStatus();
    } else if (/429|rate/i.test(msg)) {
      overlay('HDFC Sky is rate-limiting requests. Try again in a few seconds.', false);
    } else {
      overlay(msg, false);
    }
  }

  /* ---------- buyers / sellers feed ---------- */
  async function startFlow(inst, seq) {
    if (!inst.flowKey) return;
    try {
      const r = await EV.call('flowWatch', { keys: [inst.flowKey] });
      if (seq !== S.reqSeq || S.flowKey !== inst.flowKey) return;
      const rows = ((r && r.history) || {})[inst.flowKey] || [];
      for (const [t, b, sQty] of rows) S.flowMin.set(t, [b, sQty]);
      if (rows.length) rebuild(true);
    } catch (e) {
      if (/AUTH/.test(e.message || '')) handleError(e);
    }
  }

  let flowRedraw = 0;
  EV.on('flow', (p) => {
    if (!p || p.key !== S.flowKey) return;
    for (const [t, b, sQty] of p.rows || []) S.flowMin.set(t, [b, sQty]);
    S.book = { buy: p.bookBuy || 0, sell: p.bookSell || 0 };
    const now = Date.now();
    if (now - flowRedraw > 900 && S.bars.length) { flowRedraw = now; rebuild(true); }
  });

  EV.on('feed', (p) => {
    S.feedStatus = p.status;
    updateConn();
    if (p.status === 'error') toast('Live feed: ' + (p.detail || 'error'), 4000);
  });

  function updateConn() {
    const st = S.status || {};
    const on = !!st.loggedIn;
    const map = { connected: 'Live feed', connecting: 'Connecting…', disconnected: 'Feed offline', error: 'Feed error' };
    $('connText').textContent = st.demo ? 'Demo data' : !on ? 'Offline' : (map[S.feedStatus] || 'HDFC Sky');
    $('conn').classList.toggle('on', on && (st.demo || S.feedStatus === 'connected' || !S.feedStatus));
  }

  async function loadFutures(inst, seq, short) {
    if (!inst.oiSource || !S.ind.strip) return;
    try {
      const rows = await fetchCandles(inst.oiSource, TF[S.tf], short);
      if (seq !== S.reqSeq) return;
      S.futRaw = short ? D.mergeRaw(S.futRaw, rows) : rows;
      rebuild(true);
    } catch (e) { /* strip simply stays off */ }
  }

  /* ---------- live refresh ---------- */
  function stopRefresh() { clearInterval(S.refreshTimer); S.refreshTimer = null; $('refreshNote').textContent = ''; }

  function startRefresh() {
    stopRefresh();
    if (!D.isMarketOpen()) { $('refreshNote').textContent = 'Market closed'; return; }
    $('refreshNote').textContent = 'Live · 20s';
    S.refreshTimer = setInterval(tick, REFRESH_MS);
  }

  async function tick() {
    if (document.hidden || S.loading) return;
    if (!D.isMarketOpen()) { startRefresh(); return; }
    const inst = current();
    if (!inst) return;
    const seq = S.reqSeq;
    S.loading = true;
    try {
      const fresh = await fetchCandles(inst, TF[S.tf], true);
      if (seq !== S.reqSeq) return;
      S.raw = D.mergeRaw(S.raw, fresh);
      rebuild(true);
      updateQuote(inst, seq);
      loadFutures(inst, seq, true);
    } catch (e) {
      if (/AUTH|401|403|token|session/i.test(e.message || '')) { stopRefresh(); handleError(e); }
    } finally {
      S.loading = false;
    }
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden && S.refreshTimer) tick(); });

  /* ---------- boot ---------- */
  let booted = false;
  async function boot() {
    if (!ready()) { clearChart(''); return; }
    booted = true;
    overlay('');
    setMode(S.mode);
  }

  // Called by Android when the app returns to the foreground.
  EV.on('resume', async () => {
    const st = await refreshStatus();
    if (st.loggedIn && !booted) boot();
  });

  (async function init() {
    const st = await refreshStatus();
    setMode(S.mode, false);
    if (st.loggedIn && st.master && st.master.ready && st.master.date !== D.ymd(D.istNow())) {
      downloadMaster(); // daily refresh keeps new expiries and strikes available
    } else {
      boot();
    }
  })();
})();
