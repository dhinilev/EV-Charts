package com.evgroup.evcharts

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var store: SecureStore
    private lateinit var master: ContractMaster
    private lateinit var feed: MarketFeed
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0F14")
        window.navigationBarColor = Color.parseColor("#121821")

        store = SecureStore(this)
        master = ContractMaster(filesDir)
        feed = MarketFeed(filesDir) { name, payload -> emit(name, payload) }

        web = WebView(this)
        web.setBackgroundColor(Color.parseColor("#0B0F14"))
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            textZoom = 100
        }
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "EVNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/www/index.html")
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) emit("resume", JSONObject())
    }

    override fun onDestroy() {
        feed.shutdown()
        pool.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    /* ---------------- JS <-> Kotlin ---------------- */

    private fun resolve(id: String, ok: Boolean, payload: String) {
        main.post {
            web.evaluateJavascript("window.EVResolve(${JSONObject.quote(id)}, $ok, ${JSONObject.quote(payload)})", null)
        }
    }

    private fun emit(name: String, payload: JSONObject) {
        main.post {
            web.evaluateJavascript("window.EVEvent && window.EVEvent(${JSONObject.quote(name)}, ${JSONObject.quote(payload.toString())})", null)
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun call(id: String, method: String, argsJson: String) {
            pool.execute {
                try {
                    val args = if (argsJson.isBlank()) JSONObject() else JSONObject(argsJson)
                    val result: Any = handle(method, args)
                    resolve(id, true, result.toString())
                } catch (e: Exception) {
                    resolve(id, false, JSONObject().put("error", e.message ?: e.javaClass.simpleName).toString())
                }
            }
        }
    }

    private fun apiKey() = store.get(K_API_KEY) ?: ""
    private fun redirectUrl() = store.get(K_REDIRECT) ?: DEFAULT_REDIRECT

    /** Session token is only trusted for the IST day it was issued on. */
    private fun sessionToken(): String? {
        val t = store.get(K_TOKEN) ?: return null
        return if (store.get(K_TOKEN_DATE) == ContractMaster.todayIst()) t else null
    }

    private fun api(): HdfcSky {
        val token = sessionToken() ?: throw HdfcSky.ApiException("AUTH Not logged in")
        return HdfcSky(apiKey(), token)
    }

    /** Clears the stored session when HDFC Sky rejects it, so the UI asks to log in again. */
    private fun <T> authed(block: () -> T): T = try {
        block()
    } catch (e: HdfcSky.ApiException) {
        if (e.message?.startsWith("AUTH") == true) store.put(K_TOKEN, null)
        throw e
    }

    private fun handle(method: String, a: JSONObject): Any = when (method) {
        "status" -> {
            val m = master.meta()
            JSONObject()
                .put("hasKeys", apiKey().isNotBlank() && !store.get(K_SECRET).isNullOrBlank())
                .put("loggedIn", sessionToken() != null)
                .put("loginDate", store.get(K_TOKEN_DATE) ?: "")
                .put("apiKey", apiKey())
                .put("redirectUrl", redirectUrl())
                .put("master", JSONObject()
                    .put("ready", master.isReady())
                    .put("date", m?.optString("date") ?: "")
                    .put("count", m?.optInt("count") ?: 0))
        }
        "saveSettings" -> {
            store.put(K_API_KEY, a.optString("apiKey").trim())
            val secret = a.optString("apiSecret").trim()
            if (secret.isNotEmpty()) store.put(K_SECRET, secret)
            store.put(K_REDIRECT, a.optString("redirectUrl").trim().ifEmpty { DEFAULT_REDIRECT })
            store.put(K_TOKEN, null)
            JSONObject().put("ok", true)
        }
        "login" -> {
            if (apiKey().isBlank()) throw Exception("Save your API key first")
            main.post {
                val i = Intent(this, LoginActivity::class.java)
                    .putExtra(LoginActivity.EXTRA_LOGIN_URL, HdfcSky.loginUrl(apiKey()))
                    .putExtra(LoginActivity.EXTRA_REDIRECT, redirectUrl())
                @Suppress("DEPRECATION")
                startActivityForResult(i, REQ_LOGIN)
            }
            JSONObject().put("started", true)
        }
        "logout" -> {
            feed.stop()
            store.put(K_TOKEN, null); store.put(K_TOKEN_DATE, null)
            JSONObject().put("ok", true)
        }
        "downloadMaster" -> {
            val count = master.download { pct -> emit("master", JSONObject().put("pct", pct)) }
            JSONObject().put("count", count)
        }
        "indices" -> master.indexList()
        "optionUnderlyings" -> master.underlyings()
        "optionExpiries" -> master.expiries(a.getString("underlying"))
        "optionChain" -> master.chain(a.getString("underlying"), a.getString("expiry"))
        "searchStocks" -> master.searchStocks(a.optString("q"))
        "candles" -> authed {
            val syms = a.getJSONArray("chartSymbols")
            api().candles(
                (0 until syms.length()).map { syms.getString(it) },
                a.getString("exchange"), a.getString("seriesType"),
                a.getString("chartType"), a.getString("start"), a.getString("end")
            )
        }
        "ltp" -> authed { api().ltp(a.getJSONArray("items")) }
        "flowWatch" -> {
            val token = sessionToken() ?: throw HdfcSky.ApiException("AUTH Not logged in")
            val keys = a.getJSONArray("keys")
            feed.watch((0 until keys.length()).map { keys.getString(it) }, token, apiKey())
        }
        else -> throw Exception("Unknown method $method")
    }

    /* ---------------- login result ---------------- */

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        @Suppress("DEPRECATION")
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_LOGIN) return
        val reqToken = data?.getStringExtra(LoginActivity.EXTRA_TOKEN)
        if (reqToken == null) {
            val err = data?.getStringExtra(LoginActivity.EXTRA_ERROR) ?: "Login was cancelled"
            emit("login", JSONObject().put("ok", false).put("error", err))
            return
        }
        pool.execute {
            try {
                val secret = store.get(K_SECRET) ?: throw Exception("API secret missing — save it in Settings")
                val token = HdfcSky(apiKey(), null).exchangeToken(reqToken, secret)
                feed.stop() // reconnect the live feed with the new session
                store.put(K_TOKEN, token)
                store.put(K_TOKEN_DATE, ContractMaster.todayIst())
                emit("login", JSONObject().put("ok", true))
            } catch (e: Exception) {
                emit("login", JSONObject().put("ok", false).put("error", e.message ?: "Login failed"))
            }
        }
    }

    companion object {
        private const val REQ_LOGIN = 41
        private const val K_API_KEY = "api_key"
        private const val K_SECRET = "api_secret"
        private const val K_REDIRECT = "redirect_url"
        private const val K_TOKEN = "access_token"
        private const val K_TOKEN_DATE = "access_token_date"
        const val DEFAULT_REDIRECT = "https://evcharts.app/callback"
    }
}
