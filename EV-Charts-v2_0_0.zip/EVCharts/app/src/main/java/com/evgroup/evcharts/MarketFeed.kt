package com.evgroup.evcharts

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.TreeMap
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

/**
 * Live HDFC Sky tick feed + buyer/seller split.
 *
 * Every trade (detected as a rise in the day's traded volume) is classified as
 * buyer-initiated or seller-initiated:
 *   - traded at or above the previous best ask  -> buyer was in a hurry  -> BUY
 *   - traded at or below the previous best bid  -> seller was in a hurry -> SELL
 *   - otherwise the tick rule: price up = BUY, price down = SELL, unchanged = same as last trade
 * The traded quantity is added to that side's total for the IST minute. Minutes
 * are saved per day, so reopening the app keeps what was collected earlier.
 */
class MarketFeed(private val baseDir: File, private val emit: (String, JSONObject) -> Unit) {

    private class FlowState(val key: String) {
        var lastVol = -1L
        var lastLtp = 0.0
        var bid = 0.0
        var ask = 0.0
        var lastSide = 0
        var bookBuy = 0L
        var bookSell = 0L
        var oi = 0L
        var ltp = 0.0
        var dirty = false
        val minutes = TreeMap<Long, LongArray>() // IST minute (wall clock as UTC secs) -> [buyQty, sellQty]
        // Writers / buyers from OI: minute -> [writersAdding, writersExiting, buyersAdding, buyersExiting] (qty)
        val oiMinutes = TreeMap<Long, LongArray>()
        var baseMinute = 0L
        var baseOi = 0L
        var baseLtp = 0.0
    }

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .connectTimeout(20, TimeUnit.SECONDS)
        .build()
    private val sched = Executors.newSingleThreadScheduledExecutor()
    private val states = ConcurrentHashMap<String, FlowState>()
    private val subscribed = LinkedHashMap<String, Long>() // scripId -> last used (LRU)
    @Volatile private var active: List<String> = emptyList()
    @Volatile private var ws: WebSocket? = null
    @Volatile private var connected = false
    @Volatile private var wanted = false
    @Volatile private var accessToken: String? = null
    @Volatile private var apiKey: String? = null
    @Volatile private var lastFrameAt = 0L
    private var backoffSec = 5L
    private var reconnectTask: ScheduledFuture<*>? = null
    private var day = ContractMaster.todayIst()

    init {
        sched.scheduleWithFixedDelay(Runnable { safe { pushActive() } }, 1, 1, TimeUnit.SECONDS)
        sched.scheduleWithFixedDelay(Runnable { safe { heartbeat() } }, 10, 10, TimeUnit.SECONDS)
        sched.scheduleWithFixedDelay(Runnable { safe { persist() } }, 15, 15, TimeUnit.SECONDS)
    }

    private inline fun safe(block: () -> Unit) {
        try { block() } catch (e: Exception) { /* keep the scheduler alive */ }
    }

    /* ---------------- public API ---------------- */

    /**
     * Start watching these scripIds (e.g. "NFO_43650", "NSE_2885").
     * Returns the minutes already collected today for each of them.
     */
    @Synchronized
    fun watch(keys: List<String>, token: String, key: String): JSONObject {
        active = keys
        ensure(keys, token, key)
        val res = JSONObject()
        for (k in keys) res.put(k, rowsOf(states[k], Long.MIN_VALUE))
        return JSONObject().put("history", res).put("connected", connected)
    }

    /** Keep these option strikes subscribed (for walls / magnets) without making them the chart. */
    @Synchronized
    fun watchChain(keys: List<String>, token: String, key: String): JSONObject {
        ensure(keys, token, key)
        return JSONObject().put("ok", true).put("connected", connected)
    }

    /**
     * Per strike: live OI / LTP plus writers / buyers OI totals for today and for the
     * last 15 minutes: [writersAdding, writersExiting, buyersAdding, buyersExiting].
     */
    fun chainStats(keys: List<String>): JSONObject {
        val out = JSONObject()
        val now = System.currentTimeMillis() / 1000 + IST_OFFSET
        val recentFrom = now - now % 60 - 15 * 60
        for (k in keys) {
            val st = states[k] ?: continue
            synchronized(st) {
                val tot = LongArray(4)
                val rec = LongArray(4)
                for ((m, v) in st.oiMinutes) {
                    for (i in 0 until 4) {
                        tot[i] += v[i]
                        if (m >= recentFrom) rec[i] += v[i]
                    }
                }
                out.put(k, JSONObject().put("oi", st.oi).put("ltp", st.ltp)
                    .put("tot", JSONArray(tot.toList())).put("recent", JSONArray(rec.toList())))
            }
        }
        return JSONObject().put("stats", out).put("connected", connected)
    }

    private fun ensure(keys: List<String>, token: String, key: String) {
        rollDayIfNeeded()
        accessToken = token
        apiKey = key
        wanted = true
        val now = System.currentTimeMillis()
        val fresh = ArrayList<String>()
        for (k in keys) {
            if (!subscribed.containsKey(k)) fresh.add(k)
            subscribed[k] = now
            states.getOrPut(k) { loadState(k) }
        }
        // Keep at most MAX_SUBS instruments subscribed; drop the least recently used.
        val keep = keys.toSet() + active
        while (subscribed.size > MAX_SUBS) {
            val oldest = subscribed.entries.filter { it.key !in keep }.minByOrNull { it.value }?.key ?: break
            subscribed.remove(oldest)
            sendSubscription(emptyList(), listOf(oldest))
            persistOne(states[oldest])
            states.remove(oldest)
        }
        if (ws == null) connect() else if (connected && fresh.isNotEmpty()) sendSubscription(fresh, emptyList())
    }

    @Synchronized
    fun stop() {
        wanted = false
        reconnectTask?.cancel(false)
        ws?.close(1000, "bye")
        ws = null
        connected = false
        persist()
    }

    fun shutdown() {
        stop()
        sched.shutdownNow()
        client.dispatcher.executorService.shutdown()
    }

    /* ---------------- connection ---------------- */

    private fun connect() {
        val token = accessToken ?: return
        val key = apiKey ?: return
        val url = HdfcSky.ROOT.replace("https://", "wss://") + "/wsapi/v1/session?token=" +
            URLEncoder.encode(token, "UTF-8") + "&api_key=" + URLEncoder.encode(key, "UTF-8")
        val req = Request.Builder().url(url).header("User-Agent", HdfcSky.USER_AGENT).build()
        status("connecting")
        ws = client.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                synchronized(this@MarketFeed) {
                    if (webSocket !== ws) return
                    connected = true
                    backoffSec = 5
                    lastFrameAt = System.currentTimeMillis()
                    sendSubscription(subscribed.keys.toList(), emptyList())
                }
                status("connected")
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                lastFrameAt = System.currentTimeMillis()
                for (t in FeedProto.decodeFrame(bytes.toByteArray())) onTick(t)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                lastFrameAt = System.currentTimeMillis()
                val low = text.lowercase()
                if (low.contains("unauthor") || low.contains("invalid token") || low.contains("expired") ||
                    (low.contains("\"status\"") && low.contains("error"))
                ) status("error", text.take(160))
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val code = response?.code ?: 0
                dropped(webSocket, if (code == 401 || code == 403) "AUTH HTTP $code" else (t.message ?: "connection failed"))
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                dropped(webSocket, "closed $code")
            }
        })
    }

    private fun dropped(socket: WebSocket, why: String) {
        synchronized(this) {
            if (socket !== ws) return
            ws = null
            connected = false
        }
        status("disconnected", why)
        if (!wanted || why.startsWith("AUTH")) return
        val delay = backoffSec
        backoffSec = (backoffSec * 2).coerceAtMost(60)
        reconnectTask = sched.schedule(Runnable { synchronized(this) { if (wanted && ws == null) connect() } }, delay, TimeUnit.SECONDS)
    }

    private fun sendSubscription(sub: List<String>, unsub: List<String>) {
        val socket = ws ?: return
        if (!connected) return
        // At most 100 scrips per frame.
        sub.chunked(100).forEach { batch ->
            val arr = JSONArray()
            batch.forEach { arr.put(JSONObject().put("scripId", it).put("type", "ALL")) }
            socket.send(JSONObject().put("heart_beat", false).put("subscribe", arr).toString())
        }
        if (unsub.isNotEmpty()) {
            val arr = JSONArray()
            unsub.forEach { arr.put(JSONObject().put("scripId", it).put("type", "ALL")) }
            socket.send(JSONObject().put("heart_beat", false).put("unSubscribe", arr).toString())
        }
    }

    private fun heartbeat() {
        val socket = ws ?: return
        if (!connected) return
        socket.send("{\"heart_beat\":true}")
        // Force a reconnect if the market is open but nothing arrived for 90 s.
        if (marketHours() && System.currentTimeMillis() - lastFrameAt > 90_000) socket.cancel()
    }

    private fun status(s: String, detail: String = "") {
        emit("feed", JSONObject().put("status", s).put("detail", detail))
    }

    /* ---------------- tick -> buyers / sellers ---------------- */

    private fun onTick(t: FeedTick) {
        val prefix = FeedProto.prefixFor(t.packetType) ?: return
        val st = states["${prefix}_${t.token}"] ?: return
        synchronized(st) {
            if (t.isIndex) { if (t.ltp > 0) st.ltp = t.ltp; return }
            if (t.oi > 0) st.oi = t.oi
            if (t.totalBuyQty > 0 || t.totalSellQty > 0) { st.bookBuy = t.totalBuyQty; st.bookSell = t.totalSellQty }

            if (t.volume > 0) {
                if (st.lastVol < 0 || t.volume < st.lastVol) {
                    st.lastVol = t.volume // first packet (or a reset): baseline only
                } else if (t.volume > st.lastVol && t.ltp > 0) {
                    val qty = t.volume - st.lastVol
                    val side = when {
                        st.ask > 0 && t.ltp >= st.ask -> 1
                        st.bid > 0 && t.ltp <= st.bid -> -1
                        st.lastLtp > 0 && t.ltp > st.lastLtp -> 1
                        st.lastLtp > 0 && t.ltp < st.lastLtp -> -1
                        else -> st.lastSide
                    }
                    if (side != 0) {
                        val minute = minuteOf(t.timestampMs)
                        val cell = st.minutes.getOrPut(minute) { LongArray(2) }
                        if (side > 0) cell[0] += qty else cell[1] += qty
                        st.lastSide = side
                        st.dirty = true
                    }
                    st.lastVol = t.volume
                }
            }
            if (t.ltp > 0) { st.lastLtp = t.ltp; st.ltp = t.ltp }
            trackOi(st, minuteOf(t.timestampMs))
            // Quote is updated AFTER classifying, so each trade is judged against the book it hit.
            if (t.bestBid > 0) st.bid = t.bestBid
            if (t.bestAsk > 0) st.ask = t.bestAsk
        }
    }

    /**
     * Once per minute, compare OI and price with the previous minute:
     *   OI up + price down = writers adding,   OI down + price up   = writers exiting,
     *   OI up + price up   = buyers adding,    OI down + price down = buyers exiting.
     */
    private fun trackOi(st: FlowState, minute: Long) {
        if (st.oi <= 0 || st.ltp <= 0) return
        if (st.baseMinute == 0L) { st.baseMinute = minute; st.baseOi = st.oi; st.baseLtp = st.ltp; return }
        if (minute == st.baseMinute) return
        val dOi = st.oi - st.baseOi
        val dP = st.ltp - st.baseLtp
        if (dOi != 0L && dP != 0.0) {
            val idx = if (dOi > 0) (if (dP < 0) 0 else 2) else (if (dP > 0) 1 else 3)
            st.oiMinutes.getOrPut(st.baseMinute) { LongArray(4) }[idx] += kotlin.math.abs(dOi)
            st.dirty = true
        }
        st.baseMinute = minute
        st.baseOi = st.oi
        st.baseLtp = st.ltp
    }

    private fun minuteOf(tsMs: Long): Long {
        val now = System.currentTimeMillis()
        val ms = if (tsMs > 0 && kotlin.math.abs(tsMs - now) < 6 * 3600_000L) tsMs else now
        val ist = ms / 1000 + IST_OFFSET
        return ist - ist % 60
    }

    private fun marketHours(): Boolean {
        val ist = System.currentTimeMillis() / 1000 + IST_OFFSET
        val dow = ((ist / 86400) + 4) % 7
        val sec = ist % 86400
        return dow in 1L..5L && sec in (9L * 3600 + 14 * 60)..(15L * 3600 + 31 * 60)
    }

    /* ---------------- push to the chart ---------------- */

    private fun rowsOf(st: FlowState?, fromMinute: Long): JSONArray {
        val arr = JSONArray()
        if (st == null) return arr
        synchronized(st) {
            for ((m, v) in st.minutes.tailMap(fromMinute)) arr.put(JSONArray().put(m).put(v[0]).put(v[1]))
        }
        return arr
    }

    private fun pushActive() {
        rollDayIfNeeded()
        val keys = active
        if (keys.isEmpty() || !wanted) return
        val now = System.currentTimeMillis() / 1000 + IST_OFFSET
        val from = now - now % 60 - 120 // last ~3 minutes
        for (k in keys) {
            val st = states[k] ?: continue
            val payload = JSONObject().put("key", k).put("rows", rowsOf(st, from)).put("connected", connected)
            synchronized(st) {
                payload.put("bookBuy", st.bookBuy).put("bookSell", st.bookSell).put("ltp", st.ltp).put("oi", st.oi)
            }
            emit("flow", payload)
        }
    }

    /* ---------------- persistence (one small JSON file per instrument per day) ---------------- */

    private fun dayDir(): File = File(baseDir, "flow/$day").apply { mkdirs() }

    private fun loadState(key: String): FlowState {
        val st = FlowState(key)
        val f = File(dayDir(), "$key.json")
        if (f.exists()) {
            try {
                val json = JSONObject(f.readText())
                val rows = json.getJSONArray("rows")
                for (i in 0 until rows.length()) {
                    val r = rows.getJSONArray(i)
                    st.minutes[r.getLong(0)] = longArrayOf(r.getLong(1), r.getLong(2))
                }
                val oiRows = json.optJSONArray("oiRows") ?: JSONArray()
                for (i in 0 until oiRows.length()) {
                    val r = oiRows.getJSONArray(i)
                    st.oiMinutes[r.getLong(0)] = longArrayOf(r.getLong(1), r.getLong(2), r.getLong(3), r.getLong(4))
                }
            } catch (e: Exception) { /* start fresh */ }
        }
        return st
    }

    private fun persistOne(st: FlowState?) {
        if (st == null) return
        val text: String
        synchronized(st) {
            if (!st.dirty) return
            st.dirty = false
            val oiRows = JSONArray()
            for ((m, v) in st.oiMinutes) oiRows.put(JSONArray().put(m).put(v[0]).put(v[1]).put(v[2]).put(v[3]))
            text = JSONObject().put("rows", rowsOf(st, Long.MIN_VALUE)).put("oiRows", oiRows).toString()
        }
        try { File(dayDir(), "${st.key}.json").writeText(text) } catch (e: Exception) { st.dirty = true }
    }

    private fun persist() {
        for (st in states.values) persistOne(st)
    }

    @Synchronized
    private fun rollDayIfNeeded() {
        val today = ContractMaster.todayIst()
        if (today == day) return
        persist()
        day = today
        states.clear()
        // Old days are kept for 5 days, then removed.
        File(baseDir, "flow").listFiles()?.sortedBy { it.name }?.dropLast(5)?.forEach { it.deleteRecursively() }
        for (k in subscribed.keys) states[k] = FlowState(k)
    }

    companion object {
        private const val IST_OFFSET = 19800L
        private const val MAX_SUBS = 150 // HDFC Sky allows 300 per connection
    }
}
