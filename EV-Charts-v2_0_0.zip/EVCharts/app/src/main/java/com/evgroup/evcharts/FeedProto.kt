package com.evgroup.evcharts

/**
 * One decoded market-data packet from HDFC Sky's live feed.
 * Prices are rupees (doubles on the wire). 0 means "not present in this packet".
 */
class FeedTick(
    val token: Long,
    val packetType: Int,
    val timestampMs: Long,
    val ltp: Double,
    val volume: Long,
    val ltq: Long,
    val oi: Long,
    val totalBuyQty: Long,
    val totalSellQty: Long,
    val bestBid: Double,
    val bestAsk: Double,
    val isIndex: Boolean,
)

/**
 * Minimal protobuf decoder for HDFC Sky's feed frames (no protobuf library needed).
 * Only the fields EV Charts uses are read; everything else is skipped by wire type.
 *
 *   GenericDTOList { repeated GenericDTO genericDTOList = 1; }
 *   GenericDTO     { int64 instrumentId = 1; MBPData mbpData = 2; IndexData indexData = 3;
 *                    int64 packetTimestamp = 8; PacketType packetType = 9; }
 *   MBPData        { double lastTradedPrice = 1; int64 volumeTradedToday = 9; int64 lastTradeQuantity = 10;
 *                    MarketDepthDTOList marketDepthDTOList = 12; int64 totalBuyQuantity = 13;
 *                    int64 totalSellQuantity = 14; int64 oi = 17; }
 *   MarketDepthDTO { int64 quantity = 1; double price = 2; int64 numberOfOrders = 3; bool buyFlag = 4; }
 *   IndexData      { double indexValue = 2; }
 */
object FeedProto {

    const val HEARTBEAT = 16

    /** Packet type -> scripId prefix used when subscribing ("NFO_43650"). */
    fun prefixFor(packetType: Int): String? = when (packetType) {
        0, 10 -> "NSE"                 // NSE_CM_ALL, NSE_CM_CIRC
        2 -> "NSE_INDEX"
        3, 13, 14, 17 -> "NFO"         // NSE_FO_ALL, NSE_FO_CIRC, NSE_FO_OI, NSE_FO_GREEK
        4 -> "BSE"                     // BSE_CM
        5 -> "BSE_INDEX"
        6, 15, 18 -> "BFO"             // BSE_FO_ALL, BSE_FO_OI, BSE_FO_GREEK
        else -> null
    }

    private class Reader(val buf: ByteArray, var pos: Int, val end: Int) {
        fun eof() = pos >= end

        fun varint(): Long {
            var result = 0L
            var shift = 0
            while (true) {
                if (pos >= end) throw IllegalArgumentException("truncated varint")
                val b = buf[pos++].toInt() and 0xff
                result = result or ((b and 0x7f).toLong() shl shift)
                if (b and 0x80 == 0) return result
                shift += 7
                if (shift > 63) throw IllegalArgumentException("varint too long")
            }
        }

        private fun need(n: Int) {
            if (pos + n > end) throw IllegalArgumentException("truncated")
        }

        fun double(): Double {
            need(8)
            var bits = 0L
            for (i in 0 until 8) bits = bits or ((buf[pos + i].toLong() and 0xff) shl (8 * i))
            pos += 8
            return java.lang.Double.longBitsToDouble(bits)
        }

        fun sub(): Reader {
            val len = varint()
            if (len < 0 || pos + len > end) throw IllegalArgumentException("bad length")
            val r = Reader(buf, pos, pos + len.toInt())
            pos += len.toInt()
            return r
        }

        fun skip(wire: Int) {
            when (wire) {
                0 -> varint()
                1 -> { need(8); pos += 8 }
                2 -> sub()
                5 -> { need(4); pos += 4 }
                else -> throw IllegalArgumentException("wire type $wire")
            }
        }
    }

    /** Decodes one binary frame: normally a GenericDTOList, sometimes a bare GenericDTO. */
    fun decodeFrame(data: ByteArray): List<FeedTick> {
        val out = ArrayList<FeedTick>()
        try {
            val r = Reader(data, 0, data.size)
            while (!r.eof()) {
                val tag = r.varint()
                val field = (tag ushr 3).toInt()
                val wire = (tag and 7).toInt()
                if (field == 1 && wire == 2) decodeDto(r.sub())?.let { out.add(it) }
                else if (field == 1 && wire == 0) return single(data) // bare GenericDTO
                else r.skip(wire)
            }
        } catch (e: Exception) {
            return single(data)
        }
        return if (out.isEmpty()) single(data) else out
    }

    private fun single(data: ByteArray): List<FeedTick> = try {
        listOfNotNull(decodeDto(Reader(data, 0, data.size)))
    } catch (e: Exception) {
        emptyList()
    }

    private fun decodeDto(r: Reader): FeedTick? {
        var token = 0L
        var packetType = 0 // proto3 omits default values; 0 = NSE_CM_ALL (NSE cash)
        var ts = 0L
        var mbp: Reader? = null
        var index: Reader? = null
        while (!r.eof()) {
            val tag = r.varint()
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7).toInt()
            when {
                field == 1 && wire == 0 -> token = r.varint()
                field == 2 && wire == 2 -> mbp = r.sub()
                field == 3 && wire == 2 -> index = r.sub()
                field == 8 && wire == 0 -> ts = r.varint()
                field == 9 && wire == 0 -> packetType = r.varint().toInt()
                else -> r.skip(wire)
            }
        }
        if (packetType == HEARTBEAT || token == 0L) return null

        if (index != null && (packetType == 2 || packetType == 5 || mbp == null)) {
            var value = 0.0
            val ir = index
            while (!ir.eof()) {
                val tag = ir.varint()
                val field = (tag ushr 3).toInt()
                val wire = (tag and 7).toInt()
                if (field == 2 && wire == 1) value = ir.double() else ir.skip(wire)
            }
            return FeedTick(token, packetType, ts, value, 0, 0, 0, 0, 0, 0.0, 0.0, true)
        }
        val m = mbp ?: return null

        var ltp = 0.0; var vol = 0L; var ltq = 0L; var oi = 0L; var tbq = 0L; var tsq = 0L
        var bid = 0.0; var ask = 0.0
        while (!m.eof()) {
            val tag = m.varint()
            val field = (tag ushr 3).toInt()
            val wire = (tag and 7).toInt()
            when {
                field == 1 && wire == 1 -> ltp = m.double()
                field == 9 && wire == 0 -> vol = m.varint()
                field == 10 && wire == 0 -> ltq = m.varint()
                field == 13 && wire == 0 -> tbq = m.varint()
                field == 14 && wire == 0 -> tsq = m.varint()
                field == 17 && wire == 0 -> oi = m.varint()
                field == 12 && wire == 2 -> {
                    val list = m.sub()
                    while (!list.eof()) {
                        val lt = list.varint()
                        if ((lt ushr 3).toInt() == 1 && (lt and 7).toInt() == 2) {
                            val lvl = list.sub()
                            var price = 0.0; var buy = false
                            while (!lvl.eof()) {
                                val t2 = lvl.varint()
                                val f2 = (t2 ushr 3).toInt()
                                val w2 = (t2 and 7).toInt()
                                when {
                                    f2 == 2 && w2 == 1 -> price = lvl.double()
                                    f2 == 4 && w2 == 0 -> buy = lvl.varint() != 0L
                                    else -> lvl.skip(w2)
                                }
                            }
                            if (price > 0) {
                                if (buy) { if (price > bid) bid = price }
                                else if (ask == 0.0 || price < ask) ask = price
                            }
                        } else list.skip((lt and 7).toInt())
                    }
                }
                else -> m.skip(wire)
            }
        }
        return FeedTick(token, packetType, ts, ltp, vol, ltq, oi, tbq, tsq, bid, ask, false)
    }
}
