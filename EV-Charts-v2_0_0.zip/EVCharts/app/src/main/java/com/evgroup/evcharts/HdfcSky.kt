package com.evgroup.evcharts

import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * HDFC Sky Open API client (market data only — no order endpoints).
 *
 * Facts used here, as implemented by the open-source OpenAlgo HDFC Sky plugin:
 *  - Host: https://developer.hdfcsky.com
 *  - Login page:  GET  /oapi/v1/login?api_key=KEY  (redirects to your redirect URL with a request token)
 *  - Token:       POST /oapi/v1/access-token?api_key=KEY&request_token=T  body {"apiSecret": SECRET}
 *  - Candles:     GET  /oapi/charts-api/charts/v1/fetch-candle
 *                 ?api_key&symbol&exchange&chartType(MINUTE|DAY)&seriesType&start&end (yyyy-MM-dd)
 *                 -> data.results = [[o,h,l,c,vol,oi,"DD-MM-YYYY HH:MM",cumVol], ...]
 *                 MINUTE ranges are capped at 31 days, DAY at 2000 days.
 *  - LTP:         PUT  /oapi/v1/fetch-ltp?api_key  body {"data":[{"exchange","token"}]}
 *  - Every call needs a User-Agent header; Authorization is the raw token (no "Bearer").
 */
class HdfcSky(private val apiKey: String, private val token: String?) {

    class ApiException(message: String) : Exception(message)

    private fun qs(params: Map<String, String>): String =
        params.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }

    private data class Resp(val code: Int, val body: String)

    private fun request(method: String, path: String, params: Map<String, String>, body: String? = null, auth: Boolean = true): Resp {
        val url = URL("$ROOT$path?${qs(params)}")
        val conn = url.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("User-Agent", USER_AGENT)
            conn.setRequestProperty("Accept", "application/json")
            if (auth && !token.isNullOrEmpty()) conn.setRequestProperty("Authorization", token)
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream: InputStream? = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
            return Resp(code, text)
        } finally {
            conn.disconnect()
        }
    }

    /** Pull a readable message out of an HDFC Sky error body. Never echoes the URL (it holds the API key). */
    private fun errorText(r: Resp): String {
        val json = try { JSONObject(r.body) } catch (e: Exception) { null }
        val msg = json?.optJSONObject("meta")?.optString("displayMessage")?.takeIf { it.isNotBlank() }
            ?: json?.optString("message")?.takeIf { it.isNotBlank() }
            ?: json?.optString("error")?.takeIf { it.isNotBlank() }
            ?: r.body.take(160)
        val prefix = if (r.code == 401 || r.code == 403) "AUTH " else ""
        return "${prefix}HTTP ${r.code}: $msg"
    }

    fun exchangeToken(requestToken: String, apiSecret: String): String {
        val body = JSONObject().put("apiSecret", apiSecret).toString()
        val r = request(
            "POST", "/oapi/v1/access-token",
            mapOf("api_key" to apiKey, "request_token" to requestToken), body, auth = false
        )
        if (r.code !in 200..299) throw ApiException("Login failed — ${errorText(r)}")
        val json = JSONObject(r.body)
        val t = json.optString("accessToken").ifBlank { json.optString("access_token") }.ifBlank {
            json.optJSONObject("data")?.let { d -> d.optString("accessToken").ifBlank { d.optString("access_token") } } ?: ""
        }
        if (t.isBlank()) throw ApiException("Login failed — no access token in the response")
        return t
    }

    /**
     * Candles for the first chart symbol that returns data (index symbols have
     * two spellings on HDFC Sky's chart service, e.g. "NIFTY" vs "NIFTY 50").
     */
    fun candles(
        chartSymbols: List<String>, exchange: String, seriesType: String,
        chartType: String, start: String, end: String
    ): JSONObject {
        var lastError: String? = null
        for (sym in chartSymbols) {
            val params = mapOf(
                "api_key" to apiKey, "symbol" to sym, "exchange" to exchange,
                "chartType" to chartType, "seriesType" to seriesType, "start" to start, "end" to end
            )
            var r = request("GET", "/oapi/charts-api/charts/v1/fetch-candle", params)
            var attempt = 0
            while (r.code == 429 && attempt < 3) {
                Thread.sleep(800L shl attempt)
                attempt++
                r = request("GET", "/oapi/charts-api/charts/v1/fetch-candle", params)
            }
            if (r.code != 200) {
                if (r.code == 401 || r.code == 403) throw ApiException(errorText(r))
                lastError = errorText(r)
                continue
            }
            val json = try { JSONObject(r.body) } catch (e: Exception) {
                lastError = "Unexpected response from HDFC Sky"; continue
            }
            val err = json.optJSONObject("meta")?.optString("err_code")?.lowercase() ?: ""
            if (err.isNotEmpty() && err != "success" && err != "ok" && err != "0") {
                lastError = json.optJSONObject("meta")?.optString("displayMessage") ?: "Chart error $err"
                continue
            }
            val rows = json.optJSONObject("data")?.optJSONArray("results") ?: JSONArray()
            if (rows.length() > 0) return JSONObject().put("symbol", sym).put("rows", rows)
        }
        if (lastError != null) throw ApiException(lastError)
        return JSONObject().put("symbol", chartSymbols.firstOrNull() ?: "").put("rows", JSONArray())
    }

    /** items: [{exchange, token}] -> [{exchange, token, ltp, prev_close}] */
    fun ltp(items: JSONArray): JSONArray {
        val data = JSONArray()
        for (i in 0 until items.length()) {
            val it = items.getJSONObject(i)
            val tok = it.optString("token")
            if (tok.isBlank()) continue
            data.put(JSONObject().put("exchange", it.optString("exchange")).put("token", tok))
        }
        if (data.length() == 0) return JSONArray()
        val r = request("PUT", "/oapi/v1/fetch-ltp", mapOf("api_key" to apiKey), JSONObject().put("data", data).toString())
        if (r.code != 200) throw ApiException(errorText(r))
        return JSONObject(r.body).optJSONArray("data") ?: JSONArray()
    }

    companion object {
        const val ROOT = "https://developer.hdfcsky.com"
        const val USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"

        fun loginUrl(apiKey: String): String =
            "$ROOT/oapi/v1/login?api_key=" + URLEncoder.encode(apiKey, "UTF-8")
    }
}
