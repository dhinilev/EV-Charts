package com.evgroup.evcharts

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.zip.ZipInputStream

/**
 * HDFC Sky security master (public ZIP with CompactScrip.csv, ~17 MB).
 * Columns: exchange_token, trading_symbol, company_name, close_price, expiry, strike,
 * tick_size, lot_size, instrument_name, option_type, segment, exchange, ...
 *
 * Only what EV Charts needs is kept, in a small TSV in the app's files folder:
 *   I  display  exchange  token                       (indices)
 *   S  symbol   name      token                       (NSE cash, -EQ series)
 *   O  und  expiry(yyyy-MM-dd)  strike  CE|PE  tradingSymbol  token  lot  exchange   (index options)
 *   F  und  expiry  tradingSymbol  token  lot  exchange                                (index futures)
 */
class ContractMaster(private val dir: File) {

    data class Index(val display: String, val exchange: String, val token: String)
    data class Stock(val symbol: String, val name: String, val token: String)
    data class Fut(val und: String, val expiry: String, val tsym: String, val token: String, val lot: Int, val exchange: String)
    data class Opt(
        val und: String, val expiry: String, val strike: Double, val side: String,
        val tsym: String, val token: String, val lot: Int, val exchange: String
    )

    private val dataFile = File(dir, "instruments.tsv")
    private val metaFile = File(dir, "instruments_meta.json")

    @Volatile private var indices: List<Index> = emptyList()
    @Volatile private var stocks: List<Stock> = emptyList()
    @Volatile private var options: List<Opt> = emptyList()
    @Volatile private var futures: List<Fut> = emptyList()
    @Volatile private var loaded = false

    fun meta(): JSONObject? = try {
        if (metaFile.exists()) JSONObject(metaFile.readText()) else null
    } catch (e: Exception) { null }

    /** Format version 2 added index futures; older files are downloaded again. */
    fun isReady(): Boolean = dataFile.exists() && (meta()?.optInt("v") ?: 0) >= FORMAT

    /** Downloads and rebuilds the instrument file. progress(pct 0..100). */
    fun download(progress: (Int) -> Unit): Int {
        val conn = URL(URL_MASTER).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", HdfcSky.USER_AGENT)
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        try {
            if (conn.responseCode != 200) throw Exception("Contract list download failed (HTTP ${conn.responseCode})")
            val total = conn.contentLengthLong
            var read = 0L
            var lastPct = -1
            val counting = object : FilterInputStream(conn.inputStream) {
                private fun bump(n: Int) {
                    if (n <= 0) return
                    read += n
                    if (total > 0) {
                        val pct = (read * 90 / total).toInt()
                        if (pct != lastPct) { lastPct = pct; progress(pct) }
                    }
                }
                override fun read(): Int { val b = super.read(); if (b >= 0) bump(1); return b }
                override fun read(b: ByteArray, off: Int, len: Int): Int { val n = super.read(b, off, len); bump(n); return n }
            }
            val tmp = File(dir, "instruments.tmp")
            val count = ZipInputStream(counting).use { zip ->
                var entry = zip.nextEntry
                while (entry != null && !entry.name.lowercase().endsWith(".csv")) entry = zip.nextEntry
                if (entry == null) throw Exception("No CSV inside the contract list")
                parseCsv(zip, tmp)
            }
            progress(95)
            if (count == 0) throw Exception("Contract list was empty")
            tmp.renameTo(dataFile)
            metaFile.writeText(JSONObject().put("date", todayIst()).put("count", count).put("v", FORMAT).toString())
            loaded = false
            load()
            progress(100)
            return count
        } finally {
            conn.disconnect()
        }
    }

    private fun parseCsv(input: InputStream, out: File): Int {
        val reader = input.bufferedReader(Charsets.UTF_8)
        val header = splitCsv(reader.readLine() ?: return 0).map { it.trim().lowercase() }
        fun col(name: String) = header.indexOf(name)
        val cTok = col("exchange_token"); val cSym = col("trading_symbol"); val cName = col("company_name")
        val cExp = col("expiry"); val cStrike = col("strike"); val cLot = col("lot_size")
        val cOpt = col("option_type"); val cSeg = col("segment"); val cEx = col("exchange")
        if (listOf(cTok, cSym, cEx).any { it < 0 }) throw Exception("Unexpected contract list format")

        val today = todayIst()
        val inFmt = SimpleDateFormat("dd-MMM-yyyy", Locale.ENGLISH)
        val outFmt = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH)
        val dateCache = HashMap<String, String>()
        var count = 0

        out.bufferedWriter().use { w ->
            while (true) {
                val line = reader.readLine() ?: break
                val f = splitCsv(line)
                fun g(i: Int) = if (i in f.indices) f[i].trim() else ""
                val ex = g(cEx).uppercase()
                val tsym = g(cSym)
                val tok = g(cTok)
                if (tsym.isEmpty() || tok.isEmpty()) continue
                val seg = g(cSeg).uppercase()

                if ((ex == "NSE" && seg == "INDICES") || (ex == "BSE" && seg == "IDX")) {
                    w.write("I\t$tsym\t$ex\t$tok\n"); count++; continue
                }
                if (ex == "NSE" && tsym.endsWith("-EQ")) {
                    val name = g(cName).replace('\t', ' ')
                    w.write("S\t${tsym.removeSuffix("-EQ")}\t$name\t$tok\n"); count++; continue
                }
                if (ex == "NFO" || ex == "BFO") {
                    val side = g(cOpt).uppercase()
                    if (side != "CE" && side != "PE") {
                        // Index futures: the buyer/seller flow and OI source for index charts.
                        if (!tsym.endsWith("FUT")) continue
                        val und = underlyingOf(g(cName), tsym) ?: continue
                        val rawExp = g(cExp)
                        val exp = dateCache.getOrPut(rawExp) {
                            try { outFmt.format(inFmt.parse(rawExp)!!) } catch (e: Exception) { "" }
                        }
                        if (exp.isEmpty() || exp < today) continue
                        val lot = g(cLot).toDoubleOrNull()?.toInt() ?: 0
                        w.write("F\t$und\t$exp\t$tsym\t$tok\t$lot\t$ex\n"); count++
                        continue
                    }
                    val und = underlyingOf(g(cName), tsym) ?: continue
                    val rawExp = g(cExp)
                    val exp = dateCache.getOrPut(rawExp) {
                        try { outFmt.format(inFmt.parse(rawExp)!!) } catch (e: Exception) { "" }
                    }
                    if (exp.isEmpty() || exp < today) continue
                    val strike = g(cStrike).toDoubleOrNull() ?: continue
                    val lot = g(cLot).toDoubleOrNull()?.toInt() ?: 0
                    w.write("O\t$und\t$exp\t$strike\t$side\t$tsym\t$tok\t$lot\t$ex\n"); count++
                }
            }
        }
        return count
    }

    private fun underlyingOf(company: String, tsym: String): String? {
        val c = company.uppercase().replace(" ", "")
        if (c in OPTION_UNDERLYINGS) return c
        // Fall back to the trading symbol: underlying followed directly by the year digits.
        return OPTION_UNDERLYINGS.sortedByDescending { it.length }.firstOrNull {
            tsym.startsWith(it) && tsym.length > it.length && tsym[it.length].isDigit()
        }
    }

    @Synchronized
    fun load() {
        if (loaded) return
        if (!dataFile.exists()) throw Exception("Contract list not downloaded yet")
        val ix = ArrayList<Index>(); val st = ArrayList<Stock>(4000); val op = ArrayList<Opt>(60000); val fu = ArrayList<Fut>()
        dataFile.bufferedReader().useLines { lines ->
            lines.forEach { line ->
                val f = line.split('\t')
                when (f[0]) {
                    "I" -> if (f.size >= 4) ix.add(Index(f[1], f[2], f[3]))
                    "S" -> if (f.size >= 4) st.add(Stock(f[1], f[2], f[3]))
                    "F" -> if (f.size >= 7) fu.add(Fut(f[1], f[2], f[3], f[4], f[5].toIntOrNull() ?: 0, f[6]))
                    "O" -> if (f.size >= 9) op.add(Opt(f[1], f[2], f[3].toDouble(), f[4], f[5], f[6], f[7].toIntOrNull() ?: 0, f[8]))
                }
            }
        }
        indices = ix; stocks = st.sortedBy { it.symbol }; options = op; futures = fu.sortedBy { it.expiry }
        loaded = true
    }

    /* ---------------- queries used by the UI ---------------- */

    fun indexList(): JSONArray {
        load()
        val byNorm = indices.associateBy { norm(it.display) + "|" + it.exchange }
        val out = JSONArray()
        for (w in WANTED_INDICES) {
            val hit = byNorm[w.norm + "|" + w.exchange]
            val display = hit?.display?.uppercase() ?: w.label
            val symbols = JSONArray().put(w.key)
            if (display != w.key) symbols.put(display)
            out.put(
                JSONObject()
                    .put("key", w.key).put("label", w.label).put("exchange", w.exchange)
                    .put("series", if (w.exchange == "NSE") "INDICES" else "IDX")
                    .put("ltpExchange", w.exchange + "_INDEX")
                    .put("token", hit?.token ?: "")
                    .put("chartSymbols", symbols)
                    .put("future", nearestFuture(w.key) ?: JSONObject.NULL)
            )
        }
        return out
    }

    /** Nearest-expiry index future (today's expiry rolls to the next one after 15:30 by date filter). */
    private fun nearestFuture(und: String): JSONObject? {
        val today = todayIst()
        val f = futures.firstOrNull { it.und == und && it.expiry >= today } ?: return null
        return JSONObject().put("symbol", f.tsym).put("token", f.token).put("lot", f.lot)
            .put("exchange", f.exchange).put("series", if (f.exchange == "NFO") "FUTIDX" else "IF")
            .put("expiry", f.expiry)
    }

    fun underlyings(): JSONArray {
        load()
        val present = options.map { it.und }.toSet()
        return JSONArray(OPTION_UNDERLYINGS.filter { it in present })
    }

    fun expiries(und: String): JSONArray {
        load()
        val today = todayIst()
        return JSONArray(options.asSequence().filter { it.und == und && it.expiry >= today }
            .map { it.expiry }.distinct().sorted().toList())
    }

    fun chain(und: String, expiry: String): JSONObject {
        load()
        val legs = options.filter { it.und == und && it.expiry == expiry }
        if (legs.isEmpty()) throw Exception("No contracts for $und $expiry")
        val exchange = legs.first().exchange
        val strikes = JSONArray()
        legs.groupBy { it.strike }.toSortedMap().forEach { (strike, list) ->
            val o = JSONObject().put("strike", strike)
            list.firstOrNull { it.side == "CE" }?.let { o.put("ce", JSONObject().put("symbol", it.tsym).put("token", it.token)) }
            list.firstOrNull { it.side == "PE" }?.let { o.put("pe", JSONObject().put("symbol", it.tsym).put("token", it.token)) }
            strikes.put(o)
        }
        val idx = WANTED_INDICES.firstOrNull { it.key == und }
        val idxRow = idx?.let { w -> indices.firstOrNull { norm(it.display) == w.norm && it.exchange == w.exchange } }
        val res = JSONObject()
            .put("exchange", exchange)
            .put("series", if (exchange == "NFO") "OPTIDX" else "IO")
            .put("lot", legs.first().lot)
            .put("strikes", strikes)
        if (idx != null && idxRow != null) {
            res.put("spot", JSONObject().put("exchange", idx.exchange + "_INDEX").put("token", idxRow.token))
        }
        return res
    }

    fun searchStocks(q: String): JSONArray {
        load()
        val query = q.trim().uppercase()
        if (query.isEmpty()) return JSONArray()
        val starts = stocks.filter { it.symbol.startsWith(query) }
        val rest = stocks.filter { !it.symbol.startsWith(query) && (it.symbol.contains(query) || it.name.uppercase().contains(query)) }
        val out = JSONArray()
        (starts + rest).take(25).forEach {
            out.put(JSONObject().put("symbol", it.symbol).put("name", it.name).put("token", it.token)
                .put("exchange", "NSE").put("series", "EQ"))
        }
        return out
    }

    companion object {
        const val FORMAT = 2
        const val URL_MASTER = "https://hdfcsky.com/api/v1/contract/Compact?info=download"

        val OPTION_UNDERLYINGS = listOf("NIFTY", "BANKNIFTY", "SENSEX", "FINNIFTY", "MIDCPNIFTY", "BANKEX")

        data class WantedIndex(val key: String, val label: String, val exchange: String, val norm: String)

        val WANTED_INDICES = listOf(
            WantedIndex("NIFTY", "NIFTY 50", "NSE", "NIFTY50"),
            WantedIndex("BANKNIFTY", "NIFTY BANK", "NSE", "NIFTYBANK"),
            WantedIndex("SENSEX", "SENSEX", "BSE", "SENSEX"),
            WantedIndex("FINNIFTY", "NIFTY FIN SERVICE", "NSE", "NIFTYFINSERVICE"),
            WantedIndex("MIDCPNIFTY", "NIFTY MID SELECT", "NSE", "NIFTYMIDSELECT"),
            WantedIndex("BANKEX", "BANKEX", "BSE", "BANKEX"),
            WantedIndex("INDIAVIX", "INDIA VIX", "NSE", "INDIAVIX"),
        )

        fun norm(s: String) = s.uppercase().replace(Regex("\\s+"), "")

        fun todayIst(): String = SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).apply {
            timeZone = TimeZone.getTimeZone("Asia/Kolkata")
        }.format(java.util.Date())

        /** Minimal CSV splitter that understands double-quoted fields. */
        fun splitCsv(line: String): List<String> {
            if (line.indexOf('"') < 0) return line.split(',')
            val out = ArrayList<String>()
            val sb = StringBuilder()
            var quoted = false
            var i = 0
            while (i < line.length) {
                val ch = line[i]
                when {
                    ch == '"' && quoted && i + 1 < line.length && line[i + 1] == '"' -> { sb.append('"'); i++ }
                    ch == '"' -> quoted = !quoted
                    ch == ',' && !quoted -> { out.add(sb.toString()); sb.setLength(0) }
                    else -> sb.append(ch)
                }
                i++
            }
            out.add(sb.toString())
            return out
        }
    }
}
