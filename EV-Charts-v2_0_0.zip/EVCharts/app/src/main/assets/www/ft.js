/* EV Charts — Flattrade Pi API: ORDERS ONLY (chart data stays on HDFC Sky).
   Login once a day in the app's login screen; the daily token is kept encrypted on the phone.
   Orders go out only after the user taps Confirm in the order window. Same REST calls as EV Pulse. */
(function (root) {
  'use strict';

  const AUTH = 'https://auth.flattrade.in/?app_key=';
  const TOKEN_URL = 'https://authapi.flattrade.in/trade/apitoken';
  const REST = 'https://piconnect.flattrade.in/PiConnectAPI';
  const REDIRECT = 'https://127.0.0.1/evdplan';
  const MON = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];
  const CFG = { NIFTY: { exch: 'NFO', step: 50 }, SENSEX: { exch: 'BFO', step: 100 } };

  function createFT(deps) {
    const { http, store, Core: C, sha256, openLogin } = deps;
    const ft = {
      REDIRECT, name: 'Flattrade',
      cfg: Object.assign({ uid: '', key: '', secret: '', redirect: REDIRECT }, store.get('oi.ft.cfg', {})),
      sess: store.get('oi.ft.sess', null),     // {token, uid, at}
      diag: [], err: null, symCache: store.get('oi.ft.sym', {}),
    };
    function log(what, detail) { ft.diag.unshift({ at: Date.now(), what, detail: String(detail || '').slice(0, 500) }); ft.diag.length = Math.min(ft.diag.length, 12); }

    // Flattrade tokens expire daily at 5:00 AM IST.
    function lastReset(now) {
      const p = C.istParts(now);
      const todayReset = Date.UTC(p.y, p.mo - 1, p.d, 5, 0) - 5.5 * 3600e3;
      return now >= todayReset ? todayReset : todayReset - 86400e3;
    }
    ft.configured = () => !!(ft.cfg.uid && ft.cfg.key && ft.cfg.secret);
    ft.ready = () => !!(ft.sess && ft.sess.token && ft.sess.at >= lastReset(Date.now()));
    ft.saveCfg = (cfg) => { ft.cfg = Object.assign({}, ft.cfg, cfg); store.set('oi.ft.cfg', ft.cfg); };
    ft.logout = () => { ft.sess = null; store.set('oi.ft.sess', null); };

    /** opens Flattrade's login page; resolves once the daily token is saved */
    ft.login = async function () {
      if (!ft.configured()) throw { msg: 'Enter your Flattrade client ID, API key and secret first.' };
      const redirect = ft.cfg.redirect || REDIRECT;
      const res = await openLogin(AUTH + encodeURIComponent(ft.cfg.key), redirect);   // {code, client} or {error}
      if (!res || !res.code) throw { msg: (res && res.error) || 'Login cancelled.' };
      const hash = await sha256(ft.cfg.key + res.code + ft.cfg.secret);
      if (!hash) throw { msg: 'Flattrade login: could not compute the token hash.' };
      const r = await http('POST', TOKEN_URL, { 'Content-Type': 'application/json', 'Accept': 'application/json' },
        JSON.stringify({ api_key: ft.cfg.key, request_code: res.code, api_secret: hash }));
      log('apitoken HTTP ' + r.status, (r.text || '').replace(/"token"\s*:\s*"[^"]+"/g, '"token":"…"'));
      let j = null; try { j = JSON.parse(r.text); } catch (e) { }
      if (!j || !j.token) throw { msg: 'Flattrade login failed: ' + ((j && (j.emsg || j.message)) || ('HTTP ' + r.status)) };
      ft.sess = { token: j.token, uid: String(j.client || res.client || ft.cfg.uid).toUpperCase(), at: Date.now() };
      store.set('oi.ft.sess', ft.sess); ft.err = null;
      return true;
    };

    async function rest(path, values) {
      if (!ft.ready()) throw { msg: 'Flattrade: log in for today first (Settings → Orders).', login: true };
      const body = 'jData=' + JSON.stringify(Object.assign({ uid: ft.sess.uid }, values)) + '&jKey=' + ft.sess.token;
      const r = await http('POST', REST + path, { 'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json' }, body);
      let j = null; try { j = JSON.parse(r.text); } catch (e) { }
      log(path + ' HTTP ' + r.status, r.text);
      if (j && /session expired|invalid session|not logged/i.test(String(j.emsg || ''))) { ft.logout(); throw { msg: 'Flattrade session expired: log in again (Settings → Orders).', login: true }; }
      if (!j) throw { msg: `Flattrade ${path}: no response (HTTP ${r.status}).` };
      return j;
    }
    const okList = j => (Array.isArray(j) ? j : (j && j.stat === 'Ok' && Array.isArray(j.values) ? j.values : []));

    function candidates(index, iso, strike) {
      const [y, m, d] = iso.split('-'), yy = y.slice(2), mon = MON[+m - 1], k = Math.round(strike);
      const mcode = '123456789OND'[+m - 1];
      const nse = `${index}${d}${mon}${yy}C${k}`;
      const bseWeekly = `${index}${yy}${mcode}${d}${k}CE`, bseMonthly = `${index}${yy}${mon}${k}CE`;
      return index === 'SENSEX' ? [bseWeekly, bseMonthly, nse, `${index}${yy}${+m}${d}${k}CE`] : [nse, bseWeekly, bseMonthly];
    }
    function expIso(v) {
      const e = String(v.exd || v.expiry || '');
      const mm = /^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/.exec(e);
      return mm ? `${mm[3]}-${String(MON.indexOf(mm[2].toUpperCase()) + 1).padStart(2, '0')}-${mm[1].padStart(2, '0')}` : '';
    }
    function remember(index, iso, ts) { ft.symCache[index + '|' + iso] = ts; store.set('oi.ft.sym', ft.symCache); log('chain symbol', `${index} ${iso}: ${ts}`); }

    /** exact Flattrade contract (trading symbol + token + lot) for index / expiry / strike / CE|PE */
    ft.contract = async function (index, iso, strike, side) {
      const cfg = CFG[index]; if (!cfg) throw { msg: `Flattrade orders cover NIFTY and SENSEX only (not ${index}).` };
      const chainOf = async ts => okList(await rest('/GetOptionChain', { exch: cfg.exch, tsym: ts, strprc: String(Math.round(strike)), cnt: '4' }));
      let vals = [];
      const known = ft.symCache[index + '|' + iso];
      if (known) vals = await chainOf(known);
      if (!vals.length) for (const ts of candidates(index, iso, strike)) { vals = await chainOf(ts); if (vals.length) { remember(index, iso, ts); break; } }
      if (!vals.length) {
        const [y, m, d] = iso.split('-'), mon = MON[+m - 1];
        const texts = [`${index} ${d}${mon}${y.slice(2)}`, `${index} ${Math.round(strike)}`, `${index} ${mon}`, index];
        for (const stext of texts) {
          let found = [];
          try { found = okList(await rest('/SearchScrip', { exch: cfg.exch, stext })); } catch (e) { if (e && e.login) throw e; }
          const opts = found.filter(v => String(v.tsym || '').toUpperCase().startsWith(index) && !/^SENSEX50|^NIFTYNXT|^NIFTYFPI/i.test(String(v.tsym))
            && (/OPT/i.test(String(v.instname || '')) || /^(CE|PE)$/i.test(String(v.optt || ''))));
          const same = opts.filter(v => expIso(v) === iso || new RegExp(d + '\\s?' + mon, 'i').test(String(v.dname || v.cname || '')));
          if (same[0]) { vals = await chainOf(same[0].tsym); if (vals.length) { remember(index, iso, same[0].tsym); break; } }
        }
      }
      if (!vals.length) throw { msg: `Flattrade: couldn't find the ${index} ${iso} option chain.` };
      const v = vals.find(x => parseFloat(x.strprc) === Math.round(strike) && (/^P/i.test(String(x.optt)) ? 'PE' : 'CE') === side);
      if (!v) throw { msg: `Flattrade has no ${index} ${strike} ${side} for ${iso}.` };
      return { exch: v.exch || cfg.exch, token: String(v.token), tsym: String(v.tsym), ls: parseInt(v.ls) || 0 };
    };

    ft.placeOrder = async function (o) {
      const j = await rest('/PlaceOrder', { actid: ft.sess.uid, exch: o.exch, tsym: o.tsym, qty: String(o.qty), prc: o.prctyp === 'MKT' ? '0' : String(o.prc), prd: o.prd, trantype: o.trantype,
        prctyp: o.prctyp, ret: 'DAY', ordersource: 'API', remarks: 'EV Charts', ...(o.trgprc ? { trgprc: String(o.trgprc) } : {}) });
      if (j && j.stat === 'Ok' && j.norenordno) return { ok: true, no: String(j.norenordno) };
      return { ok: false, err: (j && (j.emsg || j.stat)) || 'No reply from Flattrade' };
    };
    ft.modifyOrder = async function (o) {
      const j = await rest('/ModifyOrder', { exch: o.exch, tsym: o.tsym, norenordno: String(o.no), prctyp: o.prctyp, prc: String(o.prc), qty: String(o.qty), ret: 'DAY', ...(o.trgprc ? { trgprc: String(o.trgprc) } : {}) });
      return j && j.stat === 'Ok' ? { ok: true, no: String(o.no) } : { ok: false, err: (j && j.emsg) || 'Modify failed' };
    };
    ft.cancelOrder = async function (no) {
      const j = await rest('/CancelOrder', { norenordno: String(no) });
      return j && j.stat === 'Ok' ? { ok: true } : { ok: false, err: (j && j.emsg) || 'Cancel failed' };
    };
    ft.orderBook = async function () {
      const j = await rest('/OrderBook', {});
      const v = Array.isArray(j) ? j.filter(x => x && x.norenordno) : okList(j);   // "no data" comes back as a stat=Not_Ok object = no orders yet
      return { at: Date.now(), list: v.map(x => ({ no: String(x.norenordno || ''), tsym: String(x.tsym || ''), side: String(x.trantype || ''), qty: parseInt(x.qty) || 0, fill: parseInt(x.fillshares) || 0,
        prc: parseFloat(x.prc) || 0, avg: parseFloat(x.avgprc) || 0, type: String(x.prctyp || ''), prd: String(x.prd || ''), status: String(x.status || '').toUpperCase(), why: String(x.rejreason || ''), ts: String(x.norentm || x.exch_tm || '') })) };
    };
    ft.limits = async function () {
      const j = await rest('/Limits', { actid: ft.sess.uid });
      if (!j || j.stat !== 'Ok') throw { msg: (j && j.emsg) || 'Could not read funds from Flattrade' };
      const n = k => parseFloat(j[k]) || 0;
      return { at: Date.now(), avail: Math.max(0, n('cash') + n('payin') + n('brkcollamt') - n('marginused') - n('payout')) };
    };
    ft.status = function () {
      if (!ft.configured()) return 'Not set up';
      if (!ft.ready()) return 'Not logged in today';
      return 'Logged in for today · orders ready';
    };
    return ft;
  }

  root.createFT = createFT;
})(typeof window !== 'undefined' ? window : globalThis);
