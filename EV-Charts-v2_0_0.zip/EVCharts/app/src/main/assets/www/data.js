/*
 * EV Charts — candle parsing, resampling and indicators.
 * Pure functions, no DOM. Times: IST wall clock seconds stored as UTC.
 */
(function () {
  'use strict';

  const SESSION_START = 9 * 3600 + 15 * 60; // 09:15 IST

  // HDFC Sky sends "DD-MM-YYYY HH:MM" (intraday) or "DD-MM-YYYY" (daily), IST.
  function parseStamp(s) {
    if (typeof s === 'number') return s > 1e11 ? Math.floor(s / 1000) : s;
    s = String(s).trim();
    let m = s.match(/^(\d{2})-(\d{2})-(\d{4})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if (m) {
      return Date.UTC(+m[3], +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)) / 1000;
    }
    m = s.match(/^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}):(\d{2})(?::(\d{2}))?)?/);
    if (m) {
      return Date.UTC(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0)) / 1000;
    }
    return NaN;
  }

  // Raw rows: [open, high, low, close, volume, oi, stamp, (cumVol)]
  function parseRows(rows) {
    const out = [];
    for (const r of rows || []) {
      if (!Array.isArray(r) || r.length < 7) continue;
      const t = parseStamp(r[6]);
      const o = +r[0], h = +r[1], l = +r[2], c = +r[3];
      if (!isFinite(t) || !isFinite(o) || !isFinite(c)) continue;
      out.push({ t, o, h: Math.max(h, o, c), l: Math.min(l, o, c), c, v: +r[4] || 0, oi: +r[5] || 0 });
    }
    out.sort((a, b) => a.t - b.t);
    // de-duplicate by time, last one wins
    const dedup = [];
    for (const b of out) {
      if (dedup.length && dedup[dedup.length - 1].t === b.t) dedup[dedup.length - 1] = b;
      else dedup.push(b);
    }
    return dedup;
  }

  function bucketOf(t, tf) {
    if (tf.minutes) {
      if (tf.minutes === 1) return t;
      const day = t - (t % 86400);
      const start = day + SESSION_START;
      const size = tf.minutes * 60;
      return start + Math.floor((t - start) / size) * size;
    }
    if (tf.weekly) {
      const day = Math.floor(t / 86400);
      const dow = (day + 4) % 7; // 0 = Sunday (1 Jan 1970 was a Thursday)
      return (day - ((dow + 6) % 7)) * 86400;
    }
    return t - (t % 86400);
  }

  function resample(bars, tf) {
    if (tf.minutes === 1 || (tf.daily && !tf.weekly)) return bars.slice();
    const out = [];
    let cur = null;
    for (const b of bars) {
      const k = bucketOf(b.t, tf);
      if (!cur || cur.t !== k) {
        cur = { t: k, o: b.o, h: b.h, l: b.l, c: b.c, v: b.v, oi: b.oi };
        out.push(cur);
      } else {
        cur.h = Math.max(cur.h, b.h);
        cur.l = Math.min(cur.l, b.l);
        cur.c = b.c;
        cur.v += b.v;
        cur.oi = b.oi || cur.oi;
      }
    }
    return out;
  }

  function ema(bars, period) {
    const k = 2 / (period + 1);
    const out = new Array(bars.length).fill(null);
    let prev = null, sum = 0;
    for (let i = 0; i < bars.length; i++) {
      const c = bars[i].c;
      if (i < period - 1) { sum += c; continue; }
      if (i === period - 1) { sum += c; prev = sum / period; }
      else prev = c * k + prev * (1 - k);
      out[i] = prev;
    }
    return out;
  }

  // Session VWAP that resets every trading day.
  function vwap(bars) {
    const out = new Array(bars.length).fill(null);
    let day = null, pv = 0, vol = 0;
    for (let i = 0; i < bars.length; i++) {
      const b = bars[i];
      const d = Math.floor(b.t / 86400);
      if (d !== day) { day = d; pv = 0; vol = 0; }
      const tp = (b.h + b.l + b.c) / 3;
      pv += tp * b.v; vol += b.v;
      out[i] = vol > 0 ? pv / vol : null;
    }
    return out;
  }

  function hasVolume(bars) {
    for (const b of bars) if (b.v > 0) return true;
    return false;
  }

  // Previous trading day's high / low / close, from intraday candles.
  function previousDayLevels(bars) {
    if (!bars.length) return null;
    const lastDay = Math.floor(bars[bars.length - 1].t / 86400);
    let pd = null;
    for (let i = bars.length - 1; i >= 0; i--) {
      const d = Math.floor(bars[i].t / 86400);
      if (d === lastDay) continue;
      if (pd === null) pd = { day: d, h: -Infinity, l: Infinity, c: bars[i].c };
      if (d !== pd.day) break;
      pd.h = Math.max(pd.h, bars[i].h);
      pd.l = Math.min(pd.l, bars[i].l);
    }
    return pd;
  }

  // Merge freshly fetched raw candles into an existing raw list by time.
  function mergeRaw(existing, fresh) {
    if (!fresh.length) return existing;
    const cut = fresh[0].t;
    const keep = existing.filter((b) => b.t < cut);
    return keep.concat(fresh);
  }

  function istNow() {
    return Math.floor(Date.now() / 1000) + 19800;
  }

  function isMarketOpen() {
    const t = istNow();
    const day = Math.floor(t / 86400);
    const dow = (day + 4) % 7;
    if (dow === 0 || dow === 6) return false;
    const sec = t % 86400;
    return sec >= SESSION_START - 60 && sec <= 15 * 3600 + 31 * 60;
  }

  function ymd(t) {
    const d = new Date(t * 1000);
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
  }

  /* ---------- buyers / sellers ---------- */

  // flowMin: Map(minute t -> [buyQty, sellQty]) -> per-bar {b, s} (null where nothing was collected)
  function flowPerBar(bars, flowMin, tf) {
    const out = new Array(bars.length).fill(null);
    if (!flowMin || !flowMin.size || !bars.length) return out;
    const idx = new Map();
    bars.forEach((b, i) => idx.set(b.t, i));
    for (const [t, v] of flowMin) {
      const i = idx.get(bucketOf(t, tf));
      if (i === undefined) continue;
      const cell = out[i] || (out[i] = { b: 0, s: 0 });
      cell.b += v[0];
      cell.s += v[1];
    }
    return out;
  }

  // Cumulative delta (buy - sell), restarting each day; null before flow exists that day.
  function cumulativeDelta(bars, flow) {
    const out = new Array(bars.length).fill(null);
    let day = null, run = 0, started = false;
    for (let i = 0; i < bars.length; i++) {
      const d = Math.floor(bars[i].t / 86400);
      if (d !== day) { day = d; run = 0; started = false; }
      const f = flow[i];
      if (f) { run += f.b - f.s; started = true; }
      if (started) out[i] = run;
    }
    return out;
  }

  /*
   * Writers / buyers from OI change + price change, per candle:
   *   OI up,   price down -> WA  writers adding      (futures: short buildup)
   *   OI down, price up   -> WE  writers exiting     (futures: short covering)
   *   OI up,   price up   -> BA  buyers adding       (futures: long buildup)
   *   OI down, price down -> BE  buyers exiting      (futures: long unwinding)
   * oiBars: candles carrying OI (the option itself, or the index future aligned by time).
   */
  function oiBuildup(bars, oiBars) {
    const out = new Array(bars.length).fill(null);
    const src = oiBars || bars;
    const byT = oiBars ? new Map(oiBars.map((b) => [b.t, b])) : null;
    let prev = null;
    for (let i = 0; i < bars.length; i++) {
      const cur = byT ? byT.get(bars[i].t) : src[i];
      if (!cur || !cur.oi) { continue; }
      if (prev && prev.oi) {
        const dOi = cur.oi - prev.oi;
        const dP = cur.c - prev.c;
        if (dOi !== 0 && dP !== 0) {
          const kind = dOi > 0 ? (dP < 0 ? 'WA' : 'BA') : (dP > 0 ? 'WE' : 'BE');
          out[i] = { kind, dOi };
        }
      }
      prev = cur;
    }
    return out;
  }

  /*
   * Estimated buyer / seller split for candles that have no live trades recorded
   * (past candles). Volume is shared by where the candle closed inside its range:
   * close at the high = all buyers, close at the low = all sellers.
   * volBars: candles carrying the volume (the index future, aligned by time), or null = own volume.
   */
  function estimateFlow(bars, volBars) {
    const out = new Array(bars.length).fill(null);
    const byT = volBars ? new Map(volBars.map((b) => [b.t, b])) : null;
    for (let i = 0; i < bars.length; i++) {
      const src = byT ? byT.get(bars[i].t) : bars[i];
      if (!src || !(src.v > 0)) continue;
      const range = src.h - src.l;
      const share = range > 0 ? (src.c - src.l) / range : 0.5;
      const b = src.v * share;
      out[i] = { b, s: src.v - b, est: true };
    }
    return out;
  }

  /*
   * Writers / buyers per minute from 1-minute candles with OI (the option itself, or the index future):
   * returns Map(minute t -> {wa, we, ba, be, kind}) where kind is the dominant group that minute.
   */
  function oiMinuteMap(raw1m) {
    const map = new Map();
    for (let i = 1; i < raw1m.length; i++) {
      const a = raw1m[i - 1], b = raw1m[i];
      if (!a.oi || !b.oi || Math.floor(a.t / 86400) !== Math.floor(b.t / 86400)) continue;
      const dOi = b.oi - a.oi, dP = b.c - a.c;
      if (dOi === 0 || dP === 0) continue;
      const kind = dOi > 0 ? (dP < 0 ? 'WA' : 'BA') : (dP > 0 ? 'WE' : 'BE');
      const cell = { wa: 0, we: 0, ba: 0, be: 0, kind };
      cell[kind.toLowerCase()] = Math.abs(dOi);
      map.set(b.t, cell);
    }
    return map;
  }

  // Sum the per-minute writers / buyers into each chart candle: [{wa, we, ba, be}] (null when none)
  function writersBuyers(bars, oiMap, tf) {
    const out = new Array(bars.length).fill(null);
    if (!oiMap || !oiMap.size) return out;
    const idx = new Map();
    bars.forEach((b, i) => idx.set(b.t, i));
    for (const [t, v] of oiMap) {
      const i = idx.get(bucketOf(t, tf));
      if (i === undefined) continue;
      const c = out[i] || (out[i] = { wa: 0, we: 0, ba: 0, be: 0 });
      c.wa += v.wa; c.we += v.we; c.ba += v.ba; c.be += v.be;
    }
    return out;
  }

  function hasOi(bars) {
    let n = 0;
    for (const b of bars) if (b.oi > 0 && ++n > 2) return true;
    return false;
  }

  window.EVData = { parseStamp, parseRows, resample, bucketOf, ema, vwap, hasVolume, previousDayLevels, mergeRaw, istNow, isMarketOpen, ymd,
    flowPerBar, cumulativeDelta, oiBuildup, hasOi, estimateFlow, oiMinuteMap, writersBuyers };
})();
