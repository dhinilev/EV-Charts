/*
 * EV Charts — full-screen chart.
 *  • Phone held sideways (landscape): the chart takes the whole screen — status and navigation bars hidden.
 *  • ⛶ button on the chart: full screen in portrait too (or leave full screen in landscape).
 *  • In full screen only the chart, the trade bar, the order window and a slim top strip are shown.
 */
(function (root) {
  'use strict';

  const View = { fs: false };
  root.EVView = View;

  View.init = function init(A) {
    if (View.ready) return;
    View.ready = true;
    const EV = root.EV;
    const $ = (id) => document.getElementById(id);
    const wrap = $('chartWrap');
    if (!wrap) return;

    // ⛶ button (top-right of the chart)
    const btn = document.createElement('button');
    btn.id = 'fsBtn'; btn.className = 'fs-btn'; btn.type = 'button'; btn.setAttribute('aria-label', 'Full screen chart');
    btn.textContent = '⛶';
    wrap.appendChild(btn);

    // slim strip shown only in full screen: instrument, price, Trade button
    const strip = document.createElement('div');
    strip.id = 'fsStrip'; strip.className = 'fs-strip';
    strip.innerHTML = '<b id="fsName">—</b><span id="fsLtp">—</span><span id="fsChg"></span><button class="mini" id="fsTrade" type="button">Trade ▸</button>';
    wrap.appendChild(strip);
    $('fsTrade').onclick = () => { if (root.EVTrade && root.EVTrade.openManual) root.EVTrade.openManual(); };

    let override = null;          // null = follow the phone's orientation, true / false = the user chose
    let lastLandscape = null;

    const isLandscape = () => window.innerWidth > window.innerHeight && window.innerWidth >= 480;
    function apply() {
      const land = isLandscape();
      if (land !== lastLandscape) { lastLandscape = land; override = null; }     // turning the phone resets the manual choice
      const on = override == null ? land : override;
      if (on === View.fs && btn.dataset.init) return;
      btn.dataset.init = '1';
      View.fs = on;
      document.body.classList.toggle('fs', on);
      btn.textContent = on ? '✕' : '⛶';
      btn.title = on ? 'Leave full screen' : 'Full screen';
      EV.call('immersive', { on }).catch(() => {});
      setTimeout(() => { try { A.chart.resize(); } catch (e) { /* ignore */ } }, 80);
      setTimeout(() => { try { A.chart.resize(); } catch (e) { /* ignore */ } }, 400);
    }
    btn.onclick = () => { override = !View.fs; apply(); };
    window.addEventListener('resize', apply);
    window.addEventListener('orientationchange', () => setTimeout(apply, 120));
    EV.on('resume', () => { EV.call('immersive', { on: View.fs }).catch(() => {}); });

    // keep the strip in step with the normal quote header
    const mirror = () => {
      const g = (id) => $(id);
      const name = g('qName'), ltp = g('qLtp'), chg = g('qChg');
      if (!name) return;
      $('fsName').textContent = name.textContent;
      $('fsLtp').textContent = ltp.textContent; $('fsLtp').className = ltp.className.replace('q-ltp', '').trim();
      $('fsChg').textContent = chg.textContent; $('fsChg').className = chg.className.replace('q-chg', '').trim();
    };
    setInterval(mirror, 600);
    apply();
  };
})(typeof window !== 'undefined' ? window : globalThis);
