/*
 * EV Charts — pattern markers, BUY CE / BUY PE signals, and walls / magnets.
 * Pure functions (no DOM), so they can be tested outside the app.
 *
 * Times are IST wall-clock seconds stored as UTC (see data.js).
 */
(function () {
  'use strict';

  const DAY = 86400;
  const tod = (t) => t % DAY; // seconds since IST midnight
  const T0930 = 9 * 3600 + 30 * 60;
  const T1500 = 15 * 3600;

  const DEFAULTS = {
    on: true,          // signals on / off
    alerts: true,      // phone notification for a new signal
    pdh: true, orb: true, vwap: true, ema: true, absorb: true,
    rr1: 2,            // T1 at 2R
    rr2: 4,            // T2 at 4R
    maxSlPct: 25,      // option premium: stop never more than 25% away
    minFlow: 55,       // buyers must be at least 55% of the candle's volume (sellers for PE)
    maxPerDay: 4,      // at most 4 signals a day
    early: true,       // breakouts fire inside the candle (1-minute engine) instead of after it closes
    watch: true,       // ⚡ heads-up before price reaches a level
    earlyFlow: 60,     // early entry needs buyers (sellers) at least 60% of the last 2 minutes
  };
  // Breakout levels fire only on their FIRST break of the day; VWAP / EMA at most twice.
  const PER_DAY_LIMIT = { pdh: 1, pdl: 1, orbH: 1, orbL: 1, vwapUp: 2, vwapDn: 2, emaUp: 2, emaDn: 2, absorbUp: 2, absorbDn: 2 };

  const SETUP_NAMES = {
    pdh: 'Prev-day high breakout', pdl: 'Prev-day low breakdown',
    orbH: 'Opening-range breakout', orbL: 'Opening-range breakdown',
    vwapUp: 'VWAP reclaim', vwapDn: 'VWAP loss',
    emaUp: 'EMA 9/21 cross up', emaDn: 'EMA 9/21 cross down',
    absorbUp: 'Absorption reversal (sellers absorbed)', absorbDn: 'Absorption reversal (buyers absorbed)',
    wallUp: 'Call wall break', wallDn: 'Put wall break',
  };

  /* ---------- helpers ---------- */

  function atrSeries(bars, period) {
    const out = new Array(bars.length).fill(null);
    let prev = null;
    for (let i = 0; i < bars.length; i++) {
      const b = bars[i];
      const pc = i > 0 ? bars[i - 1].c : b.c;
      const tr = Math.max(b.h - b.l, Math.abs(b.h - pc), Math.abs(b.l - pc));
      prev = prev == null ? tr : (prev * (period - 1) + tr) / period;
      out[i] = prev;
    }
    return out;
  }

  // Opening range (09:15–09:30) per day from 1-minute candles: day -> {h, l}
  function openingRanges(raw) {
    const map = new Map();
    for (const b of raw) {
      const s = tod(b.t);
      if (s < 9 * 3600 + 15 * 60 || s >= T0930) continue;
      const d = Math.floor(b.t / DAY);
      const r = map.get(d);
      if (!r) map.set(d, { h: b.h, l: b.l });
      else { r.h = Math.max(r.h, b.h); r.l = Math.min(r.l, b.l); }
    }
    return map;
  }

  // Previous trading day high / low / close for every day present in raw candles
  function prevDayMap(raw) {
    const days = [];
    let cur = null;
    for (const b of raw) {
      const d = Math.floor(b.t / DAY);
      if (!cur || cur.d !== d) { cur = { d, h: b.h, l: b.l, c: b.c }; days.push(cur); }
      else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); cur.c = b.c; }
    }
    const map = new Map();
    for (let k = 1; k < days.length; k++) map.set(days[k].d, days[k - 1]);
    return map;
  }

  /* ---------- pattern markers ---------- */

  /*
   * absorb  : heavy one-sided LIVE flow but price went the other way (big player absorbing)
   * reject  : long wick on a wide candle (price rejected from a level)
   * div     : new 20-bar high/low in price that cumulative delta does not confirm
   */
  function patterns(bars, flow, cvd) {
    const out = [];
    if (bars.length < 5) return out;
    const avgRange = (i) => {
      let s = 0, n = 0;
      for (let k = Math.max(0, i - 20); k < i; k++) { s += bars[k].h - bars[k].l; n++; }
      return n ? s / n : 0;
    };
    const lastDiv = { 1: -99, '-1': -99 };
    for (let i = 1; i < bars.length; i++) {
      const b = bars[i];
      const range = b.h - b.l;
      const ar = avgRange(i);
      const f = flow && flow[i];

      if (f && !f.est && f.b + f.s > 0) {
        const d = (f.b - f.s) / (f.b + f.s);
        if (d >= 0.3 && b.c <= b.o) out.push({ i, type: 'absorb', dir: -1, text: 'Buyers absorbed' });
        else if (d <= -0.3 && b.c >= b.o) out.push({ i, type: 'absorb', dir: 1, text: 'Sellers absorbed' });
      }

      if (ar > 0 && range >= 1.3 * ar) {
        const lowerWick = Math.min(b.o, b.c) - b.l;
        const upperWick = b.h - Math.max(b.o, b.c);
        if (lowerWick >= 0.55 * range) out.push({ i, type: 'reject', dir: 1, text: 'Rejected lower prices' });
        else if (upperWick >= 0.55 * range) out.push({ i, type: 'reject', dir: -1, text: 'Rejected higher prices' });
      }

      if (cvd && cvd[i] != null && i >= 20) {
        let hiP = -Infinity, loP = Infinity, hiC = -Infinity, loC = Infinity, ok = true;
        const day = Math.floor(b.t / DAY);
        for (let k = i - 20; k < i; k++) {
          if (cvd[k] == null || Math.floor(bars[k].t / DAY) !== day) { ok = false; break; }
          hiP = Math.max(hiP, bars[k].h); loP = Math.min(loP, bars[k].l);
          hiC = Math.max(hiC, cvd[k]); loC = Math.min(loC, cvd[k]);
        }
        if (ok) {
          if (b.h > hiP && cvd[i] < hiC && i - lastDiv['-1'] > 5) { out.push({ i, type: 'div', dir: -1, text: 'New high without buyers (CVD)' }); lastDiv['-1'] = i; }
          if (b.l < loP && cvd[i] > loC && i - lastDiv[1] > 5) { out.push({ i, type: 'div', dir: 1, text: 'New low without sellers (CVD)' }); lastDiv[1] = i; }
        }
      }
    }
    return out;
  }

  /* ---------- signals ---------- */

  /*
   * ctx = {
   *   bars, raw (1-minute), flow, strip, ema9, ema21, vwap,
   *   kind: 'index' | 'option' | 'stock',  closed: number of closed bars,
   *   stripKind: 'option' | 'futures' | null, settings, tick
   * }
   * Returns { signals: [...], stats }
   */
  function signals(ctx) {
    const st = Object.assign({}, DEFAULTS, ctx.settings || {});
    const bars = ctx.bars;
    const n = Math.min(ctx.closed == null ? bars.length : ctx.closed, bars.length);
    const out = [];
    if (!st.on || n < 25) return { signals: out, stats: stats(out) };

    const atr = atrSeries(bars, 14);
    const pdm = prevDayMap(ctx.raw || bars);
    const orm = openingRanges(ctx.raw || []);
    const marks = patterns(bars, ctx.flow, null).filter((m) => m.type === 'absorb');
    const absorbAt = new Map(marks.map((m) => [m.i, m.dir]));
    const dirs = ctx.kind === 'index' ? [1, -1] : [1];
    const tick = ctx.tick || 0.05;
    let open = null, cool = -1;
    const used = new Map(); // "day|setup" -> times fired (or level already broken)
    const perDay = new Map();
    const bump = (key) => used.set(key, (used.get(key) || 0) + 1);

    for (let i = 1; i < n; i++) {
      const b = bars[i], p = bars[i - 1];

      // ---- manage an open trade on this bar
      if (open) {
        step(open, b, i, bars);
        if (open.status !== 'open') { cool = i + 2; open = null; }
        continue;
      }
      if (i <= cool) continue;
      const s = tod(b.t);
      if (s < T0930 || s > T1500 - 300) continue; // 09:30 – 14:55 only
      if (Math.floor(p.t / DAY) !== Math.floor(b.t / DAY)) continue; // no first bar of a day

      const day = Math.floor(b.t / DAY);
      const pd = pdm.get(day);
      const orb = orm.get(day);

      if ((perDay.get(day) || 0) >= st.maxPerDay) continue;

      for (const dir of dirs) {
        const crossed = (lvl) => lvl != null && (dir > 0 ? p.c <= lvl && b.c > lvl : p.c >= lvl && b.c < lvl);
        const fresh = (name) => (used.get(day + '|' + name) || 0) < PER_DAY_LIMIT[name];
        // A breakout level counts as "used" the first time price crosses it, signal or not.
        const brk = (name, lvl) => {
          if (!crossed(lvl)) return false;
          const ok = fresh(name);
          bump(day + '|' + name);
          return ok;
        };
        let setup = null;
        if (st.pdh && pd && brk(dir > 0 ? 'pdh' : 'pdl', dir > 0 ? pd.h : pd.l)) setup = dir > 0 ? 'pdh' : 'pdl';
        else if (st.orb && orb && brk(dir > 0 ? 'orbH' : 'orbL', dir > 0 ? orb.h : orb.l)) setup = dir > 0 ? 'orbH' : 'orbL';
        else if (st.vwap && ctx.vwap && ctx.vwap[i] != null && i >= 4 &&
          dir * (b.c - ctx.vwap[i]) > 0 &&
          [1, 2, 3].every((k) => ctx.vwap[i - k] != null && dir * (bars[i - k].c - ctx.vwap[i - k]) < 0)) setup = dir > 0 ? 'vwapUp' : 'vwapDn';
        else if (st.ema && ctx.ema9 && ctx.ema9[i] != null && ctx.ema21[i] != null && ctx.ema9[i - 1] != null && ctx.ema21[i - 1] != null &&
          dir * (ctx.ema9[i] - ctx.ema21[i]) > 0 && dir * (ctx.ema9[i - 1] - ctx.ema21[i - 1]) <= 0) setup = dir > 0 ? 'emaUp' : 'emaDn';
        else if (st.absorb && absorbAt.get(i - 1) === dir && dir * (b.c - (dir > 0 ? p.h : p.l)) > 0) setup = dir > 0 ? 'absorbUp' : 'absorbDn';
        if (!setup) continue;
        if (!/^(pdh|pdl|orb)/.test(setup)) { if (!fresh(setup)) continue; bump(day + '|' + setup); }

        // ---- confirmations
        const range = b.h - b.l;
        if (atr[i - 1] && range > 1.5 * atr[i - 1]) continue; // no chasing a candle that already ran
        if (!(dir * (b.c - b.o) > 0 && Math.abs(b.c - b.o) >= 0.4 * range)) continue; // strong candle in the trade's direction
        const f = ctx.flow && ctx.flow[i];
        let share = null;
        if (f && f.b + f.s > 0) {
          share = f.b / (f.b + f.s);
          const need = st.minFlow / 100;
          if (dir > 0 ? share < need : share > 1 - need) continue; // buyers / sellers must agree
        }
        const k = ctx.strip && ctx.strip[i] ? ctx.strip[i].kind : null;
        if (k) {
          // option chart (buying this option): writers adding against us = no trade
          if (ctx.stripKind === 'option' && k === 'WA') continue;
          if (ctx.stripKind === 'futures') {
            if (dir > 0 && (k === 'WA' || k === 'BE')) continue; // short buildup / long unwinding
            if (dir < 0 && (k === 'BA' || k === 'WE')) continue; // long buildup / short covering
          }
        }

        // ---- levels
        const a = atr[i] || range;
        const swing = dir > 0 ? Math.min(b.l, p.l, bars[i - 2] ? bars[i - 2].l : b.l) : Math.max(b.h, p.h, bars[i - 2] ? bars[i - 2].h : b.h);
        let risk = dir * (b.c - swing) + tick;
        risk = Math.max(risk, 0.3 * a);
        risk = Math.min(risk, 1.5 * a);
        if (ctx.kind === 'option') risk = Math.min(risk, b.c * st.maxSlPct / 100);
        if (!(risk > 0)) continue;
        const entry = b.c;
        const sig = {
          i, t: b.t, dir, setup, name: SETUP_NAMES[setup],
          entry, risk,
          sl: round(entry - dir * risk, tick), t1: round(entry + dir * st.rr1 * risk, tick), t2: round(entry + dir * st.rr2 * risk, tick),
          slNow: null, share, strip: k, status: 'open', t1Hit: false, exitI: null, exitPx: null, r: 0,
          rr1: st.rr1, rr2: st.rr2,
        };
        sig.slNow = sig.sl;
        out.push(sig);
        perDay.set(day, (perDay.get(day) || 0) + 1);
        open = sig;
        break;
      }
    }
    // a trade still open at the end of a past day (or after today's close) is closed at the last candle
    if (open && n > 0) {
      const last = bars[n - 1];
      if (ctx.sessionOver || Math.floor(last.t / DAY) !== Math.floor(open.t / DAY)) closeAt(open, n - 1, bars, 'eod');
    }
    return { signals: out, stats: stats(out) };
  }

  function round(v, tick) { return Math.round(v / tick) * tick; }

  // Walk one bar forward for an open trade. Stop is checked before targets (conservative).
  function step(sig, b, i, bars) {
    const prev = bars[i - 1];
    if (Math.floor(prev.t / DAY) !== Math.floor(b.t / DAY)) { closeAt(sig, i - 1, bars, 'eod'); return; }
    const d = sig.dir;
    const worst = d > 0 ? b.l : b.h;
    const best = d > 0 ? b.h : b.l;
    if (d * (worst - sig.slNow) <= 0) {
      sig.status = sig.t1Hit ? 'be' : 'sl';
      sig.exitI = i; sig.exitPx = sig.slNow;
      sig.r = sig.t1Hit ? sig.rr1 / 2 : -1; // half booked at T1, rest out at entry
      return;
    }
    if (!sig.t1Hit && d * (best - sig.t1) >= 0) { sig.t1Hit = true; sig.slNow = sig.entry; sig.t1I = i; }
    if (sig.t1Hit && d * (best - sig.t2) >= 0) {
      sig.status = 't2'; sig.exitI = i; sig.exitPx = sig.t2;
      sig.r = (sig.rr1 + sig.rr2) / 2;
    }
  }

  function closeAt(sig, i, bars, why) {
    const px = bars[i].c;
    const r = sig.dir * (px - sig.entry) / sig.risk;
    sig.status = why; sig.exitI = i; sig.exitPx = px;
    sig.r = sig.t1Hit ? (sig.rr1 + r) / 2 : r;
  }

  function stats(list) {
    const done = list.filter((s) => s.status !== 'open');
    const wins = done.filter((s) => s.r > 0).length;
    const total = done.reduce((a, s) => a + s.r, 0);
    return {
      count: list.length, closed: done.length, wins,
      winRate: done.length ? Math.round((wins / done.length) * 100) : null,
      avgR: done.length ? total / done.length : null, totalR: total,
      open: list.find((s) => s.status === 'open') || null,
    };
  }

  /* ---------- walls & magnets: WRITERS and BUYERS kept separate ---------- */

  /*
   * rows: [{strike, ce: S, pe: S}] with S = {oi, wa, we, ba, be, rwa, rwe, rba, rbe}
   *   wa/we = writers adding / exiting today, ba/be = buyers adding / exiting today (OI qty),
   *   r*    = the same for the last 15 minutes.
   * 🧱 Writer wall  = strike where WRITERS hold the most net OI (wa − we):
   *                  call writers at/above spot = resistance, put writers at/below spot = support.
   * 🧲 Buyer wall   = strike where BUYERS hold the most net OI (ba − be):
   *                  call buyers above spot pull price up, put buyers below pull it down.
   * Weakening = in the last 15 min writers exited more than they added at that strike.
   */
  function wallsAndMagnets(rows, spot) {
    const res = { walls: [], magnets: [], ladder: [] };
    if (!rows || !rows.length || !spot) return res;
    const net = (x, a, b) => (x ? Math.max(0, x[a] - x[b]) : 0);
    for (const r of rows) {
      res.ladder.push({
        strike: r.strike,
        ceW: net(r.ce, 'wa', 'we'), ceB: net(r.ce, 'ba', 'be'),
        peW: net(r.pe, 'wa', 'we'), peB: net(r.pe, 'ba', 'be'),
        ceOi: r.ce ? r.ce.oi : 0, peOi: r.pe ? r.pe.oi : 0,
      });
    }
    const writerWalls = (side, test, role) => rows
      .filter((r) => r[side] && test(r.strike) && net(r[side], 'wa', 'we') > 0)
      .sort((a, b) => net(b[side], 'wa', 'we') - net(a[side], 'wa', 'we'))
      .slice(0, 2)
      .forEach((r, rank) => {
        const x = r[side];
        const weak = x.rwe > x.rwa && x.rwe > 0.02 * net(x, 'wa', 'we');
        const building = x.rwa > x.rwe && x.rwa > 0.01 * net(x, 'wa', 'we');
        res.walls.push({ strike: r.strike, side, role, rank, writers: net(x, 'wa', 'we'), buyers: net(x, 'ba', 'be'), oi: x.oi, weak, building });
      });
    writerWalls('ce', (k) => k >= spot, 'resistance');
    writerWalls('pe', (k) => k <= spot, 'support');

    const buyerWall = (side, test, pull) => {
      const r = rows.filter((q) => q[side] && test(q.strike) && net(q[side], 'ba', 'be') > 0)
        .sort((a, b) => net(b[side], 'ba', 'be') - net(a[side], 'ba', 'be'))[0];
      if (!r) return;
      const x = r[side];
      res.magnets.push({ strike: r.strike, side, pull, buyers: net(x, 'ba', 'be'), writers: net(x, 'wa', 'we'),
        add: net(x, 'ba', 'be'), rising: x.rba > x.rbe });
    };
    buyerWall('ce', (k) => k > spot, 'up');
    buyerWall('pe', (k) => k < spot, 'down');
    return res;
  }

  // 1-minute candles with OI -> writers / buyers totals for the latest session day (+ last 15 minutes)
  function writerBuyerTotals(raw) {
    const out = { oi: 0, wa: 0, we: 0, ba: 0, be: 0, rwa: 0, rwe: 0, rba: 0, rbe: 0 };
    if (!raw || raw.length < 2) return out;
    const lastDay = Math.floor(raw[raw.length - 1].t / DAY);
    const lastT = raw[raw.length - 1].t;
    out.oi = raw[raw.length - 1].oi || 0;
    for (let i = 1; i < raw.length; i++) {
      const a = raw[i - 1], b = raw[i];
      if (Math.floor(b.t / DAY) !== lastDay || Math.floor(a.t / DAY) !== lastDay) continue;
      if (!a.oi || !b.oi) continue;
      const dOi = b.oi - a.oi, dP = b.c - a.c;
      if (dOi === 0 || dP === 0) continue;
      const k = dOi > 0 ? (dP < 0 ? 'wa' : 'ba') : (dP > 0 ? 'we' : 'be');
      out[k] += Math.abs(dOi);
      if (b.t > lastT - 15 * 60) out['r' + k] += Math.abs(dOi);
    }
    return out;
  }

  /* ---------- early breakouts on 1-minute data (fires inside the chart candle) ---------- */

  // 5-minute ATR for every 1-minute bar, using only completed 5-minute bars (no look-ahead)
  function atr5Map(raw) {
    const out = new Array(raw.length).fill(null);
    let cur = null, pc = null, atr = null;
    for (let i = 0; i < raw.length; i++) {
      const b = raw[i];
      const day = b.t - (b.t % DAY);
      const start = day + 9 * 3600 + 15 * 60;
      const k = start + Math.floor((b.t - start) / 300) * 300;
      if (!cur || cur.k !== k) {
        if (cur) {
          const tr = pc == null ? cur.h - cur.l : Math.max(cur.h - cur.l, Math.abs(cur.h - pc), Math.abs(cur.l - pc));
          atr = atr == null ? tr : (atr * 13 + tr) / 14;
          pc = cur.c;
        }
        cur = { k, h: b.h, l: b.l, c: b.c };
      } else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); cur.c = b.c; }
      out[i] = atr != null ? atr : Math.max(cur.h - cur.l, b.c * 0.0005);
    }
    return out;
  }

  /*
   * ctx = {
   *   raw: 1-minute candles (the last one may be the live, still-forming minute),
   *   live: true when the last candle is forming now,
   *   flowMin: Map(t -> [buyQty, sellQty]) real split from the live feed,
   *   volBars: 1-minute candles carrying volume for the estimated split (option / stock itself, or index future),
   *   oiMap: Map(t -> {kind}) writers / buyers per minute,
   *   walls: live walls [{strike, role, weak, rank}],
   *   kind, stripKind, settings, tick, sessionOver
   * }
   */
  function early(ctx) {
    const st = Object.assign({}, DEFAULTS, ctx.settings || {});
    const raw = ctx.raw || [];
    const n = raw.length;
    const res = { signals: [], watch: null };
    if (!st.on || !st.early || n < 30) return res;
    const pdm = prevDayMap(raw);
    const orm = openingRanges(raw);
    const a5 = atr5Map(raw);
    const volByT = ctx.volBars ? new Map(ctx.volBars.map((b) => [b.t, b])) : null;
    const tick = ctx.tick || 0.05;
    const dirs = ctx.kind === 'index' ? [1, -1] : [1];

    const flowAt = (i) => {
      const t = raw[i].t;
      const real = ctx.flowMin && ctx.flowMin.get(t);
      if (real && real[0] + real[1] > 0) return { b: real[0], s: real[1], est: false };
      const vb = volByT && volByT.get(t);
      if (vb && vb.v > 0) {
        const range = vb.h - vb.l;
        const share = range > 0 ? (vb.c - vb.l) / range : 0.5;
        return { b: vb.v * share, s: vb.v * (1 - share), est: true };
      }
      return null;
    };
    const shareOver = (i, k) => {
      let b = 0, s = 0, real = false;
      for (let j = Math.max(1, i - k + 1); j <= i; j++) {
        const f = flowAt(j);
        if (f) { b += f.b; s += f.s; real = real || !f.est; }
      }
      return b + s > 0 ? { share: b / (b + s), real } : null;
    };
    const kindAt = (i) => { const c = ctx.oiMap && ctx.oiMap.get(raw[i].t); return c ? c.kind : null; };
    const oiAgainst = (k, dir) => {
      if (!k) return false;
      if (ctx.stripKind === 'option') return k === 'WA';
      if (ctx.stripKind === 'futures') return dir > 0 ? (k === 'WA' || k === 'BE') : (k === 'BA' || k === 'WE');
      return false;
    };
    const levelsFor = (day, dir, i, isLive) => {
      const L = [];
      const pd = pdm.get(day), orb = orm.get(day);
      if (st.pdh && pd) L.push({ name: dir > 0 ? 'pdh' : 'pdl', lvl: dir > 0 ? pd.h : pd.l });
      if (st.orb && orb && tod(raw[i].t) >= T0930) L.push({ name: dir > 0 ? 'orbH' : 'orbL', lvl: dir > 0 ? orb.h : orb.l });
      if (isLive && ctx.walls) {
        for (const w of ctx.walls) {
          if (w.rank !== 0) continue;
          if (dir > 0 && w.role === 'resistance') L.push({ name: 'wall' + w.strike, lvl: w.strike, wall: true, weak: w.weak });
          if (dir < 0 && w.role === 'support') L.push({ name: 'wall' + w.strike, lvl: w.strike, wall: true, weak: w.weak });
        }
      }
      return L;
    };

    const used = new Set();
    const perDay = new Map();
    let open = null;

    for (let i = 1; i < n; i++) {
      const b = raw[i], p = raw[i - 1];
      const isLive = !!ctx.live && i === n - 1;
      const day = Math.floor(b.t / DAY);

      if (open) {
        step(open, b, i, raw);
        // fake breakout: a CLOSED minute back on the wrong side of the level within 3 minutes -> cancel
        if (open.status === 'open' && !isLive && i <= open.iRaw + 3 && open.dir * (b.c - open.level) < 0) {
          open.status = 'cancel'; open.exitI = i; open.exitPx = b.c;
          const r = open.dir * (b.c - open.entry) / open.risk;
          open.r = open.t1Hit ? (open.rr1 + r) / 2 : r;
        }
        if (open.status !== 'open') open = null;
        continue;
      }
      const s0 = tod(b.t);
      if (s0 < T0930 || s0 > T1500 - 300) continue;
      if (Math.floor(p.t / DAY) !== day) continue;
      if ((perDay.get(day) || 0) >= st.maxPerDay) continue;

      const atr = a5[i] || (b.h - b.l) * 3;
      let fired = false;
      for (const dir of dirs) {
        for (const L of levelsFor(day, dir, i, isLive)) {
          const crossed = dir > 0 ? p.c <= L.lvl && b.c > L.lvl : p.c >= L.lvl && b.c < L.lvl;
          if (!crossed) continue;
          const key = day + '|' + L.name;
          if (used.has(key)) continue;
          if (!isLive) used.add(key); // the live minute can still un-cross before it closes

          const fl = shareOver(i, 2);
          if (!fl) continue;
          const need = st.earlyFlow / 100;
          if (dir > 0 ? fl.share < need : fl.share > 1 - need) continue;
          if (oiAgainst(kindAt(i), dir) || oiAgainst(kindAt(i - 1), dir)) continue;

          let slDist = Math.max(0.5 * atr, b.c * (ctx.kind === 'option' ? 0.03 : 0.0006));
          const entry = b.c;
          // no chasing: entry must be close to the level, and this minute must not already be a huge candle
          if (dir * (entry - L.lvl) > 0.5 * slDist) continue;
          if (b.h - b.l > 1.5 * atr) continue;
          let risk = dir * (entry - (L.lvl - dir * slDist));
          if (ctx.kind === 'option') risk = Math.min(risk, entry * st.maxSlPct / 100);
          if (!(risk > 0)) continue;
          const setup = L.wall ? (dir > 0 ? 'wallUp' : 'wallDn') : L.name;
          const sig = {
            i: null, iRaw: i, t: b.t, dir, setup, mode: 'early', level: L.lvl, live: isLive,
            name: (L.wall ? `Wall ${L.lvl} break` : SETUP_NAMES[L.name]) + ' (early)',
            entry, risk,
            sl: round(entry - dir * risk, tick), t1: round(entry + dir * st.rr1 * risk, tick), t2: round(entry + dir * st.rr2 * risk, tick),
            share: fl.share, flowReal: fl.real, strip: kindAt(i), status: 'open', t1Hit: false, exitI: null, exitPx: null, r: 0,
            rr1: st.rr1, rr2: st.rr2,
          };
          sig.slNow = sig.sl;
          res.signals.push(sig);
          perDay.set(day, (perDay.get(day) || 0) + 1);
          open = sig;
          fired = true;
          break;
        }
        if (fired) break;
      }

      // ⚡ watch: live minute, price just short of a level with buyers (sellers) already in control
      if (!fired && isLive && st.watch && !open) {
        let best = null;
        for (const dir of dirs) {
          for (const L of levelsFor(day, dir, i, true)) {
            if (used.has(day + '|' + L.name)) continue;
            const gap = dir * (L.lvl - b.c);
            if (!(gap > 0) || gap > Math.max(b.c * 0.0012, 0.35 * atr)) continue;
            const fl = shareOver(i, 3);
            if (!fl) continue;
            if (dir > 0 ? fl.share < 0.6 : fl.share > 0.4) continue;
            if (!best || gap < best.gap) best = { dir, name: L.name, level: L.lvl, wall: !!L.wall, weak: !!L.weak, gap, share: fl.share, real: fl.real, price: b.c, t: b.t };
          }
        }
        res.watch = best;
      }
    }
    if (open && (ctx.sessionOver || Math.floor(raw[n - 1].t / DAY) !== Math.floor(open.t / DAY))) closeAt(open, n - 1, raw, 'eod');
    for (const sg of res.signals) sg.exitT = sg.exitI != null ? raw[sg.exitI].t : null;
    return res;
  }

  const api = { DEFAULTS, SETUP_NAMES, patterns, signals, early, stats, wallsAndMagnets, writerBuyerTotals, atrSeries, openingRanges, prevDayMap };
  if (typeof window !== 'undefined') window.EVSignals = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
