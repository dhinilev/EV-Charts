/*
 * EV Charts — orders from the chart (v2.0).
 *
 *  • A buy call (or the Trade button) opens a small order window above the chart:
 *    lots (from your capital), limit price, stop-loss, floating stop-loss.
 *  • Nothing is sent until you tap the BUY button. Then the BUY limit order goes to
 *    Kotak Neo / Flattrade (or the Paper practice broker).
 *  • When the buy fills, a SELL stop-loss (SL-LMT) is placed at the broker. The entry, the
 *    stop-loss and the P&L show on the chart. Drag the SL line to move it — the broker's
 *    order is modified. The floating stop-loss moves it up by itself and modifies the order.
 *
 * Pure helpers are exported on EVTrade._t so they can be tested in Node.
 */
(function (root) {
  'use strict';

  const TICK = 0.05;
  const r2 = (v) => Math.round(v * 100) / 100;
  /** round to the 0.05 option tick: dir > 0 up, dir < 0 down, 0 nearest */
  function roundTick(v, dir) {
    const n = v / TICK;
    const k = dir > 0 ? Math.ceil(n - 1e-9) : dir < 0 ? Math.floor(n + 1e-9) : Math.round(n);
    return r2(k * TICK);
  }
  /** whole lots the capital can buy */
  function maxLots(capital, price, lot) {
    if (!(capital > 0 && price > 0 && lot > 0)) return 0;
    return Math.floor(capital / (price * lot) + 1e-9);
  }
  /** Floating SL: every time price is `trig` points above the SL, the SL moves up `step` points. Never moves down. */
  function trailSl(sl, ltp, trig, step) {
    if (!(trig > 0 && step > 0) || !(ltp > 0)) return sl;
    let out = sl, n = 0;
    while (ltp - out >= trig - 1e-9 && n < 400) { out += step; n++; }
    if (n === 0) return sl;
    out = Math.min(out, ltp - 1);                    // never closer than 1 point to the price
    out = roundTick(out, -1);
    return out > sl ? out : sl;
  }
  const isDone = (s) => /COMPLETE|TRADED|FILLED/i.test(s || '');
  const isRej = (s) => /REJECT/i.test(s || '');
  const isCan = (s) => /CANCEL/i.test(s || '');

  const SUPPORTED = { NIFTY: 1, SENSEX: 1 };
  const DEFAULTS = {
    broker: 'kn', capital: 0, prod: 'I', buyBuf: 0.5, slBuf: 3, trailOn: true, trailTrig: 10, trailStep: 5, autoOpen: true,
  };

  /* ------------------------------------------------------------------ */
  /* Paper broker — practice orders, filled from the live premium        */
  /* ------------------------------------------------------------------ */
  function createPaper(store) {
    const P = { name: 'Paper', orders: store.get('paper.orders', []), seq: store.get('paper.seq', 1000), ltp: {} };
    const save = () => { store.set('paper.orders', P.orders.slice(-60)); store.set('paper.seq', P.seq); };
    function evaluate() {
      for (const o of P.orders) {
        if (o.status !== 'OPEN' && o.status !== 'TRIGGER_PENDING') continue;
        const l = P.ltp[o.tsym]; if (!(l > 0)) continue;
        if (o.type === 'LMT') {
          if (o.side === 'B' && l <= o.prc + 1e-9) { o.status = 'COMPLETE'; o.fill = o.qty; o.avg = l; }
          if (o.side === 'S' && l >= o.prc - 1e-9) { o.status = 'COMPLETE'; o.fill = o.qty; o.avg = l; }
        } else if (o.type === 'SL-LMT' && o.side === 'S') {
          if (l <= o.trg + 1e-9) {
            if (l >= o.prc - 1e-9) { o.status = 'COMPLETE'; o.fill = o.qty; o.avg = l; }
            else o.status = 'OPEN';                       // price gapped through the limit: stays open, like a real exchange
          }
        }
      }
    }
    P.configured = () => true;
    P.ready = () => true;
    P.status = () => 'Practice mode · no real orders are sent';
    P.feed = (tsym, ltp) => { P.ltp[tsym] = ltp; evaluate(); save(); };
    P.contract = async (und, iso, strike, side) => ({ exch: 'PAPER', token: '', tsym: `${und} ${iso} ${strike} ${side}`, ls: 0 });
    P.placeOrder = async (o) => {
      const no = 'P' + (++P.seq);
      P.orders.push({ no, tsym: o.tsym, side: o.trantype === 'S' ? 'S' : 'B', qty: o.qty, fill: 0, prc: Number(o.prc) || 0, trg: Number(o.trgprc) || 0, avg: 0, type: o.prctyp, prd: o.prd,
        status: o.prctyp === 'SL-LMT' ? 'TRIGGER_PENDING' : 'OPEN', why: '', ts: new Date().toISOString() });
      evaluate(); save();
      return { ok: true, no };
    };
    P.modifyOrder = async (o) => {
      const x = P.orders.find((y) => y.no === String(o.no));
      if (!x || x.status === 'COMPLETE' || x.status === 'CANCELED') return { ok: false, err: 'Order is not open' };
      x.prc = Number(o.prc) || x.prc; x.trg = Number(o.trgprc) || x.trg; x.qty = o.qty || x.qty;
      if (x.type === 'SL-LMT') x.status = 'TRIGGER_PENDING';
      evaluate(); save();
      return { ok: true, no: x.no };
    };
    P.cancelOrder = async (no) => {
      const x = P.orders.find((y) => y.no === String(no));
      if (!x || x.status === 'COMPLETE') return { ok: false, err: 'Order is not open' };
      x.status = 'CANCELED'; save();
      return { ok: true };
    };
    P.orderBook = async () => ({ at: Date.now(), list: P.orders.map((o) => Object.assign({}, o)) });
    return P;
  }

  /* ------------------------------------------------------------------ */
  /* Module                                                              */
  /* ------------------------------------------------------------------ */
  const EVTrade = { _t: { roundTick, maxLots, trailSl, createPaper, isDone, isRej, isCan, DEFAULTS } };
  root.EVTrade = EVTrade;

  EVTrade.init = async function init(A) {
    if (EVTrade.ready) return;
    EVTrade.ready = true;
    const EV = root.EV;
    const D = A.D;
    const $ = (id) => document.getElementById(id);
    const fmt = A.fmt;
    const inr = (v) => '₹' + Math.round(v).toLocaleString('en-IN');
    const sgn = (v, d) => (v >= 0 ? '+' : '−') + Math.abs(v).toFixed(d == null ? 1 : d);

    /* ---------- storage: secrets go to the phone's encrypted store ---------- */
    const SECRET_KEYS = ['oi.kn.cfg', 'oi.kn.sess', 'oi.ft.cfg', 'oi.ft.sess'];
    const sec = {};
    if (EV.native) {
      try { Object.assign(sec, await EV.call('secGetMany', { keys: SECRET_KEYS })); } catch (e) { /* start empty */ }
    }
    const store = {
      get(k, d) {
        try {
          if (EV.native && SECRET_KEYS.includes(k)) { const v = sec[k]; return v == null || v === '' ? d : JSON.parse(v); }
          const v = localStorage.getItem('evc.' + k); return v == null ? d : JSON.parse(v);
        } catch (e) { return d; }
      },
      set(k, v) {
        try {
          if (EV.native && SECRET_KEYS.includes(k)) {
            const s = v == null ? '' : JSON.stringify(v); sec[k] = s;
            EV.call('secSet', { key: k, value: s }).catch(() => {});
          } else localStorage.setItem('evc.' + k, JSON.stringify(v));
        } catch (e) { /* ignore */ }
      },
    };

    /* ---------- broker plumbing ---------- */
    const Core = {
      istParts(ms) { const d = new Date(ms + 5.5 * 3600 * 1000); return { y: d.getUTCFullYear(), mo: d.getUTCMonth() + 1, d: d.getUTCDate(), h: d.getUTCHours(), mi: d.getUTCMinutes(), s: d.getUTCSeconds(), wd: d.getUTCDay() }; },
      istDate(ms) { const p = Core.istParts(ms); return `${p.y}-${String(p.mo).padStart(2, '0')}-${String(p.d).padStart(2, '0')}`; },
    };
    const http = (method, url, headers, body) => EV.call('http', { method, url, headers: headers || {}, body: body || '' })
      .then((r) => ({ status: r.status, text: r.text }))
      .catch((e) => ({ status: 0, text: 'Network error: ' + (e && e.message || e) }));
    const csvGet = (url, regex) => EV.call('httpCsv', { url, headers: {}, regex })
      .then((r) => ({ status: r.status, text: r.text }))
      .catch((e) => ({ status: 0, text: 'Network error: ' + (e && e.message || e) }));
    const sha256 = (text) => EV.call('sha256', { text }).then((r) => r.hex).catch(() => '');
    let loginWait = null;
    EV.on('ftlogin', (p) => { if (loginWait) { const w = loginWait; loginWait = null; w(p || {}); } });
    const openLogin = (url, redirect) => new Promise((resolve) => {
      loginWait = resolve;
      EV.call('ftLogin', { url, redirect }).catch((e) => { loginWait = null; resolve({ error: e.message }); });
    });

    const KN = root.createKN({ http, store, Core, csvGet });
    const FT = root.createFT({ http, store, Core, sha256, openLogin });
    const PAPER = createPaper(store);
    const BROKERS = { kn: KN, ft: FT, paper: PAPER };
    const brokerOf = (id) => BROKERS[id] || KN;

    /* ---------- settings ---------- */
    let cfg = Object.assign({}, DEFAULTS, store.get('trade.cfg', {}));
    const saveCfg = () => store.set('trade.cfg', cfg);
    const num = (v, d) => { const n = parseFloat(v); return isFinite(n) ? n : d; };

    /* ---------- state ---------- */
    let T = store.get('trade.active', null);     // the one managed trade
    let W = null;                                // the open order window
    let polling = false, pollTimer = null, modifying = false, lastModifyAt = 0, failUntil = 0, exitArmed = 0;
    const saveT = () => store.set('trade.active', T);

    const say = (title, text) => { EV.call('notify', { title, text }).catch(() => {}); A.toast(title + (text ? ' · ' + text : ''), 5000); };

    /* ================================================================== */
    /* Settings UI                                                         */
    /* ================================================================== */
    function buildSettings() {
      const host = $('ordSettings'); if (!host) return;
      host.innerHTML = `
        <h3>Orders</h3>
        <p class="hint">Orders go to Kotak Neo or Flattrade only when you tap <b>BUY</b> in the order window. Chart data still comes from HDFC Sky.</p>
        <div class="field"><label for="ord_broker">Order broker</label>
          <select id="ord_broker"><option value="kn">Kotak Neo</option><option value="ft">Flattrade</option><option value="paper">Paper (practice — no real orders)</option></select></div>
        <div class="grid2">
          <div class="field"><label for="ord_capital">Capital for orders (₹)</label><input id="ord_capital" type="number" inputmode="decimal" step="1000"></div>
          <div class="field"><label for="ord_prod">Product</label><select id="ord_prod"><option value="I">MIS (intraday)</option><option value="M">NRML</option></select></div>
          <div class="field"><label for="ord_buyBuf">Buy limit above LTP (pts)</label><input id="ord_buyBuf" type="number" inputmode="decimal" step="0.05"></div>
          <div class="field"><label for="ord_slBuf">SL limit below trigger (pts)</label><input id="ord_slBuf" type="number" inputmode="decimal" step="0.05"></div>
          <div class="field"><label for="ord_trig">Floating SL: price this far above SL (pts)</label><input id="ord_trig" type="number" inputmode="decimal" step="0.5"></div>
          <div class="field"><label for="ord_step">…then move the SL up by (pts)</label><input id="ord_step" type="number" inputmode="decimal" step="0.5"></div>
        </div>
        <div class="checks">
          <label><input type="checkbox" id="ord_trailOn"> Floating stop-loss on by default</label>
          <label><input type="checkbox" id="ord_auto"> Open the order window when a buy call comes</label>
        </div>
        <div class="btn-row"><button class="btn" id="ord_save">Save order settings</button></div>

        <h3>Kotak Neo</h3>
        <div class="status-list"><div><span>Status</span><span id="kn_status">—</span></div></div>
        <div class="field"><label for="kn_key">Consumer key</label><input id="kn_key" autocomplete="off" spellcheck="false"></div>
        <div class="grid2">
          <div class="field"><label for="kn_mobile">Mobile</label><input id="kn_mobile" inputmode="tel" autocomplete="off"></div>
          <div class="field"><label for="kn_ucc">Client code (UCC)</label><input id="kn_ucc" autocomplete="off" autocapitalize="characters"></div>
          <div class="field"><label for="kn_totp">TOTP (6 digits)</label><input id="kn_totp" inputmode="numeric" autocomplete="off" maxlength="6"></div>
          <div class="field"><label for="kn_mpin">MPIN</label><input id="kn_mpin" type="password" inputmode="numeric" autocomplete="off" maxlength="6"></div>
        </div>
        <p class="hint">Log in once each trading day. The TOTP and MPIN are never saved.</p>
        <div class="btn-row"><button class="btn" id="kn_login">Login to Kotak Neo</button><button class="btn ghost" id="kn_logout">Logout</button></div>

        <h3>Flattrade</h3>
        <div class="status-list"><div><span>Status</span><span id="ft_status">—</span></div></div>
        <div class="grid2">
          <div class="field"><label for="ft_uid">Client ID</label><input id="ft_uid" autocomplete="off" autocapitalize="characters"></div>
          <div class="field"><label for="ft_key">API key</label><input id="ft_key" autocomplete="off" spellcheck="false"></div>
        </div>
        <div class="field"><label for="ft_secret">API secret</label><input id="ft_secret" type="password" autocomplete="off" spellcheck="false" placeholder="Saved — leave blank to keep"></div>
        <div class="field"><label for="ft_redirect">Redirect URL (as set in your Flattrade API app)</label><input id="ft_redirect" autocomplete="off" spellcheck="false"></div>
        <div class="btn-row"><button class="btn" id="ft_login">Login to Flattrade</button><button class="btn ghost" id="ft_logout">Logout</button></div>
        <p class="hint">Your phone's IP must be the one registered with the broker's API. Keys are kept encrypted on this phone only.</p>`;
      const set = (id, v) => { $(id).value = v == null ? '' : v; };
      const fill = () => {
        set('ord_broker', cfg.broker); set('ord_capital', cfg.capital || ''); set('ord_prod', cfg.prod);
        set('ord_buyBuf', cfg.buyBuf); set('ord_slBuf', cfg.slBuf); set('ord_trig', cfg.trailTrig); set('ord_step', cfg.trailStep);
        $('ord_trailOn').checked = !!cfg.trailOn; $('ord_auto').checked = !!cfg.autoOpen;
        set('kn_key', KN.cfg.key); set('kn_mobile', KN.cfg.mobile); set('kn_ucc', KN.cfg.ucc);
        set('ft_uid', FT.cfg.uid); set('ft_key', FT.cfg.key); set('ft_redirect', FT.cfg.redirect || FT.REDIRECT);
        status();
      };
      const status = () => {
        $('kn_status').textContent = KN.status();
        $('ft_status').textContent = FT.status();
        $('kn_logout').disabled = !KN.ready(); $('ft_logout').disabled = !FT.ready();
      };
      EVTrade.refreshSettings = fill;
      $('ord_save').onclick = () => {
        cfg = Object.assign(cfg, {
          broker: $('ord_broker').value, capital: Math.max(0, num($('ord_capital').value, 0)), prod: $('ord_prod').value,
          buyBuf: Math.max(0, num($('ord_buyBuf').value, DEFAULTS.buyBuf)), slBuf: Math.max(0, num($('ord_slBuf').value, DEFAULTS.slBuf)),
          trailTrig: Math.max(0.5, num($('ord_trig').value, DEFAULTS.trailTrig)), trailStep: Math.max(0.5, num($('ord_step').value, DEFAULTS.trailStep)),
          trailOn: $('ord_trailOn').checked, autoOpen: $('ord_auto').checked,
        });
        saveCfg();
        A.toast(`Order settings saved · ${brokerOf(cfg.broker).name}${cfg.capital ? ' · capital ' + inr(cfg.capital) : ' · capital not set'}`);
      };
      $('kn_login').onclick = async () => {
        KN.saveCfg({ key: $('kn_key').value.trim() });
        const b = $('kn_login'); b.disabled = true; b.textContent = 'Logging in…';
        try {
          await KN.login($('kn_mobile').value, $('kn_ucc').value, $('kn_totp').value, $('kn_mpin').value);
          $('kn_totp').value = ''; $('kn_mpin').value = '';
          A.toast('Kotak Neo logged in for today');
        } catch (e) { A.toast((e && e.msg) || String(e), 5000); }
        b.disabled = false; b.textContent = 'Login to Kotak Neo'; status();
      };
      $('kn_logout').onclick = () => { KN.logout(); status(); A.toast('Kotak Neo logged out'); };
      $('ft_login').onclick = async () => {
        const redirect = $('ft_redirect').value.trim() || FT.REDIRECT;
        const patch = { uid: $('ft_uid').value.trim().toUpperCase(), key: $('ft_key').value.trim(), redirect };
        const sc = $('ft_secret').value.trim(); if (sc) patch.secret = sc;
        FT.saveCfg(patch); $('ft_secret').value = '';
        const b = $('ft_login'); b.disabled = true; b.textContent = 'Logging in…';
        try { await FT.login(); A.toast('Flattrade logged in for today'); }
        catch (e) { A.toast((e && e.msg) || String(e), 5000); }
        b.disabled = false; b.textContent = 'Login to Flattrade'; status();
      };
      $('ft_logout').onclick = () => { FT.logout(); status(); A.toast('Flattrade logged out'); };
      fill();
    }

    /* ================================================================== */
    /* Order window                                                        */
    /* ================================================================== */
    const win = document.createElement('div');
    win.id = 'ordWin'; win.className = 'ord-win'; win.hidden = true;
    win.innerHTML = `
      <div class="ow-hd"><b id="ow_title">—</b><select id="ow_broker" aria-label="Broker"><option value="kn">Kotak Neo</option><option value="ft">Flattrade</option><option value="paper">Paper</option></select><button class="ow-x" id="ow_x" aria-label="Close">✕</button></div>
      <div class="ow-seg" id="ow_sideRow" hidden><button id="ow_ce" class="ce">CE</button><button id="ow_pe" class="pe">PE</button></div>
      <div class="ow-info" id="ow_info"></div>
      <div class="ow-grid">
        <div class="ow-f"><label>Lots</label><div class="ow-st"><button id="ow_lm">−</button><input id="ow_lots" type="number" inputmode="numeric" min="1" step="1"><button id="ow_lp">+</button></div></div>
        <div class="ow-f"><label>Buy price</label><div class="ow-st"><button id="ow_pm">−</button><input id="ow_price" type="number" inputmode="decimal" step="0.05"><button id="ow_pp">+</button></div></div>
        <div class="ow-f"><label>Stop-loss</label><div class="ow-st"><button id="ow_sm">−</button><input id="ow_sl" type="number" inputmode="decimal" step="0.05"><button id="ow_sp">+</button></div></div>
      </div>
      <div class="ow-sum" id="ow_sum"></div>
      <label class="ow-trail"><input type="checkbox" id="ow_trail"> Floating SL: every <input id="ow_trig" type="number" inputmode="decimal" step="0.5"> pts above SL → SL up <input id="ow_step" type="number" inputmode="decimal" step="0.5"> pts</label>
      <div class="ow-msg" id="ow_msg"></div>
      <div class="ow-btns"><button class="btn buy" id="ow_buy">BUY</button><button class="btn ghost" id="ow_cancel">Cancel</button></div>`;
    const bar = document.createElement('div');
    bar.id = 'tradeBar'; bar.className = 'trade-bar'; bar.hidden = true;
    const wrap = $('chartWrap') || document.body;
    wrap.appendChild(bar);
    document.body.appendChild(win);
    const q = (id) => $(id);

    function closeWindow() { if (W && W.timer) clearInterval(W.timer); W = null; win.hidden = true; }
    const winAge = () => (W ? Math.floor((Date.now() - W.openedAt) / 1000) : 0);

    function recalc() {
      if (!W) return;
      const lots = Math.max(0, Math.floor(num(q('ow_lots').value, 0)));
      const price = num(q('ow_price').value, 0), sl = num(q('ow_sl').value, 0);
      const units = lots * W.lot, cost = units * price, risk = Math.max(0, (price - sl) * units);
      const mx = maxLots(cfg.capital, price, W.lot);
      W.lots = lots; W.price = price; W.sl = sl;
      let info = `LTP <b>${fmt(W.ltp, 2)}</b> · Lot ${W.lot}`;
      if (cfg.capital > 0) info += ` · Capital ${inr(cfg.capital)} → <b>max ${mx} lot${mx === 1 ? '' : 's'}</b> (${mx * W.lot} units)`;
      else info += ' · <span class="warn">set your capital in Settings → Orders</span>';
      q('ow_info').innerHTML = info;
      q('ow_sum').innerHTML = `${units} units · cost <b>${inr(cost)}</b> · risk to SL <b class="dn">${inr(risk)}</b> (${fmt(Math.max(0, price - sl), 2)} pts)`;
      const trig = num(q('ow_trig').value, cfg.trailTrig), step = num(q('ow_step').value, cfg.trailStep);
      let err = '';
      const B = brokerOf(q('ow_broker').value);
      if (!B.ready()) err = `Log in to ${B.name} first (Settings → Orders).`;
      else if (T) err = 'A trade is already open. Finish or close it first.';
      else if (!(lots >= 1)) err = 'Lots must be 1 or more.';
      else if (cfg.capital > 0 && lots > mx) err = `Over your capital: it allows ${mx} lot${mx === 1 ? '' : 's'}.`;
      else if (!(price > 0)) err = 'Enter a buy price.';
      else if (!(sl > 0) || sl >= price) err = 'Stop-loss must be below the buy price.';
      else if (q('ow_trail').checked && (trig <= 0 || step <= 0)) err = 'Floating SL needs both point values.';
      else if (W.und && !SUPPORTED[W.und]) err = 'Orders cover NIFTY and SENSEX options.';
      q('ow_msg').textContent = err || (winAge() > 120 ? 'This call is getting old — check the price.' : '');
      q('ow_msg').className = 'ow-msg' + (err ? ' err' : '');
      q('ow_buy').disabled = !!err || W.placing;
      q('ow_buy').textContent = W.placing ? 'Sending…' : `BUY ${lots} lot${lots === 1 ? '' : 's'} @ ${fmt(price, 2)}`;
    }

    async function ltpOf(item) {
      try {
        const r = await EV.call('ltp', { items: [item] });
        return r && r[0] && r[0].ltp > 0 ? r[0].ltp : null;
      } catch (e) { return null; }
    }

    /** the option to trade, from the current chart (an option, or an index → ATM option) */
    async function resolveOption(c) {
      const inst = c.inst;
      if (inst && inst.kind === 'option') {
        return { und: inst.und, expiry: inst.expiry, strike: inst.strike, side: inst.side, lot: inst.lot || 1, title: inst.title,
          ltpItem: { exchange: inst.ltpExchange, token: inst.token, symbol: inst.chartSymbols[0] } };
      }
      const und = inst && inst.key;
      if (!und || !SUPPORTED[und]) throw new Error('Orders cover NIFTY and SENSEX options.');
      const exps = await EV.call('optionExpiries', { underlying: und });
      const today = D.ymd(D.istNow());
      const expiry = (exps || []).find((e) => e >= today) || (exps || [])[0];
      if (!expiry) throw new Error('No expiry found for ' + und);
      const chain = await EV.call('optionChain', { underlying: und, expiry });
      let spot = c.spot;
      if (!spot) spot = await ltpOf({ exchange: inst.ltpExchange, token: inst.token, symbol: inst.chartSymbols[0] });
      if (!spot && c.sg) spot = c.sg.entry;
      if (!spot) throw new Error('Could not read the index price.');
      const rows = chain.strikes || [];
      let row = rows[0];
      for (const r of rows) if (Math.abs(r.strike - spot) < Math.abs(row.strike - spot)) row = r;
      return { und, expiry, strike: row.strike, lot: chain.lot || 1, rows, exchange: chain.exchange, spot, chainOf: chain };
    }
    function legOf(o, side) {
      const row = (o.rows || []).find((r) => r.strike === o.strike);
      const leg = row && (side === 'CE' ? row.ce : row.pe);
      if (!leg) throw new Error(`No ${side} at ${o.strike}`);
      const d = new Date(o.expiry + 'T00:00:00Z');
      const exp = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', timeZone: 'UTC' });
      return { side, title: `${o.und} ${exp} ${o.strike} ${side}`, ltpItem: { exchange: o.exchange, token: leg.token, symbol: leg.symbol } };
    }

    async function openWindow(c) {
      if (T) { A.toast('A trade is already open — finish it before a new order.'); return; }
      if (W) closeWindow();
      let o;
      try { o = await resolveOption(c); } catch (e) { A.toast(e.message, 4500); return; }
      const index = !(c.inst && c.inst.kind === 'option');
      let side = o.side || (c.dir < 0 ? 'PE' : 'CE');
      let leg = o;
      if (index) { try { leg = Object.assign({}, o, legOf(o, side)); } catch (e) { A.toast(e.message, 4500); return; } }
      const ltp = await ltpOf(leg.ltpItem);
      if (!ltp) { A.toast('Could not read the option price. Try again in a moment.', 4500); return; }
      W = { c, o, index, side, und: o.und, expiry: o.expiry, strike: o.strike, lot: o.lot, title: leg.title, ltpItem: leg.ltpItem, ltp,
        openedAt: Date.now(), placing: false, sgKey: c.key || '', touched: { price: false, sl: false } };
      // defaults: price a little above LTP; SL from the call (option chart) or from scalp points
      const pts = (A.S.push && A.S.push.scalp && A.S.push.sSL) ? A.S.push.sSL : 4;
      const price = roundTick(ltp + cfg.buyBuf, 1);
      let sl = null;
      if (!index && c.sg && c.sg.sl > 0 && c.sg.sl < price - 0.5) sl = c.sg.sl;
      if (sl == null && index && c.sg && c.sg.risk > 0 && !(A.S.push && A.S.push.scalp)) sl = price - c.sg.risk * 0.5;
      if (sl == null) sl = price - pts;
      sl = Math.max(TICK, roundTick(sl, 0));
      const mx = maxLots(cfg.capital, price, o.lot);
      q('ow_title').textContent = (c.sg && c.sg.label ? `${c.sg.dir > 0 ? '▲' : '▼'} ` : '') + 'BUY ' + leg.title;
      q('ow_broker').value = cfg.broker;
      q('ow_sideRow').hidden = !index;
      q('ow_ce').classList.toggle('active', side === 'CE'); q('ow_pe').classList.toggle('active', side === 'PE');
      q('ow_lots').value = mx >= 1 ? mx : 1;
      q('ow_price').value = price.toFixed(2); q('ow_sl').value = sl.toFixed(2);
      q('ow_trail').checked = !!cfg.trailOn; q('ow_trig').value = cfg.trailTrig; q('ow_step').value = cfg.trailStep;
      win.hidden = false;
      recalc();
      W.timer = setInterval(async () => {          // keep the price fresh; close a stale call
        if (!W) return;
        if (winAge() > 180) { closeWindow(); A.toast('Order window closed — the call was over 3 minutes old.'); return; }
        const l = await ltpOf(W.ltpItem);
        if (W && l) { W.ltp = l; if (!W.touched.price) q('ow_price').value = roundTick(l + cfg.buyBuf, 1).toFixed(2); recalc(); }
      }, 2500);
    }

    async function switchSide(side) {
      if (!W || !W.index || W.side === side) return;
      try {
        const leg = legOf(W.o, side);
        W.side = side; W.title = leg.title; W.ltpItem = leg.ltpItem;
        q('ow_title').textContent = 'BUY ' + leg.title;
        q('ow_ce').classList.toggle('active', side === 'CE'); q('ow_pe').classList.toggle('active', side === 'PE');
        const l = await ltpOf(leg.ltpItem); if (l) W.ltp = l;
        const price = roundTick(W.ltp + cfg.buyBuf, 1);
        const pts = (A.S.push && A.S.push.scalp && A.S.push.sSL) ? A.S.push.sSL : 4;
        q('ow_price').value = price.toFixed(2); q('ow_sl').value = Math.max(TICK, roundTick(price - pts, 0)).toFixed(2);
        W.touched = { price: false, sl: false };
        recalc();
      } catch (e) { A.toast(e.message, 4000); }
    }

    // window wiring
    const stepBtn = (btn, input, delta, min) => { q(btn).onclick = () => { const v = num(q(input).value, 0) + delta; q(input).value = (Math.max(min, v)).toFixed(delta % 1 ? 2 : 0); if (W && input === 'ow_price') W.touched.price = true; if (W && input === 'ow_sl') W.touched.sl = true; recalc(); }; };
    stepBtn('ow_lm', 'ow_lots', -1, 1); stepBtn('ow_lp', 'ow_lots', 1, 1);
    stepBtn('ow_pm', 'ow_price', -0.5, 0.05); stepBtn('ow_pp', 'ow_price', 0.5, 0.05);
    stepBtn('ow_sm', 'ow_sl', -0.5, 0.05); stepBtn('ow_sp', 'ow_sl', 0.5, 0.05);
    ['ow_lots', 'ow_price', 'ow_sl', 'ow_trig', 'ow_step'].forEach((id) => { q(id).oninput = () => { if (W && id === 'ow_price') W.touched.price = true; if (W && id === 'ow_sl') W.touched.sl = true; recalc(); }; });
    q('ow_trail').onchange = recalc;
    q('ow_broker').onchange = recalc;
    q('ow_ce').onclick = () => switchSide('CE'); q('ow_pe').onclick = () => switchSide('PE');
    q('ow_x').onclick = closeWindow; q('ow_cancel').onclick = closeWindow;
    q('ow_buy').onclick = confirmBuy;

    async function confirmBuy() {
      if (!W || W.placing) return;
      recalc();
      if (q('ow_buy').disabled) return;
      const brokerId = q('ow_broker').value, B = brokerOf(brokerId);
      const w = W; w.placing = true; recalc();
      try {
        const k = await B.contract(w.und, w.expiry, w.strike, w.side);
        const ls = k.ls || w.lot;
        const lots = w.lots, qty = lots * ls;
        const price = roundTick(w.price, 0), sl = roundTick(w.sl, 0);
        const r = await B.placeOrder({ exch: k.exch, tsym: k.tsym, qty, prc: price, prctyp: 'LMT', prd: cfg.prod, trantype: 'B', trgprc: 0 });
        if (!r || !r.ok) throw new Error((r && r.err) || 'The broker did not accept the order');
        T = { id: Date.now(), broker: brokerId, und: w.und, expiry: w.expiry, strike: w.strike, side: w.side, title: w.title, ltpItem: w.ltpItem,
          exch: k.exch, tsym: k.tsym, token: w.ltpItem.token, lot: ls, lots, qty, prd: cfg.prod, price, avg: null, ltp: w.ltp, sl,
          trail: { on: q('ow_trail').checked, trig: num(q('ow_trig').value, cfg.trailTrig), step: num(q('ow_step').value, cfg.trailStep) },
          state: 'entry', entryNo: r.no, slNo: null, slErr: null, placedT: D.istNow(), fillT: null, peak: price };
        saveT();
        closeWindow();
        say(`Buy order sent · ${w.title}`, `${lots} lot${lots === 1 ? '' : 's'} (${qty}) limit ${fmt(price, 2)} · ${B.name} #${r.no}`);
        showOnChart();
        startPolling(); pollOnce();
      } catch (e) {
        w.placing = false;
        const m = (e && (e.msg || e.message)) || String(e);
        q('ow_msg').textContent = m; q('ow_msg').className = 'ow-msg err';
        q('ow_buy').disabled = false; q('ow_buy').textContent = 'Try again';
        A.toast('Order not sent: ' + m, 6000);
      }
    }

    /* ================================================================== */
    /* Trade management                                                    */
    /* ================================================================== */
    function showOnChart() {
      if (!T) return;
      const cur = A.current();
      if (A.S.mode === 'option' && cur && cur.kind === 'option' && String(cur.token) === String(T.token)) return;
      A.openOption({ und: T.und, side: T.side, strike: T.strike, expiry: T.expiry });
    }

    function startPolling() {
      stopPolling();
      pollTimer = setInterval(() => { if (T && !document.hidden) pollOnce(); else if (!T) stopPolling(); }, 2000);
    }
    function stopPolling() { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } }

    const logTrade = (rec) => { const L = store.get('trade.log', []); L.push(rec); store.set('trade.log', L.slice(-60)); };
    function closeTrade(how, text, exitPx) {
      const t = T; T = null; saveT(); stopPolling(); render(); syncChart();
      if (!t) return;
      const pts = t.avg != null && exitPx != null ? exitPx - t.avg : null;
      logTrade({ t: Date.now(), title: t.title, broker: t.broker, qty: t.qty, avg: t.avg, exit: exitPx, pts, pnl: pts != null ? pts * t.qty : null, how });
      say(`${text}${pts != null ? ` · ${sgn(pts)} pts · ${pts >= 0 ? '+' : '−'}${inr(Math.abs(pts * t.qty))}` : ''}`, t.title);
    }

    async function placeSl(B) {
      const trg = roundTick(T.sl, 0), prc = Math.max(TICK, roundTick(T.sl - cfg.slBuf, -1));
      if (T.ltp && T.ltp <= trg + 1e-9) {
        T.slErr = 'Price is already at or below your SL. Exit now, or drag the SL lower.';
        say('SL not placed — price is at your SL', T.title);
        return false;
      }
      const r = await B.placeOrder({ exch: T.exch, tsym: T.tsym, qty: T.qty, prc, trgprc: trg, prctyp: 'SL-LMT', prd: T.prd, trantype: 'S' });
      if (r && r.ok) { T.slNo = r.no; T.slErr = null; say(`Stop-loss placed at ${fmt(trg, 2)}`, `${T.title} · ${B.name} #${r.no}`); return true; }
      T.slErr = (r && r.err) || 'SL order failed';
      say('⚠ SL order failed — place it again or exit', `${T.slErr}`);
      return false;
    }

    async function moveSl(B, newSl) {
      const trg = roundTick(newSl, 0), prc = Math.max(TICK, roundTick(newSl - cfg.slBuf, -1));
      modifying = true;
      try {
        const r = await B.modifyOrder({ no: T.slNo, exch: T.exch, tsym: T.tsym, qty: T.qty, prc, trgprc: trg, prctyp: 'SL-LMT', prd: T.prd, trantype: 'S' });
        lastModifyAt = Date.now();
        if (r && r.ok) { T.sl = trg; T.slNo = r.no || T.slNo; T.slErr = null; return { ok: true }; }
        failUntil = Date.now() + 6000;
        return { ok: false, err: (r && r.err) || 'Modify failed' };
      } catch (e) { failUntil = Date.now() + 6000; return { ok: false, err: (e && (e.msg || e.message)) || String(e) }; }
      finally { modifying = false; }
    }

    async function pollOnce() {
      if (!T || polling) return;
      polling = true;
      try {
        const B = brokerOf(T.broker);
        if (!B.ready()) { T.warn = `Log in to ${B.name} to keep managing this trade.`; return; }
        T.warn = null;
        const l = await ltpOf(T.ltpItem);
        if (l) { T.ltp = l; T.peak = Math.max(T.peak || 0, l); if (B.feed) B.feed(T.tsym, l); }
        const book = await B.orderBook();
        const find = (no) => (book.list || []).find((x) => String(x.no) === String(no));

        if (T.state === 'entry') {
          const eo = find(T.entryNo);
          if (!eo) { T.miss = (T.miss || 0) + 1; if (T.miss === 8) say('Entry order not found in the order book', 'Check your broker app'); return; }
          T.miss = 0; T.partial = eo.fill || 0;
          if (isDone(eo.status)) {
            T.state = 'live'; T.avg = eo.avg || eo.prc || T.price; T.qty = eo.fill || T.qty; T.fillT = D.istNow();
            say(`Bought ${T.qty} @ ${fmt(T.avg, 2)}`, T.title);
            await placeSl(B);
          } else if (isRej(eo.status)) { closeTrade('rejected', `Buy order rejected${eo.why ? ': ' + eo.why : ''}`, null); return; }
          else if (isCan(eo.status)) {
            if (eo.fill > 0) { T.state = 'live'; T.avg = eo.avg || T.price; T.qty = eo.fill; T.fillT = D.istNow(); say(`Part filled ${T.qty} @ ${fmt(T.avg, 2)}`, T.title); await placeSl(B); }
            else { closeTrade('cancelled', 'Buy order cancelled', null); return; }
          }
        } else if (T.state === 'live') {
          if (T.slNo) {
            const so = find(T.slNo);
            if (so && isDone(so.status)) { closeTrade('sl', 'Stop-loss hit', so.avg || T.sl); return; }
            if (so && isRej(so.status)) { T.slNo = null; T.slErr = so.why || 'SL order rejected'; say('⚠ SL order rejected', T.slErr); }
            else if (so && isCan(so.status)) { T.slNo = null; T.slErr = 'SL order was cancelled'; say('⚠ SL order cancelled', 'Place it again or exit'); }
          }
          // floating stop-loss
          if (T.slNo && T.trail.on && T.ltp && !modifying && Date.now() > failUntil && Date.now() - lastModifyAt > 1500) {
            const ns = trailSl(T.sl, T.ltp, T.trail.trig, T.trail.step);
            if (ns >= T.sl + TICK - 1e-9) {
              const r = await moveSl(B, ns);
              if (r.ok) A.toast(`SL moved up to ${fmt(T.sl, 2)}`, 2200);
              else say('⚠ SL could not be moved', r.err);
            }
          }
        } else if (T.state === 'exiting') {
          const xo = find(T.exitNo);
          if (xo && isDone(xo.status)) { closeTrade('exit', 'Exited', xo.avg || xo.prc); return; }
          if (xo && (isRej(xo.status) || isCan(xo.status))) { T.state = 'live'; T.exitNo = null; T.slNo = null; T.slErr = 'Exit order failed — your SL was cancelled. Place the SL again or exit.'; say('⚠ Exit order failed', xo.why || ''); }
        }
      } catch (e) {
        const m = (e && (e.msg || e.message)) || String(e);
        if (!(e && e.login)) { T.warn = m; }
      } finally { polling = false; saveT(); render(); syncChart(); }
    }

    /** two taps to exit: cancel the stop-loss, then sell at the market-ish limit */
    async function exitNow() {
      if (!T) return;
      if (Date.now() - exitArmed > 3500) { exitArmed = Date.now(); render(); return; }
      exitArmed = 0;
      const B = brokerOf(T.broker);
      try {
        if (T.state === 'entry') {
          const r = await B.cancelOrder(T.entryNo);
          if (!r.ok) throw new Error(r.err);
          A.toast('Cancelling the buy order…'); pollOnce(); return;
        }
        if (T.slNo) { const c = await B.cancelOrder(T.slNo); if (!c.ok) throw new Error('Could not cancel the SL: ' + c.err); T.slNo = null; }
        const l = await ltpOf(T.ltpItem) || T.ltp;
        const prc = Math.max(TICK, roundTick(l - 1, -1));
        const r = await B.placeOrder({ exch: T.exch, tsym: T.tsym, qty: T.qty, prc, prctyp: 'LMT', prd: T.prd, trantype: 'S', trgprc: 0 });
        if (!r.ok) { T.slErr = 'Exit failed: ' + r.err + ' — your SL was cancelled. Place the SL again.'; throw new Error(r.err); }
        T.state = 'exiting'; T.exitNo = r.no; saveT();
        say(`Exit order sent @ ${fmt(prc, 2)}`, T.title); pollOnce();
      } catch (e) { A.toast('Exit: ' + ((e && (e.msg || e.message)) || e), 6000); }
      render();
    }
    async function retrySl() {
      if (!T || T.state !== 'live') return;
      const B = brokerOf(T.broker);
      T.ltp = (await ltpOf(T.ltpItem)) || T.ltp;
      await placeSl(B); saveT(); render(); syncChart();
    }
    function stopTracking() {
      if (!T) return;
      if (Date.now() - exitArmed > 3500) { exitArmed = Date.now(); A.toast('Tap again to stop tracking. Orders already at the broker stay as they are.', 3500); return; }
      exitArmed = 0; T = null; saveT(); stopPolling(); render(); syncChart();
    }

    /** the SL line was dragged on the chart */
    async function onSlDrag(price) {
      if (!T || (T.state !== 'entry' && T.state !== 'live')) return;
      const ns = roundTick(price, 0);
      const ref = T.ltp || T.price;
      if (!(ns > 0)) { A.toast('Stop-loss must be above zero.'); syncChart(); return; }
      if (T.state === 'live' && ns >= ref - TICK) { A.toast('Stop-loss must stay below the current price.'); syncChart(); return; }
      if (T.state === 'entry') {
        if (ns >= T.price) { A.toast('Stop-loss must be below your buy price.'); syncChart(); return; }
        T.sl = ns; saveT(); render(); syncChart(); return;
      }
      if (!T.slNo) { T.sl = ns; saveT(); render(); syncChart(); A.toast('SL line set — tap “Place SL” to send it.'); return; }
      const B = brokerOf(T.broker);
      const prev = T.sl, wasTrail = T.trail.on;
      const loosen = ns < prev - 1e-9;
      T.sl = ns; syncChart();                         // show it where it was dropped while the broker confirms
      const r = await moveSl(B, ns);
      if (r.ok) {
        if (loosen && wasTrail) { T.trail.on = false; A.toast(`SL moved to ${fmt(T.sl, 2)} · floating SL paused (tap Trail to resume)`, 3500); }
        else A.toast(`SL moved to ${fmt(T.sl, 2)} at ${B.name}`, 2500);
      } else { T.sl = prev; A.toast('SL not changed: ' + r.err, 5000); }
      saveT(); render(); syncChart();
    }

    /* ---------- trade bar (above the chart) ---------- */
    function render() {
      if (!T) { bar.hidden = true; bar.innerHTML = ''; return; }
      const B = brokerOf(T.broker);
      const pts = T.avg != null && T.ltp ? T.ltp - T.avg : null;
      const cls = pts == null ? '' : pts >= 0 ? 'up' : 'dn';
      let line1, btns = '';
      if (T.state === 'entry') {
        line1 = `<b>⏳ ${T.title}</b> buy ${T.lots}×${T.lot} @ ${fmt(T.price, 2)} · waiting for fill${T.partial ? ` (${T.partial}/${T.qty})` : ''}`;
        btns = `<button id="tb_exit">${Date.now() - exitArmed < 3500 ? 'Tap again' : 'Cancel buy'}</button>`;
      } else if (T.state === 'exiting') {
        line1 = `<b>${T.title}</b> exit order sent · waiting for fill`;
      } else {
        line1 = `<b>● ${T.title}</b> ${T.qty} @ ${fmt(T.avg, 2)} · LTP ${fmt(T.ltp, 2)} · <span class="${cls}">${pts == null ? '' : `${sgn(pts)} pts · ${pts >= 0 ? '+' : '−'}${inr(Math.abs(pts * T.qty))}`}</span>`;
        btns = (T.slNo ? '' : '<button id="tb_sl" class="warnb">Place SL</button>') +
          `<button id="tb_trail">${T.trail.on ? 'Trail ON' : 'Trail off'}</button>` +
          `<button id="tb_exit">${Date.now() - exitArmed < 3500 ? 'Tap again' : 'Exit'}</button>`;
      }
      const slTxt = T.state === 'entry' ? `SL ${fmt(T.sl, 2)} (placed after the fill)` : T.slNo ? `SL ${fmt(T.sl, 2)}${T.trail.on ? ` · floating ${T.trail.trig}/${T.trail.step}` : ''} · drag the red line` : '<span class="dn">no SL order at the broker</span>';
      const note = T.warn ? `<div class="tb-warn">${T.warn}</div>` : T.slErr ? `<div class="tb-warn">${T.slErr}</div>` : '';
      bar.innerHTML = `<div class="tb-l1">${line1}</div><div class="tb-l2"><span>${slTxt} · ${B.name}</span><span class="tb-b">${btns}<button id="tb_x" aria-label="Stop tracking">✕</button></span></div>${note}`;
      bar.hidden = false;
      const g = (id) => bar.querySelector('#' + id);
      if (g('tb_exit')) g('tb_exit').onclick = exitNow;
      if (g('tb_sl')) g('tb_sl').onclick = retrySl;
      if (g('tb_trail')) g('tb_trail').onclick = () => { T.trail.on = !T.trail.on; saveT(); render(); };
      g('tb_x').onclick = stopTracking;
    }

    /* ---------- chart overlay ---------- */
    let lastSyncKey = '';
    function syncChart() {
      const cur = A.current();
      const show = !!(T && A.S.mode === 'option' && cur && cur.kind === 'option' && String(cur.token) === String(T.token));
      if (!show) { if (lastSyncKey !== 'off') { A.chart.setTrade(null); lastSyncKey = 'off'; } return; }
      const key = [T.state, T.avg, T.sl, T.price, T.ltp, T.slNo, T.trail.on, T.qty].join('|');
      if (key === lastSyncKey) return;
      lastSyncKey = key;
      A.chart.setTrade({
        state: T.state, entry: T.state === 'entry' ? T.price : T.avg, sl: T.sl, ltp: T.ltp, qty: T.qty, lots: T.lots, lot: T.lot,
        placedT: T.placedT, fillT: T.fillT, hasSl: !!T.slNo || T.state === 'entry', trail: !!T.trail.on, draggable: T.state === 'entry' || (T.state === 'live'),
      });
    }
    setInterval(syncChart, 700);
    A.chart.opts.onSlDrag = onSlDrag;

    /* ---------- entry points ---------- */
    EVTrade.onSignal = function (inst, sg) {
      try {
        if (!cfg.autoOpen || !inst || !sg) return;
        if (!(inst.kind === 'option' || (inst.kind === 'index' && SUPPORTED[inst.key]))) return;
        if (inst.kind === 'option' && !SUPPORTED[inst.und]) return;
        if (T) { A.toast('Buy call ignored — you already have a trade open.', 3500); return; }
        const key = `${inst.title}|${sg.key || sg.t || ''}|${sg.dir}`;
        if (W && W.sgKey === key) return;
        if (!brokerOf(cfg.broker).configured()) { A.toast('Buy call — set up your order broker in Settings → Orders to trade it.', 4500); return; }
        openWindow({ inst, sg, dir: sg.dir, key });
      } catch (e) { /* never break the signal flow */ }
    };
    EVTrade.openManual = function () {
      const inst = A.current();
      if (!inst || !(inst.kind === 'option' || (inst.kind === 'index' && SUPPORTED[inst.key]))) { A.toast('Open a NIFTY / SENSEX index or option chart to trade.', 3500); return; }
      if (inst.kind === 'option' && !SUPPORTED[inst.und]) { A.toast('Orders cover NIFTY and SENSEX options.', 3500); return; }
      openWindow({ inst, sg: null, dir: 1, key: 'manual' + Date.now() });
    };
    EVTrade.hasTrade = () => !!T;
    EVTrade.state = () => ({ T, W, cfg });

    // Trade button next to the price
    const quoteRow = document.querySelector('.quote');
    if (quoteRow && quoteRow.querySelector('.q-price')) {
      const b = document.createElement('button'); b.id = 'tradeBtn'; b.className = 'mini trade-btn'; b.textContent = 'Trade ▸';
      b.onclick = EVTrade.openManual; quoteRow.insertBefore(b, quoteRow.querySelector('.q-price'));
    }

    buildSettings();
    // resume a trade that was open when the app was closed
    if (T) { render(); startPolling(); pollOnce(); }
    EV.on('resume', () => { if (T) { startPolling(); pollOnce(); } if (EVTrade.refreshSettings) EVTrade.refreshSettings(); });
    EVTrade._ctl = { pollOnce, openWindow, confirmBuy, onSlDrag, exitNow, brokers: BROKERS, setCfg: (c) => { Object.assign(cfg, c); saveCfg(); } };
  };
})(typeof window !== 'undefined' ? window : globalThis);
