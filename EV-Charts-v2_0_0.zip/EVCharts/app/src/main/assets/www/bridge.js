/*
 * EV Charts — bridge between the web UI and the Android (Kotlin) side.
 *
 * Android injects `EVNative` (a @JavascriptInterface). Calls are async:
 *   EVNative.call(id, method, argsJson)  ->  window.EVResolve(id, ok, payloadJson)
 * Events from Android (login finished, download progress) arrive via
 *   window.EVEvent(name, payloadJson)
 *
 * When EVNative is missing (opening index.html in a desktop browser) a demo
 * bridge with generated candles is used so the UI can be tried and tested.
 */
(function () {
  'use strict';

  const pending = new Map();
  const listeners = {};
  let seq = 0;

  window.EVResolve = function (id, ok, payload) {
    const p = pending.get(id);
    if (!p) return;
    pending.delete(id);
    let data = payload;
    try { data = typeof payload === 'string' ? JSON.parse(payload) : payload; } catch (e) { /* keep raw */ }
    if (ok) p.resolve(data);
    else p.reject(new Error((data && data.error) || String(data || 'Request failed')));
  };

  window.EVEvent = function (name, payload) {
    let data = payload;
    try { data = typeof payload === 'string' ? JSON.parse(payload) : payload; } catch (e) { /* keep raw */ }
    (listeners[name] || []).forEach((fn) => { try { fn(data); } catch (e) { console.error(e); } });
  };

  function on(name, fn) { (listeners[name] = listeners[name] || []).push(fn); }

  function nativeCall(method, args) {
    return new Promise((resolve, reject) => {
      const id = 'c' + (++seq);
      pending.set(id, { resolve, reject });
      try {
        window.EVNative.call(id, method, JSON.stringify(args || {}));
      } catch (e) {
        pending.delete(id);
        reject(e);
      }
    });
  }

  /* ------------------------------------------------------------------ */
  /* Demo bridge (desktop browser only)                                  */
  /* ------------------------------------------------------------------ */
  function makeDemo() {
    const state = { hasKeys: true, loggedIn: true, master: true };
    const base = { NIFTY: 25180, BANKNIFTY: 56420, SENSEX: 82350, FINNIFTY: 26750, INDIAVIX: 11.8, BANKEX: 63800 };
    const stocks = [
      ['RELIANCE', 'RELIANCE INDUSTRIES LTD', 1452], ['HDFCBANK', 'HDFC BANK LTD', 1985], ['TCS', 'TATA CONSULTANCY SERV LT', 3120],
      ['INFY', 'INFOSYS LIMITED', 1528], ['SBIN', 'STATE BANK OF INDIA', 872], ['KTKBANK', 'KARNATAKA BANK LTD', 214],
      ['ICICIBANK', 'ICICI BANK LTD.', 1410], ['TATAMOTORS', 'TATA MOTORS LIMITED', 712], ['ITC', 'ITC LTD', 418],
    ];
    function seedOf(s) { let h = 7; for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) >>> 0; return h; }
    function rng(seed) { let x = seed || 1; return () => ((x = (x * 1664525 + 1013904223) >>> 0) / 4294967296); }
    function priceFor(sym) {
      if (base[sym]) return base[sym];
      if (/FUT$/.test(sym)) return (base[sym.replace(/FUT$/, '')] || 500) * 1.004;
      const st = stocks.find((s) => s[0] === sym);
      if (st) return st[2];
      const m = sym.match(/(\d{5})(CE|PE)$/);
      return m ? 80 + (seedOf(sym) % 120) : 500;
    }
    const isDeriv = (sym) => /(CE|PE|FUT)$/.test(sym);
    const pad = (n) => String(n).padStart(2, '0');
    const dstr = (day) => { const d = new Date(day * 1000); return `${pad(d.getUTCDate())}-${pad(d.getUTCMonth() + 1)}-${d.getUTCFullYear()}`; };
    const cache = new Map();
    // One canonical 1-minute series per symbol, so every timeframe and the flow agree.
    function minuteSeries(sym) {
      if (cache.has(sym)) return cache.get(sym);
      const r = rng(seedOf(sym));
      const out = [];
      let p = priceFor(sym), oi = 4e6 + (seedOf(sym) % 3e6);
      const vol = /(CE|PE)$/.test(sym) ? 0.012 : sym === 'INDIAVIX' ? 0.004 : 0.0009;
      const isIdx = !!base[sym];
      const nowIst = Math.floor(Date.now() / 1000) + 19800;
      const today = nowIst - (nowIst % 86400);
      for (let day = today - 35 * 86400; day <= today; day += 86400) {
        const dow = (Math.floor(day / 86400) + 4) % 7;
        if (dow === 0 || dow === 6) continue;
        let drift = (r() - 0.5) * 0.4;
        for (let m = 555; m < 930; m++) {
          const t = day + m * 60;
          if (t > nowIst) break;
          if (m % 25 === 0) drift = (r() - 0.5) * 0.5;
          const o = p;
          const c = Math.max(0.05, o * (1 + (r() - 0.5 + drift * 0.08) * vol * 2));
          const h = Math.max(o, c) * (1 + r() * vol), l = Math.min(o, c) * (1 - r() * vol);
          const v = isIdx ? 0 : Math.round(r() * 40000 + 2000);
          if (isDeriv(sym)) oi = Math.max(1e5, oi + Math.round((r() - 0.45) * 60000));
          out.push({ t, o, h, l, c, v, oi: isDeriv(sym) ? oi : 0, day });
          p = c;
        }
      }
      cache.set(sym, out);
      return out;
    }
    function genRows(sym, chartType, start, end) {
      const s0 = new Date(start + 'T00:00:00Z').getTime() / 1000;
      const e0 = new Date(end + 'T00:00:00Z').getTime() / 1000 + 86399;
      if (chartType !== 'DAY') {
        return minuteSeries(sym).filter((b) => b.t >= s0 && b.t <= e0)
          .map((b) => [b.o, b.h, b.l, b.c, b.v, b.oi, `${dstr(b.day)} ${pad(Math.floor((b.t - b.day) / 3600))}:${pad(((b.t - b.day) / 60) % 60)}`, 0])
          .reverse(); // the real API is not chronological either
      }
      const r = rng(seedOf(sym) + 7);
      const rows = [];
      let p = priceFor(sym) * 0.8;
      const isIdx = !!base[sym];
      for (let day = s0 - (s0 % 86400); day <= e0; day += 86400) {
        const dow = (Math.floor(day / 86400) + 4) % 7;
        if (dow === 0 || dow === 6) continue;
        const o = p; const c = o * (1 + (r() - 0.48) * 0.018);
        rows.push([o, Math.max(o, c) * (1 + r() * 0.006), Math.min(o, c) * (1 - r() * 0.006), c, isIdx ? 0 : Math.round(r() * 9e6), 0, dstr(day), 0]);
        p = c;
      }
      return rows.reverse();
    }
    // Simulated buyer/seller split for the latest session day, leaning with each candle.
    function flowRows(sym) {
      const series = minuteSeries(sym);
      if (!series.length) return [];
      const lastDay = series[series.length - 1].day;
      const r = rng(seedOf(sym) + 99);
      return series.filter((b) => b.day === lastDay && b.v > 0).map((b) => {
        const range = Math.max(1e-9, b.h - b.l);
        const lean = (b.c - b.o) / range; // -1 .. 1
        const share = Math.min(0.92, Math.max(0.08, 0.5 + lean * 0.3 + (r() - 0.5) * 0.25));
        const traded = Math.round(b.v * (0.85 + r() * 0.15));
        return [b.t, Math.round(traded * share), Math.round(traded * (1 - share))];
      });
    }
    function expiriesFor(und) {
      const out = [];
      const wd = und === 'SENSEX' ? 4 : 2; // Thu for SENSEX, Tue for NIFTY
      let t = Math.floor(Date.now() / 86400000);
      while (out.length < 6) {
        if ((t + 4) % 7 === wd) out.push(new Date(t * 86400000).toISOString().slice(0, 10));
        t++;
      }
      return out;
    }
    const delay = (v, ms = 250) => new Promise((res) => setTimeout(() => res(v), ms));

    return function demoCall(method, a) {
      switch (method) {
        case 'status':
          return delay({ hasKeys: state.hasKeys, loggedIn: state.loggedIn, loginDate: new Date().toISOString().slice(0, 10),
            master: { ready: state.master, date: new Date().toISOString().slice(0, 10), count: 18234 },
            apiKey: 'demo-key', redirectUrl: 'https://evcharts.app/callback', demo: true });
        case 'saveSettings': state.hasKeys = true; return delay({ ok: true });
        case 'login': state.loggedIn = true; setTimeout(() => window.EVEvent('login', { ok: true }), 400); return delay({ started: true });
        case 'logout': state.loggedIn = false; return delay({ ok: true });
        case 'downloadMaster':
          [20, 55, 90].forEach((p, i) => setTimeout(() => window.EVEvent('master', { pct: p }), 200 * (i + 1)));
          return delay({ count: 18234 }, 900);
        case 'indices':
          return delay([
            ['NIFTY', 'NIFTY 50', 'NSE'], ['BANKNIFTY', 'NIFTY BANK', 'NSE'], ['SENSEX', 'SENSEX', 'BSE'],
            ['FINNIFTY', 'NIFTY FIN SERVICE', 'NSE'], ['BANKEX', 'BANKEX', 'BSE'], ['INDIAVIX', 'INDIA VIX', 'NSE'],
          ].map(([key, label, ex]) => ({ key, label, exchange: ex, series: ex === 'NSE' ? 'INDICES' : 'IDX',
            ltpExchange: ex + '_INDEX', token: String(seedOf(key) % 99999), chartSymbols: [key, label],
            future: key === 'INDIAVIX' ? null : { symbol: key + 'FUT', token: key + 'FUT', lot: key === 'SENSEX' ? 20 : key === 'BANKNIFTY' ? 35 : 75,
              exchange: ex === 'NSE' ? 'NFO' : 'BFO', series: ex === 'NSE' ? 'FUTIDX' : 'IF' } })));
        case 'optionUnderlyings': return delay(['NIFTY', 'BANKNIFTY', 'SENSEX', 'FINNIFTY']);
        case 'optionExpiries': return delay(expiriesFor(a.underlying));
        case 'optionChain': {
          const spot = base[a.underlying];
          const step = a.underlying === 'NIFTY' || a.underlying === 'FINNIFTY' ? 50 : 100;
          const atm = Math.round(spot / step) * step;
          const strikes = [];
          const ex = a.underlying === 'SENSEX' ? 'BFO' : 'NFO';
          const d = new Date(a.expiry + 'T00:00:00Z');
          const code = `${String(d.getUTCFullYear()).slice(2)}${'JFMAMJJASOND'[d.getUTCMonth()]}${String(d.getUTCDate()).padStart(2, '0')}`;
          for (let k = -20; k <= 20; k++) {
            const s = atm + k * step;
            strikes.push({ strike: s, ce: { symbol: `${a.underlying}${code}${s}CE`, token: `${a.underlying}${code}${s}CE` },
              pe: { symbol: `${a.underlying}${code}${s}PE`, token: `${a.underlying}${code}${s}PE` } });
          }
          return delay({ exchange: ex, series: ex === 'NFO' ? 'OPTIDX' : 'IO', lot: 75, strikes,
            spot: { exchange: ex === 'NFO' ? 'NSE_INDEX' : 'BSE_INDEX', token: 'spot-' + a.underlying } });
        }
        case 'searchStocks': {
          const q = String(a.q || '').toUpperCase();
          return delay(stocks.filter((s) => s[0].includes(q) || s[1].includes(q)).slice(0, 20)
            .map(([symbol, name]) => ({ symbol, name, token: symbol, exchange: 'NSE', series: 'EQ' })), 120);
        }
        case 'candles': {
          const sym = a.chartSymbols[0];
          return delay({ symbol: sym, rows: genRows(sym, a.chartType, a.start, a.end) }, 350);
        }
        case 'flowWatch': {
          const history = {};
          for (const key of a.keys || []) history[key] = flowRows(key.replace(/^(NSE|BSE|NFO|BFO)_/, ''));
          setTimeout(() => window.EVEvent('feed', { status: 'connected' }), 300);
          return delay({ history, connected: true }, 200);
        }
        case 'chainWatch': return delay({ ok: true, connected: true }, 100);
        case 'chainStats': {
          // Demo OI profile: call writers stacked above spot, put writers below, buyers piling into one strike each side.
          const stats = {};
          for (const key of a.keys || []) {
            const sym = key.replace(/^(NFO|BFO)_/, '');
            const m = sym.match(/^([A-Z]+?)\d{2}[A-Z0-9]{3}(\d+)(CE|PE)$/);
            if (!m) continue;
            const und = m[1], strike = +m[2], side = m[3];
            const spot = base[und] || 25000;
            const stepW = und === 'NIFTY' || und === 'FINNIFTY' ? 50 : 100;
            const k = Math.round((strike - spot) / stepW); // strikes away from spot
            const r = rng(seedOf(key));
            let oi = 2e5 + r() * 3e5;
            if (side === 'CE' && k > 0) oi += k === 2 ? 9e6 : k === 4 ? 6e6 : 1.5e6 / k;
            if (side === 'PE' && k < 0) oi += k === -3 ? 8e6 : k === -1 ? 5e6 : 1.2e6 / -k;
            const tot = [oi * 0.25, oi * 0.05, oi * 0.06, oi * 0.02].map(Math.round);
            const recent = [oi * 0.02, oi * 0.004, 0, 0].map(Math.round);
            if (side === 'CE' && k === 1) tot[2] = Math.round(4e6);        // buyers piling into the next call
            if (side === 'PE' && k === -2) tot[2] = Math.round(2.5e6);
            if (side === 'PE' && k === -1) { recent[1] = Math.round(oi * 0.05); recent[0] = Math.round(oi * 0.01); } // weakening
            stats[key] = { oi: Math.round(oi), ltp: 100, tot, recent };
          }
          return delay({ stats, connected: true }, 120);
        }
        case 'immersive': return delay({ ok: true }, 5);
        case 'secGetMany': return delay({}, 5);
        case 'secSet': return delay({ ok: true }, 5);
        case 'sha256': return delay({ hex: '' }, 5);
        case 'http': case 'httpCsv': return delay({ status: 0, text: 'Broker calls work in the Android app only (use Paper in a browser).' }, 50);
        case 'ftLogin': setTimeout(() => window.EVEvent('ftlogin', { error: 'Flattrade login works in the Android app only.' }), 200); return delay({ started: true }, 5);
        case 'notify': console.log('notify', a.title, a.text); return delay({ ok: true }, 10);
        case 'pendingLink': return delay({}, 10);
        case 'openExternal': return Promise.reject(new Error("EV Pulse doesn't have the EV Charts link yet"));
        case 'ltp':
          return delay((a.items || []).map((it) => {
            let sym = it.symbol || String(it.token);
            if (String(it.token).startsWith('spot-')) sym = String(it.token).slice(5);
            const p = priceFor(sym);
            return { exchange: it.exchange, token: it.token, ltp: p * 1.003, prev_close: p };
          }), 120);
        default:
          return Promise.reject(new Error('Unknown method ' + method));
      }
    };
  }

  const isNative = !!window.EVNative;
  const demo = isNative ? null : makeDemo();

  window.EV = {
    native: isNative,
    on,
    call(method, args) { return isNative ? nativeCall(method, args) : demo(method, args || {}); },
  };
})();
