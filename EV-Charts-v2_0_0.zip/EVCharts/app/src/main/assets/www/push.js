/*
 * EV Charts — Push Strength (live, 0–100) and pre-move calls.
 *
 * The score is worked out for every minute (history) and every second on the live, forming minute.
 * A pre-move call is given while price is still SHORT of a level, with a trigger IN just beyond it:
 *   pending  -> triggered (price crosses the trigger) -> trailing SL -> exit
 *   pending  -> withdrawn (push fades, price walks away, or 20 minutes pass)
 *   triggered -> "exit early" when the push collapses before T1
 *
 * Times are IST wall-clock seconds stored as UTC.
 */
(function () {
  'use strict';

  const DAY = 86400;
  const tod = (t) => t % DAY;
  const T0930 = 9 * 3600 + 30 * 60;
  const T1500 = 15 * 3600;
  const clamp = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);

  const DEFAULTS = {
    premove: true, minScore: 60, trail: true,
    // Scalp mode: fixed OPTION PREMIUM points (on index charts converted with ATM delta ≈ 0.5)
    scalp: true, sT1: 5, sT2: 10, sSL: 4, sBE: 3, sGap: 3, sMin: 70, sCool: 2, sMax: 15,
  };

  // weights of each part; parts that are unknown are left out and the rest re-weighted
  const W = { share: 0.22, trend: 0.12, absorb: 0.10, oi: 0.16, squeeze: 0.06, vol: 0.08, wall: 0.12, room: 0.07, book: 0.07 };
  const CORE = ['share', 'trend', 'absorb', 'oi', 'squeeze', 'vol']; // known for every past minute -> used to create calls
  const PART_NAMES = {
    share: 'Buyer / seller share', trend: 'Share rising', absorb: 'Absorption', oi: 'OI on this side',
    squeeze: 'Squeeze near level', vol: 'Volume surge', wall: 'Writers leaving wall', room: 'Room to next wall', book: 'Order book',
  };

  function atr5Map(raw) {
    const out = new Array(raw.length).fill(null);
    let cur = null, pc = null, atr = null;
    for (let i = 0; i < raw.length; i++) {
      const b = raw[i];
      const day = b.t - (b.t % DAY);
      const start = day + 9 * 3600 + 15 * 60;
      const k = start + Math.floor((b.t - start) / 300) * 300;
      if (!cur || cur.k !== k) {
        if (cur) {
          const tr = pc == null ? cur.h - cur.l : Math.max(cur.h - cur.l, Math.abs(cur.h - pc), Math.abs(cur.l - pc));
          atr = atr == null ? tr : (atr * 13 + tr) / 14;
          pc = cur.c;
        }
        cur = { k, h: b.h, l: b.l, c: b.c };
      } else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); cur.c = b.c; }
      out[i] = atr != null ? atr : Math.max(cur.h - cur.l, b.c * 0.0005);
    }
    return out;
  }

  /*
   * ctx = {
   *   raw: 1-minute candles (last may be live / forming), live: bool,
   *   flowMin: Map(t -> [buy, sell]) real split, volBars: 1-minute candles with volume (est. split / volume),
   *   oiMap: Map(t -> {kind}), kind: 'index'|'option'|'stock', stripKind, side ('CE'|'PE' on option charts),
   *   wm: {walls, ...} live writer walls (underlying), spot: underlying price (option charts), book: {buy, sell},
   *   settings, rr1, rr2, maxSlPct, stored: Map(key -> fixed levels of calls given live), tick, sessionOver
   * }
   */
  function prepare(ctx) {
    const raw = ctx.raw || [];
    const n = raw.length;
    const volBy = ctx.volBars ? new Map(ctx.volBars.map((b) => [b.t, b])) : null;
    const flow = new Array(n), vol = new Array(n), dayAvg = new Array(n), kind = new Array(n);
    let day = null, sum = 0, cnt = 0;
    for (let i = 0; i < n; i++) {
      const b = raw[i];
      const d = Math.floor(b.t / DAY);
      if (d !== day) { day = d; sum = 0; cnt = 0; }
      const vb = volBy ? volBy.get(b.t) : b;
      const v = vb && vb.v > 0 ? vb.v : 0;
      vol[i] = v;
      dayAvg[i] = cnt ? sum / cnt : 0;
      if (v > 0) { sum += v; cnt++; }
      const real = ctx.flowMin && ctx.flowMin.get(b.t);
      if (real && real[0] + real[1] > 0) flow[i] = { b: real[0], s: real[1], real: true };
      else if (vb && v > 0) {
        const range = vb.h - vb.l;
        const sh = range > 0 ? (vb.c - vb.l) / range : 0.5;
        flow[i] = { b: v * sh, s: v * (1 - sh), real: false };
      } else flow[i] = null;
      const c = ctx.oiMap && ctx.oiMap.get(b.t);
      kind[i] = c ? c.kind : null;
    }
    return { raw, n, flow, vol, dayAvg, kind, atr: atr5Map(raw) };
  }

  function sameDay(raw, a, b) { return Math.floor(raw[a].t / DAY) === Math.floor(raw[b].t / DAY); }

  function shareOver(P, from, to) {
    let b = 0, s = 0;
    for (let j = Math.max(0, from); j <= to; j++) {
      if (!sameDay(P.raw, j, to)) continue;
      const f = P.flow[j];
      if (f) { b += f.b; s += f.s; }
    }
    return b + s > 0 ? b / (b + s) : null;
  }

  // underlying direction for walls: index = dir; CE premium up = underlying up; PE premium up = underlying down
  function undDir(ctx, dir) { return ctx.kind === 'option' && ctx.side === 'PE' ? -dir : dir; }

  function partsAt(ctx, P, i, dir, liveExtras) {
    const raw = P.raw, b = raw[i];
    const parts = {};
    const sh3 = shareOver(P, i - 2, i);
    const shPrior = shareOver(P, i - 9, i - 3);
    if (sh3 != null) {
      const d3 = dir > 0 ? sh3 : 1 - sh3;
      parts.share = clamp((d3 - 0.5) / 0.25);
      if (shPrior != null) parts.trend = clamp(((d3) - (dir > 0 ? shPrior : 1 - shPrior)) / 0.15);
    }
    const sh5 = shareOver(P, i - 4, i);
    if (sh5 != null && i >= 5 && sameDay(raw, i - 5, i)) {
      const opp = dir > 0 ? 1 - sh5 : sh5;
      const move = dir * (b.c - raw[i - 5].c) / (P.atr[i] || 1);
      parts.absorb = opp > 0.55 && move >= -0.1 ? clamp((opp - 0.5) / 0.2) : 0;
    }
    if (ctx.stripKind) {
      let fav = 0, known = 0;
      for (let j = i - 4; j <= i; j++) {
        if (j < 0 || !sameDay(raw, j, i) || !P.kind[j]) continue;
        known++;
        const k = P.kind[j];
        if (dir > 0 ? (k === 'BA' || k === 'WE') : (k === 'WA' || k === 'BE')) fav++;
      }
      if (known) parts.oi = fav / known;
    }
    if (i >= 9 && sameDay(raw, i - 9, i)) {
      let hi = -Infinity, lo = Infinity;
      for (let j = i - 9; j <= i; j++) { hi = Math.max(hi, raw[j].h); lo = Math.min(lo, raw[j].l); }
      parts.squeeze = clamp(1 - (hi - lo) / (2.2 * (P.atr[i] || 1)));
    }
    if (P.dayAvg[i] > 0) {
      const v3 = (P.vol[i] + (i > 0 ? P.vol[i - 1] : 0) + (i > 1 ? P.vol[i - 2] : 0)) / 3;
      parts.vol = clamp((v3 / P.dayAvg[i] - 1) / 1.5);
    }
    if (liveExtras) {
      const wall = nextWall(ctx, dir);
      if (wall) {
        parts.wall = wall.weak ? 1 : wall.building ? 0 : 0.4;
        const spot = ctx.kind === 'index' ? b.c : ctx.spot;
        if (spot) parts.room = clamp(((Math.abs(wall.strike - spot) / spot) * 100 - 0.1) / 0.3);
      } else if (ctx.wm && ctx.wm.live) { parts.room = 1; }
      if (ctx.book && ctx.book.buy + ctx.book.sell > 0) {
        const bs = ctx.book.buy / (ctx.book.buy + ctx.book.sell);
        parts.book = clamp(((dir > 0 ? bs : 1 - bs) - 0.5) / 0.2);
      }
    }
    return parts;
  }

  function scoreOf(parts, keys) {
    let s = 0, w = 0;
    for (const k of keys || Object.keys(W)) {
      if (parts[k] == null) continue;
      s += W[k] * parts[k]; w += W[k];
    }
    return w ? Math.round((s / w) * 100) : 0;
  }

  // nearest writer wall in the way of the underlying move
  function nextWall(ctx, dir) {
    if (!ctx.wm || !ctx.wm.walls || ctx.kind === 'stock') return null;
    const ud = undDir(ctx, dir);
    const role = ud > 0 ? 'resistance' : 'support';
    return ctx.wm.walls.find((w) => w.rank === 0 && w.role === role) || null;
  }

  function prevDayHL(raw) {
    const days = [];
    let cur = null;
    for (const b of raw) {
      const d = Math.floor(b.t / DAY);
      if (!cur || cur.d !== d) { cur = { d, h: b.h, l: b.l }; days.push(cur); }
      else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); }
    }
    const m = new Map();
    for (let k = 1; k < days.length; k++) m.set(days[k].d, days[k - 1]);
    return m;
  }

  function levelsAt(ctx, P, i, dir, orb, pdm, live) {
    const raw = P.raw, b = raw[i], d = Math.floor(b.t / DAY);
    const L = [];
    const pd = pdm.get(d);
    if (pd) L.push({ name: dir > 0 ? 'Prev-day high' : 'Prev-day low', lvl: dir > 0 ? pd.h : pd.l });
    const o = orb.get(d);
    if (o && tod(b.t) >= T0930) L.push({ name: dir > 0 ? 'Opening-range high' : 'Opening-range low', lvl: dir > 0 ? o.h : o.l });
    // recent swing: last 30 minutes, leaving out the latest 3
    let cnt = 0, ext = dir > 0 ? -Infinity : Infinity;
    for (let j = i - 33; j <= i - 3; j++) {
      if (j < 0 || !sameDay(raw, j, i)) continue;
      cnt++; ext = dir > 0 ? Math.max(ext, raw[j].h) : Math.min(ext, raw[j].l);
    }
    if (cnt >= 15) L.push({ name: dir > 0 ? '30-min high' : '30-min low', lvl: ext });
    if (ctx.scalp) {
      let c2 = 0, e2 = dir > 0 ? -Infinity : Infinity;
      for (let j = i - 12; j <= i - 2; j++) {
        if (j < 0 || !sameDay(raw, j, i)) continue;
        c2++; e2 = dir > 0 ? Math.max(e2, raw[j].h) : Math.min(e2, raw[j].l);
      }
      if (c2 >= 8 && Math.abs(e2 - ext) > 1e-9) L.push({ name: dir > 0 ? '10-min high' : '10-min low', lvl: e2 });
    }
    if (live && ctx.kind === 'index' && ctx.wm && ctx.wm.walls) {
      for (const w of ctx.wm.walls) {
        if (w.rank !== 0) continue;
        if (dir > 0 && w.role === 'resistance') L.push({ name: `${w.strike} CE writer wall`, lvl: w.strike, wall: true });
        if (dir < 0 && w.role === 'support') L.push({ name: `${w.strike} PE writer wall`, lvl: w.strike, wall: true });
      }
    }
    return L;
  }

  function openingRanges(raw) {
    const map = new Map();
    for (const b of raw) {
      const s = tod(b.t);
      if (s < 9 * 3600 + 15 * 60 || s >= T0930) continue;
      const d = Math.floor(b.t / DAY);
      const r = map.get(d);
      if (!r) map.set(d, { h: b.h, l: b.l }); else { r.h = Math.max(r.h, b.h); r.l = Math.min(r.l, b.l); }
    }
    return map;
  }

  const rnd = (v, tick) => Math.round(v / tick) * tick;

  function run(ctx) {
    const st = Object.assign({}, DEFAULTS, ctx.settings || {});
    const P = prepare(ctx);
    const raw = P.raw, n = P.n;
    const out = { calls: [], meter: null, history: [] };
    if (n < 15) return out;
    const dirs = ctx.kind === 'index' ? [1, -1] : [1];
    const meterDirs = [1, -1];
    const orb = openingRanges(raw);
    const pdm = prevDayHL(raw);
    const rr1 = ctx.rr1 || 2, rr2 = ctx.rr2 || 4;
    const used = new Set();
    const SC = ctx.scalp ? Object.assign({ delta: 0.5 }, ctx.scalp) : null;
    // index points per premium point (option / stock charts: 1)
    const unit = SC ? (ctx.kind === 'index' ? 1 / SC.delta : 1) : 1;
    const minScore = SC ? SC.minScore : st.minScore;
    const perDay = new Map();
    let coolUntil = 0;
    let active = null;
    const core = new Array(n).fill(null); // best core score per minute, per dir
    const coreAt = (i, dir) => {
      if (!core[i]) core[i] = {};
      if (core[i][dir] == null) core[i][dir] = scoreOf(partsAt(ctx, P, i, dir, false), CORE);
      return core[i][dir];
    };

    for (let i = 10; i < n; i++) {
      const b = raw[i];
      const isLive = !!ctx.live && i === n - 1;
      const d = Math.floor(b.t / DAY);
      const tick = ctx.tick || (b.c < 1000 ? 0.05 : 0.05);

      // ---------- manage the active call
      if (active) {
        const a = active;
        if (Math.floor(a.t / DAY) !== d) {
          if (a.status === 'pending') { a.status = 'withdrawn'; a.why = 'day ended'; a.exitI = i - 1; }
          else finish(a, i - 1, raw[i - 1].c, 'eod');
          active = null;
        }
        else if (a.status === 'pending') {
          const hit = a.dir > 0 ? b.h >= a.trigger : b.l <= a.trigger;
          if (hit) {
            a.status = 'open'; a.iTrig = i; a.trigT = b.t;
            a.entry = a.dir > 0 ? Math.max(a.trigger, b.o) : Math.min(a.trigger, b.o);
            a.slNow = a.sl; a.best = a.entry;
          } else if (!isLive) {
            const sc = coreAt(i, a.dir);
            const away = a.dir * (a.level - b.c) > 3 * a.gapLimit;
            const faded = sc < (SC ? 55 : 45);
            const maxWait = SC ? 8 * 60 : 20 * 60;
            // waiting longer is fine while the push is still strong; time out only once it has cooled
            const timedOut = b.t - a.t >= maxWait && sc < minScore;
            if (faded || away || timedOut || b.t - a.t >= 30 * 60 || tod(b.t) > T1500) {
              a.status = 'withdrawn'; a.exitI = i; a.exitPx = b.c;
              a.why = faded ? 'push faded' : away ? 'price moved away' : `no trigger in ${maxWait / 60} min`;
              active = null;
            }
          }
        }
        if (active && active.status === 'open') {
          const a2 = active;
          const worst = a2.dir > 0 ? b.l : b.h;
          const bestPx = a2.dir > 0 ? b.h : b.l;
          if (a2.dir * (worst - a2.slNow) <= 0 && i > a2.iTrig) {
            finish(a2, i, a2.slNow, a2.t1Hit ? 'trail' : a2.slNow === a2.entry ? 'be' : 'sl');
            active = null;
          } else if (SC) {
            // scalp: SL to entry at +sBE points, then trail sGap points behind the best price
            if (a2.dir * (bestPx - a2.best) > 0) a2.best = bestPx;
            const gain = a2.dir * (a2.best - a2.entry) / unit;
            if (gain >= SC.be && a2.dir * (a2.slNow - a2.entry) < 0) { a2.slNow = a2.entry; a2.moves.push({ t: b.t, sl: a2.slNow, why: `+${SC.be} pts → SL at entry` }); }
            if (st.trail && gain >= SC.be) {
              const c2 = rnd(a2.best - a2.dir * SC.gap * unit, tick);
              if (a2.dir * (c2 - a2.slNow) > 0) { a2.slNow = c2; a2.moves.push({ t: b.t, sl: c2, why: `trailing ${SC.gap} pts` }); }
            }
            if (!a2.t1Hit && a2.dir * (a2.best - a2.t1) >= 0) { a2.t1Hit = true; a2.t1T = b.t; }
            if (a2.dir * (a2.best - a2.t2) >= 0) { finish(a2, i, a2.t2, 't2'); active = null; }
            else if (!isLive && !a2.t1Hit && i > a2.iTrig && coreAt(i, a2.dir) < 45) { finish(a2, i, b.c, 'early'); active = null; }
          } else {
            if (a2.dir * (bestPx - a2.best) > 0) a2.best = bestPx;
            const r1 = a2.entry + a2.dir * a2.risk;
            if (a2.dir * (a2.best - r1) >= 0 && a2.dir * (a2.slNow - a2.entry) < 0) { a2.slNow = a2.entry; a2.moves.push({ t: b.t, sl: a2.slNow, why: '+1R → SL at entry' }); }
            if (!a2.t1Hit && a2.dir * (a2.best - a2.t1) >= 0) { a2.t1Hit = true; a2.t1T = b.t; }
            if (a2.dir * (a2.best - a2.t2) >= 0) { finish(a2, i, a2.t2, 't2'); active = null; }
            else if (!isLive) {
              const sc = coreAt(i, a2.dir);
              if (st.trail && a2.t1Hit) {
                // trail under the last 3 closed minutes; tighter when the push weakens
                let ext = a2.dir > 0 ? Infinity : -Infinity;
                for (let j = i - 2; j <= i; j++) ext = a2.dir > 0 ? Math.min(ext, raw[j].l) : Math.max(ext, raw[j].h);
                const k = sc >= 70 ? 1.2 : sc >= 45 ? 0.8 : 0.5;
                const byAtr = b.c - a2.dir * k * (P.atr[i] || 0);
                const cand = a2.dir > 0 ? Math.max(ext - tick, byAtr) : Math.min(ext + tick, byAtr);
                const c2 = rnd(cand, tick);
                if (a2.dir * (c2 - a2.slNow) > 0 && a2.dir * (b.c - c2) > 0) { a2.slNow = c2; a2.moves.push({ t: b.t, sl: c2, why: 'trailing' }); }
              }
              if (!a2.t1Hit && sc < 35 && i > a2.iTrig) {
                finish(a2, i, b.c, 'early'); active = null;
              }
            }
          }
        }
        if (active) continue;
        if (a.entry != null) coolUntil = b.t + (SC ? SC.cool : 2) * 60; // short pause after a trade ends
      }

      // ---------- look for a new pre-move call
      if (!st.premove) continue;
      const s = tod(b.t);
      if (s < T0930 || s > T1500 - 300) continue;
      if (!sameDay(raw, i - 1, i)) continue;
      if (b.t < coolUntil) continue;
      if ((perDay.get(d) || 0) >= (SC ? SC.max : 6)) continue;
      let best = null;
      for (const dir of dirs) {
        const sc = coreAt(i, dir);
        if (sc < minScore) continue;
        if (coreAt(i - 1, dir) < minScore - 5) continue; // must be building, not a one-minute blip
        const atr = P.atr[i] || b.c * 0.001;
        const gapLimit = SC ? (ctx.kind === 'stock' ? b.c * 0.0015 : 2 * unit)
          : ctx.kind === 'option' ? Math.max(0.5 * atr, b.c * 0.03) : Math.max(0.5 * atr, b.c * 0.0015);
        for (const L of levelsAt(ctx, P, i, dir, orb, pdm, isLive)) {
          const gap = dir * (L.lvl - b.c);
          if (!(gap > 0) || gap > gapLimit) continue;
          // named levels give one call a day; a 30-min swing can repeat once it has moved
          const key = /-min /.test(L.name) ? `${d}|${dir}|swing|${Math.round(L.lvl / (b.c * 0.001))}` : `${d}|${dir}|${L.name}`;
          if (used.has(key)) continue;
          if (!best || sc > best.sc || (sc === best.sc && gap < best.gap)) best = { dir, L, gap, sc, key, atr, gapLimit };
        }
      }
      if (!best) continue;
      const { dir, L, atr, gapLimit } = best;
      if (!isLive) used.add(best.key);
      const buf = SC ? (ctx.kind === 'index' ? 1 : Math.max(tick, 0.3))
        : ctx.kind === 'option' ? Math.max(tick, L.lvl * 0.005) : Math.max(tick, L.lvl * 0.0002);
      let trigger = rnd(L.lvl + dir * buf, tick);
      let risk = Math.min(Math.max(0.8 * atr, trigger * (ctx.kind === 'option' ? 0.04 : 0.0008)), 2 * atr);
      if (ctx.kind === 'option') risk = Math.min(risk, trigger * (ctx.maxSlPct || 25) / 100);
      let t1 = trigger + dir * rr1 * risk;
      let t2 = trigger + dir * rr2 * risk;
      if (SC) {
        risk = SC.sl * unit;
        t1 = trigger + dir * SC.t1 * unit;
        t2 = trigger + dir * SC.t2 * unit;
      }
      let capped = null;
      if (ctx.kind === 'index') {
        // never aim T1 through the next writer wall beyond the level
        const wall = nextWall(ctx, dir);
        if (wall && dir * (wall.strike - trigger) > 0 && dir * (t1 - wall.strike) > 0) {
          t1 = wall.strike - dir * buf; capped = wall.strike;
        }
      }
      const sk = `${d}|${dir}|${b.t}`;
      const fixed = ctx.stored && ctx.stored.get(sk);
      const fullParts = partsAt(ctx, P, i, dir, isLive);
      const call = {
        key: sk, t: b.t, iRaw: i, dir, level: L.lvl, levelName: L.name, wallLevel: !!L.wall, gapLimit,
        trigger: fixed ? fixed.trigger : trigger,
        sl: fixed ? fixed.sl : rnd(trigger - dir * risk, tick),
        t1: fixed ? fixed.t1 : rnd(t1, tick), t2: fixed ? fixed.t2 : rnd(t2, tick),
        risk: fixed ? fixed.risk : risk, capped: fixed ? fixed.capped : capped,
        score: fixed ? fixed.score : isLive ? scoreOf(fullParts) : best.sc,
        parts: fixed ? fixed.parts : fullParts,
        status: 'pending', t1Hit: false, moves: [], r: 0, live: isLive,
      };
      call.slNow = call.sl;
      call.scalp = !!SC; call.unit = unit;
      out.calls.push(call);
      perDay.set(d, (perDay.get(d) || 0) + 1);
      active = call;
      // the forming minute can trigger straight away
      if (isLive) {
        const hit = dir > 0 ? b.h >= call.trigger : b.l <= call.trigger;
        if (hit) { call.status = 'open'; call.iTrig = i; call.trigT = b.t; call.entry = call.trigger; call.best = b.c; }
      }
    }
    if (active && ctx.sessionOver) {
      if (active.status === 'pending') { active.status = 'withdrawn'; active.why = 'session over'; active.exitI = n - 1; }
      else if (active.status === 'open') finish(active, n - 1, raw[n - 1].c, 'eod');
    }

    // ---------- live meter: the latest minute, both directions
    const li = n - 1;
    const md = meterDirs.map((dir) => { const parts = partsAt(ctx, P, li, dir, true); return { dir, parts, score: scoreOf(parts) }; });
    const top = md[0].score >= md[1].score ? md[0] : md[1];
    out.meter = { dir: top.dir, score: top.score, parts: top.parts, up: md[0].score, down: md[1].score,
      real: !!(P.flow[li] && P.flow[li].real), t: raw[li].t };
    // score per minute for the last 15 minutes (sparkline), in the meter's direction
    for (let j = Math.max(0, li - 14); j <= li; j++) {
      if (!sameDay(raw, j, li)) continue;
      out.history.push(scoreOf(partsAt(ctx, P, j, top.dir, j === li), j === li ? null : CORE));
    }
    for (const c of out.calls) { c.exitT = c.exitI != null ? raw[c.exitI].t : null; }
    return out;

    function finish(a, i, px, why) {
      a.status = why; a.exitI = i; a.exitPx = px;
      if (a.entry == null) { a.r = 0; return; }
      a.pts = a.dir * (px - a.entry) / (a.unit || 1); // premium points (index charts: via ATM delta)
      if (a.scalp) { a.r = a.dir * (px - a.entry) / a.risk; return; }
      const rr = a.dir * (px - a.entry) / a.risk;
      const r1 = a.dir * (a.t1 - a.entry) / a.risk;
      a.r = a.t1Hit && why !== 't2' ? (r1 + rr) / 2 : why === 't2' ? (r1 + rr) / 2 : rr;
    }
  }

  // results grouped by the score the call was given at
  function byScore(calls) {
    const buckets = [[60, 70], [70, 80], [80, 101]].map(([lo, hi]) => ({ lo, hi, n: 0, trig: 0, t1: 0, win: 0, r: 0, pts: 0 }));
    for (const c of calls) {
      const b = buckets.find((x) => c.score >= x.lo && c.score < x.hi);
      if (!b || c.status === 'pending' || (c.status === 'open')) continue;
      b.n++;
      if (c.entry != null) { b.trig++; if (c.t1Hit) b.t1++; if (c.r > 0) b.win++; b.r += c.r; b.pts += c.pts || 0; }
    }
    return buckets;
  }

  const api = { DEFAULTS, PART_NAMES, W, run, byScore };
  if (typeof window !== 'undefined') window.EVPush = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
