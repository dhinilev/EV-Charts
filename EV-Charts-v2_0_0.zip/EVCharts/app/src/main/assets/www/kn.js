/* EV Charts — Kotak Neo Trade API: ORDERS ONLY (chart data stays on HDFC Sky). Same module as EV Pulse.
   Login each morning inside the app: mobile + client code (UCC) + 6-digit TOTP, then MPIN. The consumer key is saved on the
   phone; TOTP and MPIN are never saved. Orders go out only after the user taps Confirm in the order window.
   API reference: github.com/Kotak-Neo/kotak-neo-python (REST: tradeApiLogin / tradeApiValidate, quick/order/…, portfolio/v2/positions). */
(function (root) {
  'use strict';

  const LOGIN_HOST = 'https://mis.kotaksecurities.com';
  const DEF_BASE = 'https://mis.kotaksecurities.com';
  const FIN_KEY = 'neotradeapi';
  const SRC = 'NEOTRADEAPI';
  const SEG = { NIFTY: 'nse_fo', SENSEX: 'bse_fo' }, EXCH = { NIFTY: 'NFO', SENSEX: 'BFO' };

  function csvSplit(line) {                     // simple CSV (handles quoted fields)
    const out = []; let cur = '', q = false;
    for (let i = 0; i < line.length; i++) { const ch = line[i];
      if (q) { if (ch === '"') { if (line[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += ch; }
      else if (ch === '"') q = true; else if (ch === ',') { out.push(cur); cur = ''; } else cur += ch; }
    out.push(cur); return out;
  }
  /** expiry in the scrip master: epoch seconds (NSE F&O is offset by 315511200 s), or a date text */
  function expIso(v) {
    const s = String(v || '').trim(); if (!s) return '';
    if (/^\d+(\.\d+)?$/.test(s)) { let e = +s; if (e > 1e12) e = e / 1000; let d = new Date(e * 1000); if (d.getUTCFullYear() < new Date().getUTCFullYear() - 3) d = new Date((e + 315511200) * 1000);   // NSE F&O dates are 10 years behind
      const ist = new Date(d.getTime() + 5.5 * 3600e3); return ist.toISOString().slice(0, 10); }
    const d = new Date(s.replace(/^(\d{1,2})([A-Za-z]{3})(\d{4})$/, '$1 $2 $3')); return isNaN(d) ? '' : new Date(d.getTime() + 5.5 * 3600e3).toISOString().slice(0, 10);
  }
  /** scrip-master CSV text → [{iso, K, side, tsym, tok, ls}] for NIFTY / SENSEX options */
  function parseMaster(text, index) {
    const lines = String(text || '').split(/\r?\n/).filter(Boolean); if (lines.length < 2) return [];
    const H = csvSplit(lines[0]).map(h => h.replace(/;$/, '').trim()), ix = n => H.indexOf(n);
    const iName = ix('pSymbolName'), iTs = ix('pTrdSymbol'), iTok = ix('pSymbol'), iOpt = ix('pOptionType'), iK = ix('dStrikePrice'), iExp = ix('pExpiryDate'), iLs = ix('lLotSize');
    if (iName < 0 || iTs < 0 || iOpt < 0 || iK < 0 || iExp < 0) return [];
    const out = [];
    for (let i = 1; i < lines.length; i++) { const c = csvSplit(lines[i]); if (String(c[iName] || '').trim().toUpperCase() !== index) continue;
      const side = String(c[iOpt] || '').trim().toUpperCase(); if (side !== 'CE' && side !== 'PE') continue;
      const K = Math.round(parseFloat(c[iK]) / 100); if (!(K > 0)) continue;
      out.push({ iso: expIso(c[iExp]), K, side, tsym: String(c[iTs]).trim(), tok: String(c[iTok] || '').trim(), ls: parseInt(c[iLs]) || 0 }); }
    return out;
  }

  function createKN(deps) {
    const { http, store, Core: C, csvGet } = deps;
    const kn = {
      name: 'Kotak Neo',
      cfg: Object.assign({ key: '', mobile: '', ucc: '' }, store.get('oi.kn.cfg', {})),
      sess: store.get('oi.kn.sess', null),           // {token, sid, base, day, at}
      master: null, positions: { at: 0, list: [], err: null }, orders: { at: 0, list: [] }, funds: null, diag: [], err: null,
    };
    const today = () => C.istDate(Date.now());
    function log(what, detail) { kn.diag.unshift({ at: Date.now(), what, detail: String(detail || '').slice(0, 500) }); kn.diag.length = Math.min(kn.diag.length, 14); }
    kn.configured = () => !!kn.cfg.key;
    kn.ready = () => !!(kn.sess && kn.sess.token && kn.sess.sid && kn.sess.day === today());
    kn.saveCfg = c => { kn.cfg = Object.assign({}, kn.cfg, c); store.set('oi.kn.cfg', kn.cfg); };
    kn.logout = () => { kn.sess = null; store.set('oi.kn.sess', null); };
    const J = t => { try { return JSON.parse(t); } catch (e) { return null; } };
    const errOf = (j, d) => (j && (j.errMsg || j.emsg || j.message || j.error && (j.error[0] && j.error[0].message || j.error) || (j.data && j.data.message) || j.stat && j.stat !== 'Ok' && j.stat)) || d;

    /** step 1 (TOTP) + step 2 (MPIN) in one go; nothing but the day's session is kept */
    kn.login = async function (mobile, ucc, totp, mpin) {
      kn.err = null; if (!kn.cfg.key) throw { msg: 'Kotak Neo: save your consumer key first.' };
      let mob = String(mobile || '').replace(/\s+/g, ''); if (/^\d{10}$/.test(mob)) mob = '+91' + mob; else if (/^91\d{10}$/.test(mob)) mob = '+' + mob;
      if (!/^\+\d{11,13}$/.test(mob)) throw { msg: 'Mobile number: 10 digits (or +91…).' };
      if (!/^\d{6}$/.test(String(totp || ''))) throw { msg: 'TOTP: the 6-digit code from your authenticator app.' };
      if (!/^\d{4,6}$/.test(String(mpin || ''))) throw { msg: 'MPIN: your Kotak Neo MPIN (digits).' };
      const h1 = { 'Authorization': kn.cfg.key, 'neo-fin-key': FIN_KEY, 'Content-Type': 'application/json', 'Accept': 'application/json' };
      const r1 = await http('POST', LOGIN_HOST + '/login/1.0/tradeApiLogin', h1, JSON.stringify({ mobileNumber: mob, ucc: String(ucc || '').trim(), totp: String(totp) }));
      log('login (TOTP) HTTP ' + r1.status, (r1.text || '').replace(/"token"\s*:\s*"[^"]+"/g, '"token":"…"'));
      const j1 = J(r1.text), d1 = j1 && j1.data;
      if (!d1 || !d1.token || !d1.sid) throw { msg: 'Kotak Neo login: ' + errOf(j1, 'HTTP ' + r1.status) };
      const h2 = { 'Authorization': kn.cfg.key, 'sid': d1.sid, 'Auth': d1.token, 'neo-fin-key': FIN_KEY, 'Content-Type': 'application/json', 'Accept': 'application/json' };
      const r2 = await http('POST', LOGIN_HOST + '/login/1.0/tradeApiValidate', h2, JSON.stringify({ mpin: String(mpin) }));
      log('validate (MPIN) HTTP ' + r2.status, (r2.text || '').replace(/"token"\s*:\s*"[^"]+"/g, '"token":"…"'));
      const j2 = J(r2.text), d2 = j2 && j2.data;
      if (!d2 || !d2.token || !d2.sid) throw { msg: 'Kotak Neo MPIN check: ' + errOf(j2, 'HTTP ' + r2.status) };
      kn.sess = { token: d2.token, sid: d2.sid, base: String(d2.baseUrl || DEF_BASE).replace(/\/+$/, ''), day: today(), at: Date.now(), ucc: d2.ucc || ucc };
      store.set('oi.kn.sess', kn.sess); kn.saveCfg({ mobile: String(mobile || '').trim(), ucc: String(ucc || '').trim() });
      try { await kn.loadMaster(); } catch (e) { log('contract list', (e && e.msg) || e); }
      return true;
    };
    async function call(method, path, body) {
      if (!kn.ready()) throw { msg: 'Kotak Neo: log in for today first (Settings).', login: true };
      const h = { 'Authorization': kn.cfg.key, 'Sid': kn.sess.sid, 'Auth': kn.sess.token, 'Accept': 'application/json' };
      let payload = '';
      if (body) { h['Content-Type'] = 'application/x-www-form-urlencoded'; payload = 'jData=' + encodeURIComponent(JSON.stringify(body)); }
      const r = await http(method, kn.sess.base + '/' + path.replace(/^\//, ''), h, payload);
      log(method + ' ' + path + ' HTTP ' + r.status, r.text);
      const j = J(r.text);
      if (r.status === 401 || r.status === 403 || /invalid session|session.*expired|re-?login/i.test(String(errOf(j, '')))) { kn.logout(); throw { msg: 'Kotak Neo session ended: log in again in Settings.', login: true }; }
      if (!j) throw { msg: `Kotak Neo ${path}: no response (HTTP ${r.status}).` };
      return j;
    }

    // ---- contract list (NIFTY on NSE F&O, SENSEX on BSE F&O), once a day, kept on the phone
    kn.loadMaster = async function (force) {
      const day = today(); if (!force) { if (kn.master && kn.master.day === day) return kn.master; const S = store.get('oi.kn.master', null); if (S && S.day === day) return (kn.master = S); }
      const r = await http('GET', DEF_BASE + '/script-details/1.0/masterscrip/file-paths', { 'Authorization': kn.cfg.key, 'Accept': 'application/json' }, '');
      const j = J(r.text), files = (j && j.data && j.data.filesPaths) || [];
      log('contract files HTTP ' + r.status, files.join('\n') || r.text);
      const M = { day, NIFTY: [], SENSEX: [] };
      for (const ix of ['NIFTY', 'SENSEX']) { const f = files.find(u => new RegExp('/' + SEG[ix] + '(-v1)?\\.csv', 'i').test(u)); if (!f) continue;
        const t = await csvGet(f, ',' + ix + ',');
        M[ix] = parseMaster(t.text, ix); log(ix + ' contracts', `${M[ix].length} options (HTTP ${t.status})`); }
      if (!M.NIFTY.length && !M.SENSEX.length) throw { msg: 'Kotak Neo: contract list could not be read.' };
      kn.master = M; try { store.set('oi.kn.master', M); } catch (e) { }
      return M;
    };
    kn.contract = async function (index, iso, strike, side) {
      const M = await kn.loadMaster().catch(() => kn.master); if (!M || !M[index] || !M[index].length) throw { msg: 'Kotak Neo: contract list not loaded yet (log in first).' };
      const L = M[index].filter(x => x.K === strike && x.side === side);
      const o = L.find(x => x.iso === iso) || (L.filter(x => x.iso >= today()).sort((a, b) => a.iso < b.iso ? -1 : 1)[0]);
      if (!o) throw { msg: `Kotak Neo has no ${index} ${strike} ${side}${iso ? ' for ' + iso : ''}.` };
      if (iso && o.iso !== iso) throw { msg: `Kotak Neo: ${index} ${strike} ${side} expiry ${o.iso} does not match ${iso}. Not sent.` };
      return { exch: EXCH[index], seg: SEG[index], token: o.tok, tsym: o.tsym, ls: o.ls };
    };
    const segOf = exch => /BFO|bse_fo/i.test(exch) ? 'bse_fo' : 'nse_fo';
    const ptOf = t => /^SL-?M/i.test(t || '') ? 'SL-M' : /^SL/i.test(t || '') ? 'SL' : /MKT/i.test(t || '') ? 'MKT' : 'L';
    const ok = j => j && /^ok$/i.test(String(j.stat || '')) && (j.stCode === undefined || +j.stCode === 200);
    kn.placeOrder = async function (o) {
      const pt = ptOf(o.prctyp);
      if ((pt === 'L' || pt === 'SL') && !(Number(o.prc) > 0)) return { ok: false, err: 'Kotak Neo: a limit price is needed' };
      if (!o.tsym) return { ok: false, err: 'Kotak Neo: contract symbol missing' };
      const j = await call('POST', 'quick/order/rule/ms/place', { am: 'NO', dq: '0', es: segOf(o.exch), mp: '0', pc: o.prd === 'M' ? 'NRML' : 'MIS', pr: String(Number(o.prc) || 0), pt,
        qt: String(o.qty), rt: 'DAY', tp: String(Number(o.trgprc) || 0), ts: o.tsym, tt: o.trantype === 'S' ? 'S' : 'B', ig: 'EVCharts', os: SRC });
      if (ok(j) && j.nOrdNo) return { ok: true, no: String(j.nOrdNo) };
      return { ok: false, err: errOf(j, 'No reply from Kotak Neo') };
    };
    kn.modifyOrder = async function (o) {
      const j = await call('POST', 'quick/order/vr/modify', { mp: '0', dq: '0', vd: 'DAY', pr: String(Number(o.prc) || 0), pt: ptOf(o.prctyp), am: 'NO', tp: String(Number(o.trgprc) || 0), qt: String(o.qty), no: String(o.no), os: SRC,
        es: segOf(o.exch), ts: o.tsym, tt: o.trantype === 'S' ? 'S' : 'B', pc: o.prd === 'M' ? 'NRML' : 'MIS' });
      return ok(j) ? { ok: true, no: String(j.nOrdNo || o.no) } : { ok: false, err: errOf(j, 'Modify failed') };
    };
    kn.cancelOrder = async function (no) {
      const j = await call('POST', 'quick/order/cancel', { on: String(no), am: 'NO' });
      return ok(j) ? { ok: true } : { ok: false, err: errOf(j, 'Cancel failed') };
    };
    kn.orderBook = async function () {
      const j = await call('GET', 'quick/user/orders'), v = (j && Array.isArray(j.data)) ? j.data : [];
      kn.orders = { at: Date.now(), list: v.map(x => { const raw = String(x.ordSt || x.stat || '').toUpperCase();
        const status = /COMPLETE|TRADED|FILLED/.test(raw) ? 'COMPLETE' : /REJECT/.test(raw) ? 'REJECTED' : /CANCEL/.test(raw) ? 'CANCELED' : /TRIGGER/.test(raw) ? 'TRIGGER_PENDING' : /OPEN|PENDING|PUT ORDER|VALIDATION|MODIF/.test(raw) ? 'OPEN' : raw;
        return { no: String(x.nOrdNo || ''), tsym: String(x.trdSym || ''), side: x.trnsTp === 'S' ? 'S' : 'B', qty: parseInt(x.qty) || 0, fill: parseInt(x.fldQty) || 0, prc: parseFloat(x.prc) || 0, avg: parseFloat(x.avgPrc) || 0,
          type: String(x.prcTp || ''), prd: String(x.prod || ''), status, why: /^-+$/.test(String(x.rejRsn || '')) ? '' : String(x.rejRsn || ''), ts: String(x.ordDtTm || x.ordEntTm || '') }; }) };
      return kn.orders;
    };
    kn.loadPositions = async function () {
      if (!kn.ready()) return kn.positions;
      try { const j = await call('GET', 'portfolio/v2/positions'), v = (j && Array.isArray(j.data)) ? j.data : [];
        const M = kn.master || store.get('oi.kn.master', null);
        kn.positions.list = v.map(x => { const tsym = String(x.trdSym || ''), ls = parseInt(x.lotSz) || 1;
          const bq = (parseInt(x.cfBuyQty) || 0) + (parseInt(x.flBuyQty) || 0), sq = (parseInt(x.cfSellQty) || 0) + (parseInt(x.flSellQty) || 0);
          const buy = (parseFloat(x.cfBuyAmt) || 0) + (parseFloat(x.buyAmt) || 0), sell = (parseFloat(x.cfSellAmt) || 0) + (parseFloat(x.sellAmt) || 0), net = bq - sq;
          let f = null; if (M) for (const i of ['NIFTY', 'SENSEX']) { const o = (M[i] || []).find(y => y.tsym === tsym); if (o) { f = { i, o }; break; } }
          const avgB = bq ? buy / bq : 0, avgS = sq ? sell / sq : 0;
          return { tsym, dname: f ? `${f.i} ${f.o.K} ${f.o.side}` : '', exch: /bse/i.test(x.exSeg) ? 'BFO' : 'NFO', token: String(x.tok || ''), k: 'kn:' + String(x.tok || tsym), prd: String(x.prod || ''), qty: net,
            avg: net > 0 ? avgB : net < 0 ? avgS : 0, lp: parseFloat(x.ltp) || 0, rpnl: net === 0 ? sell - buy : 0, ls, bq, sq, avgB, avgS }; });
        kn.positions.at = Date.now(); kn.positions.err = null;
      } catch (e) { kn.positions.err = (e && e.msg) || String(e); if (e && e.login) throw e; }
      return kn.positions;
    };
    kn.limits = async function () {
      const j = await call('POST', 'quick/user/limits', { seg: 'ALL', exch: 'ALL', prod: 'ALL' });
      const avail = parseFloat(j && (j.Net || j.net || j.CollateralValue || (j.data && j.data.Net))) || 0;
      kn.funds = { at: Date.now(), avail }; return kn.funds;
    };
    kn.liveLtp = () => NaN;                         // prices come from the data feed (HDFC Sky / Flattrade / NSE-BSE)
    kn.status = function () {
      if (!kn.configured()) return 'Not set up';
      if (!kn.ready()) return 'Not logged in today';
      return `Logged in for today · orders ready${kn.master ? ` · contracts NIFTY ${kn.master.NIFTY.length}, SENSEX ${kn.master.SENSEX.length}` : ''}`;
    };
    return kn;
  }

  root.createKN = createKN;
  root.KNKit = { parseMaster, expIso, csvSplit };
})(typeof window !== 'undefined' ? window : globalThis);
