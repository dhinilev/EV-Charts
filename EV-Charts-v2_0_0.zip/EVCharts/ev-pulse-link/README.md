# EV Pulse ⇄ EV Charts link

These two files go into **EV Pulse** (not EV Charts):

- `EvChartsLink.kt` – helper with `openOption`, `openIndex`, `openStock` and `tradeFrom`
- `MANIFEST-SNIPPET.xml` – the two manifest additions

Wiring them needs EV Pulse's own screens: a "📈 Chart" button on each strike row calls
`EvChartsLink.openOption(...)`, and EV Pulse's order ticket is opened from `EvChartsLink.tradeFrom(intent)`.
Send Claude EV Pulse's `AndroidManifest.xml`, `MainActivity.kt` and the option-chain screen file, and they
come back fully edited.
