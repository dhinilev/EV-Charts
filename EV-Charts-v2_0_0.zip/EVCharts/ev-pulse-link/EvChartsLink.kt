// Add this file to EV Pulse (same folder as its MainActivity.kt) and change the
// package line below to EV Pulse's own package name.
package CHANGE.TO.EVPULSE.PACKAGE

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast

/**
 * Two-way link between EV Pulse and EV Charts.
 *
 *  EV Pulse -> EV Charts : open the candle chart of a strike / index
 *      EvChartsLink.openOption(this, "NIFTY", "2026-10-20", 23150.0, "CE")
 *      EvChartsLink.openIndex(this, "NIFTY")
 *
 *  EV Charts -> EV Pulse : "EV Pulse ▸" on a signal sends
 *      evpulse://trade?und=NIFTY&expiry=2026-10-20&strike=23150&side=CE&entry=82.5&sl=74&t1=99&t2=116&setup=...
 *  (for index signals entry/sl/t1/t2 are empty and index_entry / index_sl / index_t1 / index_t2 are filled)
 *      val req = EvChartsLink.tradeFrom(intent)  // in onCreate and onNewIntent
 *      if (req != null) { open the order ticket pre-filled; the user confirms as always }
 */
object EvChartsLink {

    fun openOption(ctx: Context, und: String, expiry: String?, strike: Double, side: String) {
        val b = Uri.Builder().scheme("evcharts").authority("chart")
            .appendQueryParameter("und", und)
            .appendQueryParameter("strike", if (strike % 1.0 == 0.0) strike.toLong().toString() else strike.toString())
            .appendQueryParameter("side", side)
        if (!expiry.isNullOrBlank()) b.appendQueryParameter("expiry", expiry) // yyyy-MM-dd
        launch(ctx, b.build())
    }

    fun openIndex(ctx: Context, key: String) =
        launch(ctx, Uri.parse("evcharts://chart?index=" + Uri.encode(key)))

    fun openStock(ctx: Context, symbol: String) =
        launch(ctx, Uri.parse("evcharts://chart?stock=" + Uri.encode(symbol)))

    private fun launch(ctx: Context, uri: Uri) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "Install or update EV Charts (v1.2+)", Toast.LENGTH_LONG).show()
        }
    }

    data class TradeRequest(
        val und: String, val expiry: String?, val strike: Double?, val side: String,
        val entry: Double?, val sl: Double?, val t1: Double?, val t2: Double?,
        val indexEntry: Double?, val indexSl: Double?, val indexT1: Double?, val indexT2: Double?,
        val setup: String?
    )

    fun tradeFrom(intent: Intent?): TradeRequest? {
        val u = intent?.data ?: return null
        if (!u.scheme.equals("evpulse", true) || !u.host.equals("trade", true)) return null
        fun d(k: String) = u.getQueryParameter(k)?.toDoubleOrNull()
        return TradeRequest(
            und = u.getQueryParameter("und") ?: return null,
            expiry = u.getQueryParameter("expiry")?.takeIf { it.isNotBlank() },
            strike = d("strike"),
            side = u.getQueryParameter("side") ?: "CE",
            entry = d("entry"), sl = d("sl"), t1 = d("t1"), t2 = d("t2"),
            indexEntry = d("index_entry"), indexSl = d("index_sl"), indexT1 = d("index_t1"), indexT2 = d("index_t2"),
            setup = u.getQueryParameter("setup")
        )
    }
}
