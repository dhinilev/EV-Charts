# EV Charts

Candlestick charts for NIFTY / SENSEX indices, index option premiums and NSE stocks, using the HDFC Sky Open API.
*An Erulenkattil Veettil Group · by Valerian*

## What it does

- **Index** – NIFTY 50, NIFTY BANK, SENSEX, FIN NIFTY, MIDCAP SELECT, BANKEX, INDIA VIX
- **Options** – pick underlying → expiry → strike (◀ ▶ steppers, ATM button) → CE / PE and chart the premium
- **Stocks** – search any NSE stock; the last 10 stay as quick chips
- Timeframes 1m, 3m, 5m, 15m, 30m, 1h, D, W (HDFC Sky serves 1-minute and daily; the rest are built on the phone)
- EMA 9, EMA 21, session VWAP, previous-day high / low / close lines, volume
- Live refresh every 20 s while the market is open
- Pinch to zoom, drag to scroll, long-press for crosshair, double-tap to jump to the latest candle
- **Buyers vs sellers (v1.1):** every candle body is split into buyer lots (green, from the bottom) and seller lots
  (red, from the top). A pane under the chart shows buyer bars ▲, seller bars ▼ and the cumulative delta (CVD) line.
  The lots box shows `B · S · Δ` for the latest candle, or for any candle under the crosshair, plus the live
  bid/ask pressure of the order book.
- **OI strip (v1.1):** a thin coloured strip under the candles. On options it shows writers adding, writers exiting,
  buyers adding or buyers exiting. On index charts it shows short buildup, short covering, long buildup or long
  unwinding of the near-month future. It works on past candles too.
- **Signals (v1.2):** ▲ BUY CE / ▼ BUY PE on index charts, BUY on option and stock charts. A signal needs a setup
  (prev-day high/low break, opening-range break, VWAP reclaim/loss, EMA 9/21 cross, absorption reversal) **and**
  agreement from buyers/sellers and the OI strip. Entry, SL, T1 (2R) and T2 (4R) are drawn on the chart; after T1 the
  SL moves to entry. Phone alert for each new signal. Signals run 09:30–14:55, max 4 a day. Past candles show how
  each signal ended (✓ / ✗) and the Signals chip shows win rate and total R for the loaded candles.
- **Writer walls & buyer walls (v1.3.1):** for ATM ±10 strikes, CE and PE, the app reads each strike's 1-minute OI
  for the whole session and splits it into writers (OI up + price down / OI down + price up) and buyers (OI up + price
  up / OI down + price down). 🧱 Writer wall = most net writer OI (call writers above spot = resistance, put writers
  below = support), ⚠ when writers are leaving. 🧲 Buyer wall = most net buyer OI (where price gets pulled). Index
  charts show bands plus a per-strike profile at each strike price (CE above the line, PE below; dark = writers,
  light = buyers). Tap the walls line for the full ladder: CE writers · CE buyers · strike · PE buyers · PE writers.
- **Live Push meter (v1.4):** a 0–100 strength score for the side with the stronger push, recalculated every second
  while the market is open: buyer/seller share, share rising, absorption, OI on that side, squeeze near a level,
  volume surge, writers leaving the wall, room to the next wall and order book. Tap it for the breakdown; the line
  shows the last 15 minutes.
- **Pre-move calls (v1.4):** when the push is 60+ and rising while price is still just short of a level (prev-day
  high/low, opening range, 30-min high/low, writer wall), a call comes with a **trigger IN** just beyond the level,
  SL, T1 (capped before the next writer wall) and T2, plus a score card. ⏳ waiting → ✅ triggered → trailing SL
  (to entry at +1R, then under higher lows, tighter as the push weakens) → exit. ⊘ Withdrawn if the push fades or
  price walks away; ⚠ Exit early if the push dies before T1. Alerts for every step. The signal log shows results by
  Push score (calls, triggered, T1 hit, win %, total R).
- **Scalp mode (v1.5, on by default):** pre-move calls with fixed OPTION PREMIUM points — SL 4, T1 +5, T2 +10;
  SL moves to entry at +3 and then trails 3 points behind the best price; Push 70+ needed; up to 15 calls a day with a
  2-minute pause after each trade; 1-minute chart by default. Option strike charts use the premium directly; index
  charts convert with ATM delta ≈ 0.5 (5 premium pts ≈ 10 NIFTY pts). All values are editable in Signals → settings.
  The ATR-based engines (close-based, early) are switched off in scalp mode so only one kind of call appears.
- **Early entries (v1.3):** breakouts (prev-day high/low, opening range, 🧱 walls on index charts) are checked on
  1-minute data and on the live, still-forming minute, so the call comes as the level breaks — inside the candle,
  not after it. Needs buyers (sellers) ≥ 60% over the last 2 minutes and no opposing OI. **No chasing:** no call when
  price is already more than half a risk past the level or the candle has already run 1.5× its normal size.
  **Cancel:** if a closed minute goes back through the level within 3 minutes, a "✗ Cancel — exit" alert follows.
- **⚡ Watch (v1.3):** heads-up while price is still just short of a level and buyers (sellers) already hold 60%+
  of the last 3 minutes.
- **Writers vs Buyers pane (v1.3):** four bars per candle from 1-minute OI — writers adding / buyers adding above the
  line, writers exiting / buyers exiting below — also shown as W+ W− B+ B− lots in the lots box. Works on past candles.
- **Patterns (v1.2):** ⚠ absorption, ✦ rejection wick, ◆ CVD divergence.
- **EV Pulse link (v1.2):** `evcharts://chart?...` opens a chart from EV Pulse; "EV Pulse ▸" on a signal sends
  `evpulse://trade?...` to EV Pulse's order ticket. The EV Pulse side is in `ev-pulse-link/`.
- **Orders from the chart (v2.0):** place and manage option trades without leaving the chart.
  - **Order window:** a buy call (✅ triggered pre-move call, or a new signal) opens a small window above the chart —
    lots (pre-filled with the most your **capital** allows: `capital ÷ (price × lot size)`), buy limit price, stop-loss and
    the floating stop-loss. On an index chart it picks the ATM CE/PE of the nearest expiry (switch CE/PE in the window).
    The **Trade ▸** button opens the same window by hand. **Nothing is sent until you tap BUY.**
  - **Brokers:** Kotak Neo, Flattrade, or **Paper** (practice — simulated fills from the live premium, no real orders).
    Set the broker, capital, product (MIS / NRML) and floating-SL values in Settings → Orders and log in once a day.
    Kotak Neo needs consumer key + mobile + UCC + TOTP + MPIN (TOTP/MPIN are never saved); Flattrade needs client ID,
    API key, secret and its redirect URL. Keys and tokens are kept in the phone's encrypted store.
  - **Buy → stop-loss:** BUY goes as a limit order. When it fills, a SELL stop-loss (SL-LMT: trigger = your SL, limit =
    SL − the "SL limit below trigger" buffer, default 3 pts) is placed at the broker. The entry, SL and live P&L are drawn on
    the option chart with an order marker on the candle.
  - **Drag the SL:** grab the red SL line on the chart and drop it — the broker's SL order is modified. It must stay below
    the price. Dragging the SL *down* pauses the floating SL.
  - **Floating SL:** every time the price is *X* points above the SL, the SL moves up *Y* points (default 10 / 5), and the
    broker's SL order is modified each time. It never moves down. It runs while the app is open.
  - **Exit / cancel:** the trade bar has Exit (two taps: cancels the SL, sells with a limit 1 pt under the price) and
    Cancel buy while the entry waits. ✕ stops tracking only — orders already at the broker stay.
  - NIFTY and SENSEX options, buying only, one trade at a time.
- **Full-screen chart (v2.0):** turn the phone sideways and the chart takes the whole screen (status/navigation bars hidden,
  menus out of the way). The ⛶ button does the same in portrait, and leaves full screen in landscape.

## One-time setup on HDFC Sky

1. Log in at **developer.hdfcsky.com** → **My Apps** → **+ Create**.
2. **Redirect URL:** `https://evcharts.app/callback` (any https URL works, but it must be identical in the app's Settings).
3. **APIs in this app:** keep *Trading API* selected.
4. **Primary Static IP:** the form makes this mandatory (SEBI rule). See *Static IP note* below.
5. Click **Create**, then **activate** the app in My Apps (new apps start deactivated). Copy the **API Key** and **API Secret**.

## In the app

1. Open EV Charts → ⚙ Settings → paste the API Key, API Secret and Redirect URL → **Save keys**.
2. The HDFC Sky login page opens → Client ID → OTP. You are returned to the app automatically.
3. The contract list (~17 MB) downloads once a day so new expiries and strikes appear.
4. Log in again each trading day (HDFC Sky sessions are daily).

## Build

Upload the EV Charts zip to the GitHub repo as it is (no need to unzip). The workflow in `.github/workflows/main.yml`
unzips the newest `EV-Charts-*.zip` and builds it on every push to `main`; download **EV-Charts-apk** from the run's
Artifacts. The APK is signed with `app/ev-charts.keystore` so each new
build installs over the previous one. Keep the repo private, because this key file is stored in it.

## How buyers and sellers are separated

The app listens to HDFC Sky's live tick feed. Each new trade is classified against the order book it hit:

- traded at or above the best ask → a buyer was in a hurry → **buyer lots**
- traded at or below the best bid → a seller was in a hurry → **seller lots**
- in between → the price direction decides (up = buyer, down = seller)

Index charts take the split from the near-month **NIFTY / SENSEX future**, because the index itself does not trade.
The split is collected only while the app is open and logged in, from the moment you open it each day; earlier
candles show normally. What was collected is saved, so closing and reopening the app the same day keeps it.

## Static IP note

SEBI's API rules make HDFC Sky ask for a static IP. A phone on mobile data or home Wi-Fi does not have one. If HDFC Sky
enforces the IP on market-data calls as well as orders, chart requests will fail with an HTTP error, which the app
shows on the chart. In that case the requests have to go through a small server or VPN that has a static IP.

## Files

| Path | What |
|---|---|
| `app/src/main/assets/www/` | Chart screen (HTML/JS), chart engine `chart.js`, indicators `data.js` |
| `app/src/main/java/.../HdfcSky.kt` | Login token exchange, candles, LTP |
| `app/src/main/java/.../ContractMaster.kt` | Contract-list download and lookup |
| `app/src/main/java/.../LoginActivity.kt` | HDFC Sky login page and redirect capture |
| `app/src/main/java/.../SecureStore.kt` | Keystore-encrypted storage for keys and session |

Opening `app/src/main/assets/www/index.html` in a desktop browser runs the UI with demo data.
