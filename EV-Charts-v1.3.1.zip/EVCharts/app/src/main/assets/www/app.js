/* EV Charts — screen logic. */
(function () {
  'use strict';

  const D = window.EVData;
  const $ = (id) => document.getElementById(id);

  const TF = {
    '1m': { minutes: 1, chartType: 'MINUTE', days: 4 },
    '3m': { minutes: 3, chartType: 'MINUTE', days: 7 },
    '5m': { minutes: 5, chartType: 'MINUTE', days: 12 },
    '15m': { minutes: 15, chartType: 'MINUTE', days: 25 },
    '30m': { minutes: 30, chartType: 'MINUTE', days: 30 },
    '1h': { minutes: 60, chartType: 'MINUTE', days: 30 },
    'D': { daily: true, chartType: 'DAY', days: 730 },
    'W': { daily: true, weekly: true, chartType: 'DAY', days: 1900 },
  };
  const REFRESH_MS = 20000;

  /* ---------- tiny storage helper (WebView storage can be unavailable) ---------- */
  const store = {
    get(k, d) { try { const v = localStorage.getItem('evc.' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('evc.' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
  };

  const S = {
    status: null,
    mode: store.get('mode', 'index'),
    tf: store.get('tf', '5m'),
    ind: Object.assign({ ema9: true, ema21: true, vwap: false, pdl: true, vol: true, bs: true, strip: true, sig: true, pat: true, walls: true, wb: true }, store.get('ind', {})),
    sig: Object.assign({}, window.EVSignals.DEFAULTS, store.get('sig', {})),
    sigResult: null,
    alerted: new Set(store.get('alerted.' + D.ymd(D.istNow()), [])),
    chain: null,      // {und, expiry, exchange, lot, rows:[{strike, ceKey, peKey}], keys}
    wm: null,         // walls & magnets
    chainTimer: null,
    inst: { index: null, option: null, stock: null },
    indices: [],
    opt: { und: store.get('opt.und', 'NIFTY'), expiry: null, side: store.get('opt.side', 'CE'), chain: null, strikeIdx: -1, spot: null },
    recents: store.get('recents', []),
    raw: [],
    bars: [],
    flowMin: new Map(),   // minute -> [buyQty, sellQty] from the live feed
    flowKey: null,        // scripId whose trades are being split
    flowBars: [],
    book: null,           // pending buy / sell quantity in the order book
    futRaw: [],           // index future candles (for the OI strip on index charts)
    strip: null,
    feedStatus: '',
    reqSeq: 0,
    refreshTimer: null,
    loading: false,
    masterBusy: false,
  };

  /* ---------- chart ---------- */
  const chart = new window.EVChart($('chart'), { onCrosshair: showOhlc });
  setInterval(() => { // show the "Latest" button when scrolled into the past
    $('latestBtn').classList.toggle('show', chart.rightOffset < -3);
  }, 400);
  $('latestBtn').onclick = () => chart.goLatest();

  /* ---------- formatting ---------- */
  const fmt = (v, dec) => (v == null || !isFinite(v)) ? '—'
    : v.toLocaleString('en-IN', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  const decFor = (p) => (p < 1000 ? 2 : p < 10000 ? 2 : 1);
  const fmtVol = (v) => v >= 1e7 ? (v / 1e7).toFixed(2) + ' Cr' : v >= 1e5 ? (v / 1e5).toFixed(2) + ' L' : v >= 1e3 ? (v / 1e3).toFixed(1) + ' K' : String(v);

  let toastTimer = null;
  function toast(msg, ms = 2600) {
    const t = $('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), ms);
  }

  function overlay(text, spin) {
    const o = $('overlay');
    if (!text) { o.classList.remove('show'); return; }
    $('overlayText').textContent = text;
    $('overlaySpin').style.display = spin ? '' : 'none';
    o.classList.add('show');
  }

  /* ---------- status / banner ---------- */
  async function refreshStatus() {
    try { S.status = await EV.call('status'); } catch (e) { S.status = null; }
    const st = S.status || {};
    const on = !!st.loggedIn;
    updateConn();
    $('stSession').textContent = !st.hasKeys ? 'API key not set' : on ? `Logged in (${st.loginDate || 'today'})` : 'Not logged in';
    const m = st.master || {};
    $('stMaster').textContent = m.ready ? `${(m.count || 0).toLocaleString('en-IN')} instruments · ${m.date}` : 'Not downloaded';
    if (st.apiKey && !$('apiKey').value) $('apiKey').value = st.apiKey;
    if (!$('redirectUrl').value) $('redirectUrl').value = st.redirectUrl || 'https://evcharts.app/callback';
    $('logoutBtn').disabled = !on;
    $('masterBtn').disabled = !on || S.masterBusy;
    updateBanner();
    return st;
  }

  function updateBanner() {
    const st = S.status || {};
    let text = '', btn = '', action = null;
    if (!st.hasKeys) { text = 'Add your HDFC Sky API key and secret to start.'; btn = 'Settings'; action = openSheet; }
    else if (!st.loggedIn) { text = 'Login to HDFC Sky to load charts. Sessions last one trading day.'; btn = 'Login'; action = doLogin; }
    else if (!(st.master || {}).ready) { text = S.masterBusy ? 'Downloading today\'s contract list…' : 'Download today\'s contract list (about 17 MB).'; btn = 'Download'; action = downloadMaster; }
    $('banner').classList.toggle('show', !!text);
    $('bannerText').textContent = text;
    $('bannerBtn').textContent = btn;
    $('bannerBtn').disabled = S.masterBusy;
    $('bannerBtn').onclick = action;
  }

  function ready() {
    const st = S.status || {};
    return st.loggedIn && (st.master || {}).ready;
  }

  /* ---------- login / master ---------- */
  async function doLogin() {
    try { await EV.call('login'); } catch (e) { toast(e.message); }
  }

  EV.on('login', async (res) => {
    if (res && res.ok) {
      toast('Logged in to HDFC Sky');
      const st = await refreshStatus();
      const today = D.ymd(D.istNow());
      if (!(st.master || {}).ready || st.master.date !== today) await downloadMaster();
      else await boot();
    } else {
      toast((res && res.error) || 'Login was not completed', 4000);
      refreshStatus();
    }
  });

  EV.on('master', (p) => {
    $('masterProg').classList.add('show');
    $('masterProg').firstElementChild.style.width = (p.pct || 0) + '%';
    if (p.stage) $('bannerText').textContent = p.stage;
  });

  async function downloadMaster() {
    if (S.masterBusy) return;
    S.masterBusy = true;
    updateBanner();
    overlay('Downloading contract list…', true);
    try {
      const r = await EV.call('downloadMaster');
      toast(`Contract list ready · ${(r.count || 0).toLocaleString('en-IN')} instruments`);
    } catch (e) {
      toast('Contract list failed: ' + e.message, 5000);
    } finally {
      S.masterBusy = false;
      $('masterProg').classList.remove('show');
      overlay('');
      await refreshStatus();
      if (ready()) boot();
    }
  }

  /* ---------- settings sheet ---------- */
  function openSheet() { refreshStatus(); $('sheet').classList.add('show'); $('sheetBg').classList.add('show'); }
  function closeSheet() { $('sheet').classList.remove('show'); $('sigSheet').classList.remove('show'); $('ladderSheet').classList.remove('show'); $('sheetBg').classList.remove('show'); }
  $('settingsBtn').onclick = openSheet;
  $('sheetBg').onclick = closeSheet;
  $('loginBtn').onclick = () => { closeSheet(); doLogin(); };
  $('logoutBtn').onclick = async () => { await EV.call('logout'); stopRefresh(); toast('Logged out'); refreshStatus(); };
  $('masterBtn').onclick = () => { closeSheet(); downloadMaster(); };
  $('saveBtn').onclick = async () => {
    const apiKey = $('apiKey').value.trim();
    const apiSecret = $('apiSecret').value.trim();
    const redirectUrl = $('redirectUrl').value.trim();
    if (!apiKey || !redirectUrl) { toast('API key and redirect URL are required'); return; }
    if (!/^https?:\/\//i.test(redirectUrl)) { toast('Redirect URL must start with https://'); return; }
    try {
      await EV.call('saveSettings', { apiKey, apiSecret, redirectUrl });
      $('apiSecret').value = '';
      toast('Keys saved');
      const st = await refreshStatus();
      if (st.hasKeys && !st.loggedIn) { closeSheet(); doLogin(); }
    } catch (e) { toast(e.message, 4000); }
  };

  /* ---------- tabs ---------- */
  function setMode(mode, load = true) {
    S.mode = mode;
    store.set('mode', mode);
    document.querySelectorAll('#tabs button').forEach((b) => b.classList.toggle('active', b.dataset.mode === mode));
    $('pickIndex').hidden = mode !== 'index';
    $('pickOption').hidden = mode !== 'option';
    $('pickStock').hidden = mode !== 'stock';
    if (!load || !ready()) return;
    if (mode === 'index') setupIndex();
    if (mode === 'option') setupOptions();
    if (mode === 'stock') setupStocks();
  }
  document.querySelectorAll('#tabs button').forEach((b) => { b.onclick = () => setMode(b.dataset.mode); });

  /* ---------- index ---------- */
  async function setupIndex() {
    if (!S.indices.length) {
      try { S.indices = await EV.call('indices'); } catch (e) { toast(e.message); return; }
    }
    const chips = $('indexChips');
    chips.innerHTML = '';
    const saved = store.get('index.key', 'NIFTY');
    for (const ix of S.indices) {
      const b = document.createElement('button');
      b.className = 'chip';
      b.textContent = ix.label;
      b.dataset.key = ix.key;
      b.onclick = () => pickIndex(ix);
      chips.appendChild(b);
    }
    const ix = S.indices.find((i) => i.key === (S.inst.index && S.inst.index.key)) || S.indices.find((i) => i.key === saved) || S.indices[0];
    if (ix) pickIndex(ix);
  }

  function pickIndex(ix) {
    store.set('index.key', ix.key);
    document.querySelectorAll('#indexChips .chip').forEach((c) => c.classList.toggle('active', c.dataset.key === ix.key));
    const fut = ix.future || null;
    S.inst.index = {
      key: ix.key, title: ix.label, sub: `${ix.exchange} · Index` + (fut ? ` · flow from ${fut.symbol}` : ''),
      chartSymbols: ix.chartSymbols, exchange: ix.exchange, series: ix.series,
      ltpExchange: ix.ltpExchange, token: ix.token,
      flowKey: fut ? `${fut.exchange}_${fut.token}` : null, lot: fut ? (fut.lot || 1) : 1, unit: 'lots',
      oiSource: fut ? { chartSymbols: [fut.symbol], exchange: fut.exchange, series: fut.series } : null,
      stripKind: 'futures', kind: 'index',
      priceKey: ix.token ? `${ix.ltpExchange}_${ix.token}` : null, // live index ticks for the forming candle
    };
    if (S.mode === 'index') loadChart();
  }

  /* ---------- options ---------- */
  let undList = null;
  async function setupOptions() {
    if (!undList) {
      try { undList = await EV.call('optionUnderlyings'); } catch (e) { toast(e.message); return; }
    }
    const chips = $('undChips');
    chips.innerHTML = '';
    for (const u of undList) {
      const b = document.createElement('button');
      b.className = 'chip'; b.textContent = u; b.dataset.u = u;
      b.onclick = () => pickUnderlying(u);
      chips.appendChild(b);
    }
    if (S.opt.chain && S.inst.option) { markUnd(); loadChart(); return; }
    pickUnderlying(undList.includes(S.opt.und) ? S.opt.und : undList[0]);
  }

  function markUnd() {
    document.querySelectorAll('#undChips .chip').forEach((c) => c.classList.toggle('active', c.dataset.u === S.opt.und));
  }

  async function pickUnderlying(u) {
    S.opt.und = u; store.set('opt.und', u); markUnd();
    const sel = $('expirySel');
    sel.innerHTML = '<option>Loading…</option>';
    let exps = [];
    try { exps = await EV.call('optionExpiries', { underlying: u }); } catch (e) { toast(e.message); return; }
    sel.innerHTML = '';
    const today = D.ymd(D.istNow());
    exps.forEach((x, i) => {
      const o = document.createElement('option');
      const d = new Date(x + 'T00:00:00Z');
      const label = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: '2-digit', timeZone: 'UTC' });
      o.value = x; o.textContent = label + (x === today ? '  · Expiry today' : i === 0 ? '  · Nearest' : '');
      sel.appendChild(o);
    });
    if (!exps.length) { sel.innerHTML = '<option>No expiries</option>'; return; }
    const want = S.pendingExpiry && exps.includes(S.pendingExpiry) ? S.pendingExpiry : exps[0];
    S.pendingExpiry = null;
    S.opt.expiry = want;
    sel.value = want;
    await loadChain(true);
  }

  $('expirySel').onchange = async (e) => { S.opt.expiry = e.target.value; await loadChain(false); };

  async function loadChain(goAtm) {
    const prevStrike = S.opt.chain && S.opt.strikeIdx >= 0 ? S.opt.chain.strikes[S.opt.strikeIdx].strike : null;
    try {
      S.opt.chain = await EV.call('optionChain', { underlying: S.opt.und, expiry: S.opt.expiry });
    } catch (e) { toast(e.message); return; }
    S.opt.spot = null;
    try {
      const sp = S.opt.chain.spot;
      if (sp) {
        const q = await EV.call('ltp', { items: [sp] });
        if (q && q[0] && q[0].ltp > 0) S.opt.spot = q[0].ltp;
      }
    } catch (e) { /* ATM falls back to the middle strike */ }
    const strikes = S.opt.chain.strikes;
    const atmIdx = atmIndex();
    let idx = atmIdx;
    if (S.pendingStrike != null) {
      const k = strikes.findIndex((s) => Math.abs(s.strike - S.pendingStrike) < 1e-6);
      if (k >= 0) idx = k;
      S.pendingStrike = null;
    } else if (!goAtm && prevStrike != null) {
      const k = strikes.findIndex((s) => s.strike === prevStrike);
      if (k >= 0) idx = k;
    }
    const sel = $('strikeSel');
    sel.innerHTML = '';
    strikes.forEach((s, i) => {
      const o = document.createElement('option');
      o.value = i;
      const tag = i === atmIdx ? '  · ATM' : '';
      o.textContent = fmt(s.strike, s.strike % 1 ? 1 : 0) + tag;
      sel.appendChild(o);
    });
    setStrike(idx);
  }

  function atmIndex() {
    const strikes = (S.opt.chain || {}).strikes || [];
    if (!strikes.length) return -1;
    if (!S.opt.spot) return Math.floor(strikes.length / 2);
    let best = 0;
    strikes.forEach((s, i) => { if (Math.abs(s.strike - S.opt.spot) < Math.abs(strikes[best].strike - S.opt.spot)) best = i; });
    return best;
  }

  function setStrike(idx) {
    const strikes = (S.opt.chain || {}).strikes || [];
    if (!strikes.length) return;
    idx = Math.max(0, Math.min(strikes.length - 1, idx));
    S.opt.strikeIdx = idx;
    $('strikeSel').value = String(idx);
    buildOptionInstrument();
  }

  function buildOptionInstrument() {
    const ch = S.opt.chain;
    const s = ch.strikes[S.opt.strikeIdx];
    const leg = S.opt.side === 'CE' ? s.ce : s.pe;
    if (!leg) { toast(`No ${S.opt.side} at this strike`); return; }
    const d = new Date(S.opt.expiry + 'T00:00:00Z');
    const exp = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', timeZone: 'UTC' });
    const spot = S.opt.spot ? ` · Spot ${fmt(S.opt.spot, 2)}` : '';
    S.inst.option = {
      title: `${S.opt.und} ${exp} ${fmt(s.strike, s.strike % 1 ? 1 : 0)} ${S.opt.side}`,
      sub: `${ch.exchange} · Lot ${ch.lot || '—'}${spot}`,
      chartSymbols: [leg.symbol], exchange: ch.exchange, series: ch.series,
      ltpExchange: ch.exchange, token: leg.token,
      flowKey: `${ch.exchange}_${leg.token}`, lot: ch.lot || 1, unit: 'lots', stripKind: 'option',
      kind: 'option', side: S.opt.side, und: S.opt.und, expiry: S.opt.expiry, strike: s.strike,
      priceKey: `${ch.exchange}_${leg.token}`,
    };
    if (S.mode === 'option') loadChart();
  }

  $('strikeSel').onchange = (e) => setStrike(+e.target.value);
  $('strikeDown').onclick = () => setStrike(S.opt.strikeIdx - 1);
  $('strikeUp').onclick = () => setStrike(S.opt.strikeIdx + 1);
  $('atmBtn').onclick = () => setStrike(atmIndex());
  function setSide(side) {
    S.opt.side = side; store.set('opt.side', side);
    $('ceBtn').classList.toggle('active', side === 'CE');
    $('peBtn').classList.toggle('active', side === 'PE');
    if (S.opt.chain) buildOptionInstrument();
  }
  $('ceBtn').onclick = () => setSide('CE');
  $('peBtn').onclick = () => setSide('PE');
  setSide(S.opt.side);

  /* ---------- stocks ---------- */
  let searchTimer = null;
  function setupStocks() {
    renderRecents();
    if (S.inst.stock) loadChart();
    else if (S.recents.length) pickStock(S.recents[0]);
    else { clearChart('Search for a stock above'); setTimeout(() => $('stockInput').focus(), 50); }
  }

  $('stockInput').addEventListener('input', () => {
    clearTimeout(searchTimer);
    const q = $('stockInput').value.trim();
    if (q.length < 2) { $('stockResults').classList.remove('open'); return; }
    searchTimer = setTimeout(async () => {
      let list = [];
      try { list = await EV.call('searchStocks', { q }); } catch (e) { toast(e.message); return; }
      const box = $('stockResults');
      box.innerHTML = '';
      if (!list.length) box.innerHTML = '<button disabled><small>No match</small></button>';
      for (const it of list) {
        const b = document.createElement('button');
        b.innerHTML = `<b></b><small></small>`;
        b.firstChild.textContent = it.symbol;
        b.lastChild.textContent = it.name;
        b.onclick = () => { box.classList.remove('open'); $('stockInput').value = ''; $('stockInput').blur(); pickStock(it); };
        box.appendChild(b);
      }
      box.classList.add('open');
    }, 200);
  });
  document.addEventListener('pointerdown', (e) => {
    if (!e.target.closest('.search')) $('stockResults').classList.remove('open');
  });

  function renderRecents() {
    const box = $('recentChips');
    box.innerHTML = '';
    for (const it of S.recents) {
      const b = document.createElement('button');
      b.className = 'chip' + (S.inst.stock && S.inst.stock.key === it.symbol ? ' active' : '');
      b.textContent = it.symbol;
      b.onclick = () => pickStock(it);
      box.appendChild(b);
    }
  }

  function pickStock(it) {
    S.recents = [it].concat(S.recents.filter((r) => r.symbol !== it.symbol)).slice(0, 10);
    store.set('recents', S.recents);
    S.inst.stock = {
      key: it.symbol, title: it.symbol, sub: `${it.exchange} · ${it.name}`,
      chartSymbols: [it.symbol], exchange: it.exchange, series: it.series || 'EQ',
      ltpExchange: it.exchange, token: it.token,
      flowKey: `${it.exchange}_${it.token}`, lot: 1, unit: 'shares', stripKind: null, kind: 'stock',
      priceKey: `${it.exchange}_${it.token}`,
    };
    renderRecents();
    if (S.mode === 'stock') loadChart();
  }

  /* ---------- timeframe + indicators ---------- */
  function markTf() {
    document.querySelectorAll('#tfBar button').forEach((b) => b.classList.toggle('active', b.dataset.tf === S.tf));
  }
  document.querySelectorAll('#tfBar button').forEach((b) => {
    b.onclick = () => { S.tf = b.dataset.tf; store.set('tf', S.tf); markTf(); loadChart(); };
  });
  markTf();

  function markInd() {
    document.querySelectorAll('#indBar button').forEach((b) => b.classList.toggle('active', !!S.ind[b.dataset.ind]));
  }
  document.querySelectorAll('#indBar button').forEach((b) => {
    b.onclick = () => {
      S.ind[b.dataset.ind] = !S.ind[b.dataset.ind]; store.set('ind', S.ind); markInd(); applyIndicators(); showOhlc(null);
      const inst = current();
      if ((b.dataset.ind === 'strip' || b.dataset.ind === 'bs') && S.ind[b.dataset.ind] && inst && inst.oiSource && !S.futRaw.length) loadFutures(inst, S.reqSeq, false);
      if (b.dataset.ind === 'walls') { S.chain = null; setupChain(inst); }
    };
  });
  markInd();

  function applyIndicators() {
    const bars = S.bars;
    const tf = TF[S.tf];
    const ov = [];
    const legend = [];
    const cs = getComputedStyle(document.documentElement);
    const col = (n) => cs.getPropertyValue(n).trim();
    if (S.ind.ema9) { ov.push({ values: D.ema(bars, 9), color: col('--ema1') }); legend.push(['EMA 9', col('--ema1')]); }
    if (S.ind.ema21) { ov.push({ values: D.ema(bars, 21), color: col('--ema2') }); legend.push(['EMA 21', col('--ema2')]); }
    const volOk = D.hasVolume(bars);
    if (S.ind.vwap && tf.minutes && volOk) { ov.push({ values: D.vwap(bars), color: col('--vwap'), breakDaily: true }); legend.push(['VWAP', col('--vwap')]); }
    chart.setOverlays(ov);

    const levels = [];
    if (S.ind.pdl && tf.minutes) {
      const pd = D.previousDayLevels(S.raw);
      if (pd) {
        levels.push({ value: pd.h, label: 'PDH', color: '#26a69a' });
        levels.push({ value: pd.l, label: 'PDL', color: '#ef5350' });
        levels.push({ value: pd.c, label: 'PDC', color: '#90a4ae' });
      }
    }
    chart.setLevels(levels);
    chart.setVolume(S.ind.vol && volOk);

    // buyers / sellers
    // Live (real) split where trades were recorded; estimated split for older candles.
    const realFlow = D.flowPerBar(bars, S.flowMin, tf);
    let estFlow = null;
    const fi = current();
    if (S.ind.bs && fi) {
      if (fi.oiSource) { if (S.futRaw.length) estFlow = D.estimateFlow(bars, D.resample(S.futRaw, tf)); }
      else if (D.hasVolume(bars)) estFlow = D.estimateFlow(bars, null);
    }
    S.flowBars = realFlow.map((f, i) => f || (estFlow && estFlow[i]) || null);
    chart.setFlow(S.flowBars, D.cumulativeDelta(bars, S.flowBars), S.ind.bs);

    // writers / buyers strip from OI
    S.strip = null;
    const inst = current();
    if (S.ind.strip && inst && inst.stripKind) {
      if (inst.oiSource) {
        if (S.futRaw.length) S.strip = D.oiBuildup(bars, D.resample(S.futRaw, tf));
      } else if (D.hasOi(bars)) {
        S.strip = D.oiBuildup(bars);
      }
    }
    chart.setStrip(S.strip);

    // writers / buyers OI per candle, from 1-minute OI (option itself, or the index future)
    const oiRaw = inst && tf.minutes ? (inst.oiSource ? S.futRaw : inst.kind === 'option' ? S.raw : null) : null;
    S.oiMap = oiRaw && oiRaw.length ? D.oiMinuteMap(oiRaw) : null;
    S.wbBars = S.ind.wb && S.oiMap ? D.writersBuyers(bars, S.oiMap, tf) : null;
    chart.setWB(S.wbBars);

    // pattern markers + BUY CE / PE signals (intraday timeframes)
    const cvd = D.cumulativeDelta(bars, S.flowBars);
    chart.setMarkers(S.ind.pat && tf.minutes ? window.EVSignals.patterns(bars, S.flowBars, cvd) : []);
    S.sigResult = null;
    if (S.ind.sig && tf.minutes && inst) {
      const nowIst = D.istNow();
      const last = bars[bars.length - 1];
      const forming = last && D.isMarketOpen() && last.t + tf.minutes * 60 > nowIst;
      const closeBased = window.EVSignals.signals({
        bars, raw: S.raw, flow: S.flowBars, strip: S.strip,
        ema9: D.ema(bars, 9), ema21: D.ema(bars, 21), vwap: volOk ? D.vwap(bars) : null,
        kind: inst.kind, stripKind: inst.stripKind,
        // with early entries on, breakouts are handled by the 1-minute engine
        settings: Object.assign({}, S.sig, S.sig.early ? { pdh: false, orb: false } : {}),
        closed: forming ? bars.length - 1 : bars.length,
        sessionOver: !D.isMarketOpen(),
      });
      // 1-minute early engine: fires inside the candle, with ⚡ watch before the level
      const lastRaw = S.raw[S.raw.length - 1];
      const ear = S.sig.early && S.raw.length ? window.EVSignals.early({
        raw: S.raw, live: !!lastRaw && D.isMarketOpen() && lastRaw.t >= nowIst - (nowIst % 60) - 60,
        flowMin: S.flowMin, volBars: inst.oiSource ? S.futRaw : S.raw, oiMap: S.oiMap,
        walls: inst.kind === 'index' && S.wm && S.wm.live ? S.wm.walls : null,
        kind: inst.kind, stripKind: inst.stripKind, settings: S.sig, sessionOver: !D.isMarketOpen(),
      }) : { signals: [], watch: null };
      const pos = new Map(bars.map((b, k) => [b.t, k]));
      const tfIndex = (t) => { const k = pos.get(D.bucketOf(t, tf)); return k === undefined ? null : k; };
      for (const sg of ear.signals) { sg.i = tfIndex(sg.t); sg.exitI = sg.exitT != null ? tfIndex(sg.exitT) : null; }
      const earlyList = ear.signals.filter((sg) => sg.i != null);
      // drop close-based signals that fall inside an early trade
      const inEarly = (t) => earlyList.some((e) => t >= e.t && (e.exitT == null || t <= e.exitT));
      const merged = earlyList.concat(closeBased.signals.filter((sg) => !inEarly(sg.t))).sort((a, b) => a.t - b.t);
      S.sigResult = { signals: merged, stats: window.EVSignals.stats(merged), watch: ear.watch };
      for (const sg of S.sigResult.signals) sg.label = signalLabel(inst, sg) + (sg.mode === 'early' ? ' ⚡' : '');
      checkWallsAgainst(S.sigResult.signals, inst);
    }
    chart.setSignals(S.sigResult ? S.sigResult.signals : []);
    renderSignalCard();
    maybeAlert();

    if (S.strip && S.strip.some(Boolean)) {
      const names = inst.stripKind === 'futures' ? STRIP_NAMES_FUT : STRIP_NAMES_OPT;
      for (const k of ['WA', 'WE', 'BA', 'BE']) legend.push([names[k], window.EVChart.STRIP_COLORS[k]]);
    }
    const lg = $('legend');
    lg.innerHTML = '';
    for (const [name, c] of legend) {
      const s = document.createElement('span');
      s.textContent = name; s.style.setProperty('--c', c);
      lg.appendChild(s);
    }
    if (S.ind.vwap && tf.minutes && !volOk) {
      const s = document.createElement('span'); s.textContent = 'VWAP needs volume (not for indices)'; s.style.setProperty('--c', 'transparent');
      lg.appendChild(s);
    }
  }

  /* ---------- signals: labels, card, log, alerts ---------- */
  const STEP = { NIFTY: 50, BANKNIFTY: 100, FINNIFTY: 50, MIDCPNIFTY: 25, SENSEX: 100, BANKEX: 100 };
  const atmOf = (inst, px) => { const st = STEP[inst.key] || 50; return Math.round(px / st) * st; };

  function signalLabel(inst, sg) {
    if (inst.kind === 'index') return sg.dir > 0 ? `BUY ${atmOf(inst, sg.entry)} CE` : `BUY ${atmOf(inst, sg.entry)} PE`;
    if (inst.kind === 'option') return `BUY ${inst.side}`;
    return 'BUY';
  }

  // Index signals: warn when a wall sits between entry and T1.
  function checkWallsAgainst(list, inst) {
    if (!S.wm || inst.kind !== 'index') return;
    const today = Math.floor(D.istNow() / 86400);
    for (const sg of list) {
      if (sg.status !== 'open' || Math.floor(sg.t / 86400) !== today) continue;
      const wall = S.wm.walls.find((w) => w.rank === 0 && w.role === (sg.dir > 0 ? 'resistance' : 'support'));
      if (wall && sg.dir * (wall.strike - sg.entry) > 0 && sg.dir * (sg.t1 - wall.strike) > 0) sg.wallWarn = wall.strike;
    }
  }

  const fmtTime = (t) => { const d = new Date(t * 1000); return `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`; };
  const STATUS_TEXT = { open: 'Live', sl: '✗ Stop-loss hit', be: '✓ T1 hit, rest out at entry', t2: '✓✓ T2 hit', eod: 'Closed at day end', cancel: '✗ Cancelled (fake breakout)' };

  function sigLevels(sg, inst) {
    const dec = decFor(sg.entry) > 1 && sg.entry > 1000 ? 0 : decFor(sg.entry);
    let html = `<div class="lv"><span class="in">IN <b>${fmt(sg.entry, dec)}</b></span>` +
      `<span class="sl">SL <b>${fmt(sg.sl, dec)}</b></span>` +
      `<span class="tg">T1 <b>${fmt(sg.t1, dec)}</b></span>` +
      `<span class="tg">T2 <b>${fmt(sg.t2, dec)}</b></span>` +
      `<span class="rk">risk ${fmt(sg.risk, dec)}</span></div>`;
    if (inst.kind === 'index') {
      // ATM option moves roughly half as much as the index (delta ≈ 0.5)
      html += `<div class="sub">ATM ${sg.dir > 0 ? 'CE' : 'PE'} premium ≈ SL −₹${fmt(sg.risk * 0.5, 1)} · T1 +₹${fmt(sg.risk * sg.rr1 * 0.5, 1)} · T2 +₹${fmt(sg.risk * sg.rr2 * 0.5, 1)}</div>`;
    }
    return html;
  }

  function sigWhy(sg, inst) {
    const parts = [sg.name];
    if (sg.share != null) parts.push(`${sg.dir > 0 ? 'Buyers' : 'Sellers'} ${Math.round((sg.dir > 0 ? sg.share : 1 - sg.share) * 100)}%`);
    if (sg.strip) parts.push((inst.stripKind === 'futures' ? STRIP_LONG_FUT : STRIP_LONG_OPT)[sg.strip]);
    return parts.join(' · ');
  }

  function renderSignalCard() {
    const card = $('sigCard');
    const inst = current();
    const res = S.sigResult;
    const chip = $('sigChip');
    if (!res || !inst) { card.classList.remove('show'); chip.hidden = true; return; }
    const st = res.stats;
    chip.hidden = false;
    chip.textContent = st.closed ? `Signals ${st.count} · ${st.winRate}% win · ${st.totalR >= 0 ? '+' : ''}${st.totalR.toFixed(1)}R` : `Signals ${st.count}`;
    const lastBar = S.bars[S.bars.length - 1];
    const today = lastBar ? Math.floor(lastBar.t / 86400) : Math.floor(D.istNow() / 86400); // latest session day
    const sg = st.open || (res.watch ? null : res.signals.filter((x) => Math.floor(x.t / 86400) === today).slice(-1)[0]);
    if (!sg && res.watch) {
      const w = res.watch;
      const what = w.wall ? `${w.dir > 0 ? 'call' : 'put'} wall ${fmt(w.level, 0)}${w.weak ? ' (weakening)' : ''}` : levelName(w.name, w.level);
      card.className = 'sig-card show watch';
      card.innerHTML = `<div class="hd"><b>⚡ Watch ${w.dir > 0 ? '▲' : '▼'}</b><span>${fmtTime(w.t)} · get ready</span></div>` +
        `<div class="sub">Price ${fmt(w.price, decFor(w.price))} is ${fmt(w.gap, decFor(w.price))} from ${what} · ${w.dir > 0 ? 'buyers' : 'sellers'} ${Math.round((w.dir > 0 ? w.share : 1 - w.share) * 100)}% last 3 min${w.real ? '' : ' (est.)'}</div>`;
      card.onclick = null;
      return;
    }
    if (!sg) { card.classList.remove('show'); return; }
    const up = sg.dir > 0;
    card.className = 'sig-card show ' + (up ? 'bull' : 'bear');
    const state = sg.status === 'open' ? (sg.t1Hit ? 'Live · T1 hit, SL at entry' : 'Live')
      : `${STATUS_TEXT[sg.status]} · ${sg.r >= 0 ? '+' : ''}${sg.r.toFixed(1)}R`;
    card.innerHTML =
      `<div class="hd"><b>${up ? '▲' : '▼'} ${sg.label}</b><span>${fmtTime(sg.t)} · ${state}</span>` +
      (sg.status === 'open' ? '<button class="mini" id="pulseBtn">EV Pulse ▸</button>' : '') + '</div>' +
      sigLevels(sg, inst) +
      `<div class="sub">${sigWhy(sg, inst)}</div>` +
      (sg.wallWarn ? `<div class="warn">⚠ ${up ? 'Call' : 'Put'} wall at ${fmt(sg.wallWarn, 0)} before T1 — target may stall</div>` : '');
    const pb = $('pulseBtn');
    if (pb) pb.onclick = (e) => { e.stopPropagation(); tradeInPulse(sg, inst); };
    card.onclick = openSigSheet;
  }

  const levelName = (name, lvl) => {
    const n = { pdh: 'prev-day high', pdl: 'prev-day low', orbH: 'opening-range high', orbL: 'opening-range low' }[name] || name;
    return `${n} ${fmt(lvl, decFor(lvl))}`;
  };

  function maybeAlert() {
    alertWatchAndCancel();
    const res = S.sigResult;
    const inst = current();
    if (!res || !res.stats.open || !inst || !S.sig.alerts || !D.isMarketOpen()) return;
    const sg = res.stats.open;
    if (Math.floor(sg.t / 86400) !== Math.floor(D.istNow() / 86400)) return;
    const key = `${inst.title}|${sg.t}|${sg.dir}`;
    if (S.alerted.has(key)) return;
    S.alerted.add(key);
    store.set('alerted.' + D.ymd(D.istNow()), [...S.alerted]);
    const dec = decFor(sg.entry);
    const title = `${sg.dir > 0 ? '▲' : '▼'} ${sg.label} · ${inst.title}`;
    const text = `Entry ${fmt(sg.entry, dec)} · SL ${fmt(sg.sl, dec)} · T1 ${fmt(sg.t1, dec)} · T2 ${fmt(sg.t2, dec)}\n${sigWhy(sg, inst)}` +
      (sg.wallWarn ? `\n⚠ wall at ${sg.wallWarn} before T1` : '');
    EV.call('notify', { title, text }).catch(() => {});
    toast(title, 5000);
    if (sg.mode === 'early') S.liveEarly = { key, label: sg.label, level: sg.level, inst: inst.title, dir: sg.dir };
  }

  // ⚡ heads-up, and "cancel" when an early breakout fails (back through the level, or the live cross undid itself)
  function alertWatchAndCancel() {
    const res = S.sigResult;
    const inst = current();
    if (!res || !inst || !S.sig.alerts || !D.isMarketOpen()) return;
    const day = D.ymd(D.istNow());
    const w = res.watch;
    if (w && S.sig.watch) {
      const key = `watch|${inst.title}|${w.name}|${w.dir}`;
      if (!S.alerted.has(key)) {
        S.alerted.add(key);
        store.set('alerted.' + day, [...S.alerted]);
        const what = w.wall ? `${w.dir > 0 ? 'call' : 'put'} wall ${fmt(w.level, 0)}` : levelName(w.name, w.level);
        const title = `⚡ Watch ${w.dir > 0 ? '▲' : '▼'} ${inst.title}`;
        const text = `Price ${fmt(w.price, decFor(w.price))} near ${what} · ${w.dir > 0 ? 'buyers' : 'sellers'} ${Math.round((w.dir > 0 ? w.share : 1 - w.share) * 100)}% · get ready`;
        EV.call('notify', { title, text }).catch(() => {});
        toast(title, 4000);
      }
    }
    const le = S.liveEarly;
    if (le && le.inst === inst.title) {
      const now = res.signals.find((x) => `${inst.title}|${x.t}|${x.dir}` === le.key);
      if (!now || now.status === 'cancel') {
        const ck = 'cancel|' + le.key;
        if (!S.alerted.has(ck)) {
          S.alerted.add(ck);
          store.set('alerted.' + day, [...S.alerted]);
          const title = `✗ Cancel ${le.label} · ${inst.title}`;
          const text = `Price went back ${le.dir > 0 ? 'below' : 'above'} ${fmt(le.level, decFor(le.level))} — fake breakout, exit`;
          EV.call('notify', { title, text }).catch(() => {});
          toast(title, 5000);
        }
        S.liveEarly = null;
      } else if (now.status !== 'open') S.liveEarly = null;
    }
  }

  // EV Pulse takes over for the order (you confirm there).
  async function tradeInPulse(sg, inst) {
    const q = new URLSearchParams({
      side: inst.kind === 'option' ? inst.side : sg.dir > 0 ? 'CE' : 'PE',
      und: inst.kind === 'option' ? inst.und : inst.key || inst.title,
      strike: String(inst.kind === 'option' ? inst.strike : atmOf(inst, sg.entry)),
      expiry: inst.kind === 'option' ? inst.expiry : '',
      entry: String(inst.kind === 'option' ? sg.entry : ''),
      sl: String(inst.kind === 'option' ? sg.slNow : ''),
      t1: String(inst.kind === 'option' ? sg.t1 : ''),
      t2: String(inst.kind === 'option' ? sg.t2 : ''),
      index_entry: String(inst.kind === 'index' ? sg.entry : ''),
      index_sl: String(inst.kind === 'index' ? sg.slNow : ''),
      index_t1: String(inst.kind === 'index' ? sg.t1 : ''),
      index_t2: String(inst.kind === 'index' ? sg.t2 : ''),
      setup: sg.name, source: 'evcharts',
    });
    try { await EV.call('openExternal', { url: 'evpulse://trade?' + q.toString() }); }
    catch (e) { toast(e.message, 4500); }
  }

  /* ---------- signal log sheet ---------- */
  function openSigSheet() {
    const res = S.sigResult;
    const inst = current();
    const box = $('sigList');
    box.innerHTML = '';
    if (!res || !res.signals.length) box.innerHTML = '<p class="hint">No signals in the loaded candles yet.</p>';
    else {
      const st = res.stats;
      $('sigStats').textContent = `${st.count} signals · ${st.closed} closed · win ${st.winRate == null ? '—' : st.winRate + '%'} · total ${st.totalR >= 0 ? '+' : ''}${st.totalR.toFixed(1)}R · avg ${st.avgR == null ? '—' : (st.avgR >= 0 ? '+' : '') + st.avgR.toFixed(2) + 'R'}`;
      for (const sg of res.signals.slice().reverse()) {
        const d = new Date(sg.t * 1000);
        const el = document.createElement('div');
        el.className = 'sig-row ' + (sg.dir > 0 ? 'bull' : 'bear');
        el.innerHTML = `<div class="hd"><b>${sg.dir > 0 ? '▲' : '▼'} ${sg.label}</b><span>${String(d.getUTCDate()).padStart(2, '0')}/${String(d.getUTCMonth() + 1).padStart(2, '0')} ${fmtTime(sg.t)}</span></div>` +
          sigLevels(sg, inst) +
          `<div class="sub">${sigWhy(sg, inst)}</div>` +
          `<div class="res ${sg.r > 0 ? 'up' : sg.r < 0 ? 'down' : ''}">${STATUS_TEXT[sg.status]}${sg.status !== 'open' ? ` · ${sg.r >= 0 ? '+' : ''}${sg.r.toFixed(1)}R` : ''}</div>`;
        el.onclick = () => { closeSigSheet(); chart.rightOffset = chart.plotW / (2 * chart.spacing) - (S.bars.length - 1 - sg.i) - 0.5; chart._clampView(); chart.render(); };
        box.appendChild(el);
      }
    }
    // settings
    for (const k of ['on', 'alerts', 'early', 'watch', 'pdh', 'orb', 'vwap', 'ema', 'absorb']) $('sg_' + k).checked = !!S.sig[k];
    for (const k of ['rr1', 'rr2', 'maxSlPct', 'minFlow']) $('sg_' + k).value = S.sig[k];
    $('sigSheet').classList.add('show'); $('sheetBg').classList.add('show');
  }
  function closeSigSheet() { $('sigSheet').classList.remove('show'); $('sheetBg').classList.remove('show'); }
  $('sigChip').onclick = openSigSheet;
  $('sigSave').onclick = () => {
    for (const k of ['on', 'alerts', 'early', 'watch', 'pdh', 'orb', 'vwap', 'ema', 'absorb']) S.sig[k] = $('sg_' + k).checked;
    const num = (k, lo, hi) => { const v = parseFloat($('sg_' + k).value); if (isFinite(v)) S.sig[k] = Math.min(hi, Math.max(lo, v)); };
    num('rr1', 0.5, 10); num('rr2', 1, 20); num('maxSlPct', 5, 60); num('minFlow', 50, 80);
    store.set('sig', S.sig);
    closeSigSheet();
    applyIndicators();
    toast('Signal settings saved');
  };

  /* ---------- walls & magnets (live option-chain OI) ---------- */
  const expCache = new Map();
  const chainCache = new Map();

  async function setupChain(inst) {
    clearInterval(S.chainTimer); S.chainTimer = null;
    S.wm = null; renderWalls();
    if (!S.ind.walls || !inst || (inst.kind !== 'index' && inst.kind !== 'option')) return;
    const und = inst.kind === 'option' ? inst.und : inst.key;
    if (!undList) { try { undList = await EV.call('optionUnderlyings'); } catch (e) { return; } }
    if (!undList.includes(und)) return;
    try {
      let expiry = inst.kind === 'option' ? inst.expiry : null;
      if (!expiry) {
        if (!expCache.has(und)) expCache.set(und, await EV.call('optionExpiries', { underlying: und }));
        expiry = (expCache.get(und) || [])[0];
      }
      if (!expiry) return;
      const ck = und + '|' + expiry;
      if (!chainCache.has(ck)) chainCache.set(ck, await EV.call('optionChain', { underlying: und, expiry }));
      const ch = chainCache.get(ck);
      const spot = chainSpot(inst);
      const strikes = ch.strikes.slice();
      let atm = 0;
      if (spot) strikes.forEach((r, k) => { if (Math.abs(r.strike - spot) < Math.abs(strikes[atm].strike - spot)) atm = k; });
      else atm = Math.floor(strikes.length / 2);
      const sel = strikes.slice(Math.max(0, atm - 10), atm + 11);
      const rows = sel.map((r) => ({ strike: r.strike, ceKey: r.ce ? `${ch.exchange}_${r.ce.token}` : null, peKey: r.pe ? `${ch.exchange}_${r.pe.token}` : null }));
      const keys = rows.flatMap((r) => [r.ceKey, r.peKey]).filter(Boolean);
      S.chain = { und, expiry, lot: ch.lot || 1, rows, keys, inst, exchange: ch.exchange, series: ch.series, sel, totals: new Map() };
      EV.call('chainWatch', { keys }).catch(() => {});
      await loadChainHistory(S.chain);
      // during market hours, re-read every 2 minutes so the split stays current
      S.chainTimer = setInterval(() => { if (D.isMarketOpen()) loadChainHistory(S.chain); }, 120000);
    } catch (e) { /* walls are optional */ }
  }

  function chainSpot(inst) {
    if (inst.kind === 'option') return S.opt.spot || null;
    const last = S.bars[S.bars.length - 1];
    return last ? last.c : null;
  }

  // Writers / buyers for every strike, from each strike's own 1-minute OI candles (full day, even if the
  // app was opened late or the market is closed). 3 requests at a time to stay under HDFC Sky's rate limit.
  async function loadChainHistory(ch) {
    if (!ch || ch.busy || document.hidden) return;
    ch.busy = true;
    const now = D.istNow();
    const range = { start: D.ymd(now - 5 * 86400), end: D.ymd(now) };
    const jobs = [];
    for (const r of ch.sel) for (const side of ['ce', 'pe']) if (r[side]) jobs.push({ key: `${ch.exchange}_${r[side].token}`, symbol: r[side].symbol });
    let k = 0;
    const worker = async () => {
      while (k < jobs.length) {
        const j = jobs[k++];
        try {
          const res = await EV.call('candles', { chartSymbols: [j.symbol], exchange: ch.exchange, seriesType: ch.series, chartType: 'MINUTE', start: range.start, end: range.end });
          ch.totals.set(j.key, window.EVSignals.writerBuyerTotals(D.parseRows((res && res.rows) || [])));
        } catch (e) { /* keep the previous numbers for this strike */ }
      }
    };
    await Promise.all([worker(), worker(), worker()]);
    ch.busy = false;
    if (S.chain !== ch) return;
    const inst = current();
    if (!inst || ch.inst !== inst) return;
    const rows = ch.rows.map((x) => ({ strike: x.strike, ce: ch.totals.get(x.ceKey) || null, pe: ch.totals.get(x.peKey) || null }));
    S.wm = window.EVSignals.wallsAndMagnets(rows, chainSpot(inst));
    S.wm.lot = ch.lot;
    S.wm.live = S.wm.ladder.some((x) => x.ceW + x.ceB + x.peW + x.peB > 0);
    renderWalls();
    applyIndicators();
  }

  const WB_COL = { ceW: '#ff7043', ceB: '#ffcc80', peW: '#26a69a', peB: '#80cbc4' };

  function renderWalls() {
    const line = $('chainLine');
    const inst = current();
    if (!S.ind.walls || !inst || (inst.kind !== 'index' && inst.kind !== 'option')) { line.innerHTML = ''; chart.setZones([]); chart.setProfile(null); return; }
    const wm = S.wm;
    if (!wm || !wm.live) {
      line.innerHTML = '<span class="muted">🧱 Loading writers / buyers for ATM ±10 strikes…</span>';
      chart.setZones([]); chart.setProfile(null);
      return;
    }
    const lots = (q) => fmtVol(Math.round(q / (wm.lot || 1)));
    const parts = [];
    const zones = [];
    for (const w of wm.walls) {
      const col = w.side === 'ce' ? WB_COL.ceW : WB_COL.peW;
      const tag = w.weak ? ' ⚠ weakening' : w.building ? ' ▲ building' : '';
      if (w.rank === 0) parts.push(`<span style="color:${col}">🧱 Writers ${fmt(w.strike, 0)} ${w.side.toUpperCase()} ${w.role === 'resistance' ? 'resistance' : 'support'} · ${lots(w.writers)}${tag}</span>`);
      zones.push({ price: w.strike, color: col, kind: 'wall', weak: w.weak, strong: w.rank === 0,
        label: `🧱 W ${fmt(w.strike, 0)} ${w.side.toUpperCase()} ${lots(w.writers)}${w.weak ? ' ⚠' : w.building ? ' ▲' : ''}`, short: `🧱 W ${fmt(w.strike, 0)}` });
    }
    for (const m of wm.magnets) {
      const col = m.side === 'ce' ? WB_COL.ceB : WB_COL.peB;
      parts.push(`<span style="color:${col}">🧲 Buyers ${fmt(m.strike, 0)} ${m.side.toUpperCase()} pull ${m.pull === 'up' ? '↑' : '↓'} · ${lots(m.buyers)}</span>`);
      zones.push({ price: m.strike, color: col, kind: 'magnet', label: `🧲 B ${fmt(m.strike, 0)} ${m.side.toUpperCase()} ${lots(m.buyers)}`, short: `🧲 B ${fmt(m.strike, 0)}` });
    }
    parts.push('<span class="muted">tap for ladder ▸</span>');
    line.innerHTML = parts.join('<i class="dot"></i>');
    // index charts: bands + per-strike profile at the strike price. Option charts plot premium, so the ladder is in the sheet.
    chart.setZones(inst.kind === 'index' ? zones : []);
    chart.setProfile(inst.kind === 'index' ? { rows: wm.ladder, colors: WB_COL } : null);
  }

  // Ladder sheet: every strike, CE writers / CE buyers / PE writers / PE buyers side by side
  function openLadder() {
    const wm = S.wm;
    if (!wm || !wm.live) { toast('Writers / buyers are still loading'); return; }
    const lots = (q) => fmtVol(Math.round(q / (wm.lot || 1)));
    const max = Math.max(1, ...wm.ladder.map((r) => Math.max(r.ceW, r.ceB, r.peW, r.peB)));
    const spot = chainSpot(current());
    const bar = (v, col, right) => `<div class="lb ${right ? 'r' : ''}"><i style="width:${(v / max) * 100}%;background:${col}"></i><span>${v ? lots(v) : ''}</span></div>`;
    const wallSet = new Set(wm.walls.filter((w) => w.rank === 0).map((w) => w.side + w.strike));
    const magSet = new Set(wm.magnets.map((m) => m.side + m.strike));
    let html = '<div class="lad hd"><span>CE writers</span><span>CE buyers</span><b>Strike</b><span>PE buyers</span><span>PE writers</span></div>';
    for (const r of wm.ladder.slice().reverse()) {
      const atm = spot && Math.abs(r.strike - spot) === Math.min(...wm.ladder.map((x) => Math.abs(x.strike - spot)));
      const mark = (wallSet.has('ce' + r.strike) || wallSet.has('pe' + r.strike) ? '🧱' : '') + (magSet.has('ce' + r.strike) || magSet.has('pe' + r.strike) ? '🧲' : '');
      html += `<div class="lad ${atm ? 'atm' : ''}">${bar(r.ceW, WB_COL.ceW, true)}${bar(r.ceB, WB_COL.ceB, true)}<b>${fmt(r.strike, 0)}${mark ? ' ' + mark : ''}</b>${bar(r.peB, WB_COL.peB)}${bar(r.peW, WB_COL.peW)}</div>`;
    }
    $('ladderBody').innerHTML = html;
    $('ladderSub').textContent = `${S.chain ? S.chain.und + ' · ' + S.chain.expiry : ''} · net OI added today, in lots · writers and buyers counted separately`;
    $('ladderSheet').classList.add('show'); $('sheetBg').classList.add('show');
  }
  $('chainLine').onclick = openLadder;

  /* ---------- links from EV Pulse: evcharts://chart?... ---------- */
  async function openLink(p) {
    if (!p || !Object.keys(p).length) return;
    if (p.stock) {
      setMode('stock', false);
      const list = await EV.call('searchStocks', { q: p.stock }).catch(() => []);
      const it = list.find((x) => x.symbol === String(p.stock).toUpperCase()) || list[0];
      if (it) { S.mode = 'stock'; pickStock(it); setMode('stock'); }
      return;
    }
    if (p.index && !p.strike) {
      store.set('index.key', String(p.index).toUpperCase());
      S.inst.index = null;
      setMode('index');
      return;
    }
    if (p.und) {
      S.opt.und = String(p.und).toUpperCase(); store.set('opt.und', S.opt.und);
      if (p.side) setSide(String(p.side).toUpperCase() === 'PE' ? 'PE' : 'CE');
      S.pendingStrike = p.strike ? +p.strike : null;
      S.pendingExpiry = p.expiry || null;
      S.opt.chain = null; S.inst.option = null;
      setMode('option');
    }
  }
  EV.on('open', openLink);

  const STRIP_NAMES_OPT = { WA: 'Writers +', WE: 'Writers −', BA: 'Buyers +', BE: 'Buyers −' };
  const STRIP_NAMES_FUT = { WA: 'Short build', WE: 'Short cover', BA: 'Long build', BE: 'Long unwind' };
  const STRIP_LONG_OPT = { WA: 'Writers adding', WE: 'Writers exiting', BA: 'Buyers adding', BE: 'Buyers exiting' };
  const STRIP_LONG_FUT = { WA: 'Short buildup', WE: 'Short covering', BA: 'Long buildup', BE: 'Long unwinding' };

  /* ---------- lots box (buyers / sellers of one candle) ---------- */
  function fmtQty(q, inst) {
    if (!inst || inst.unit !== 'lots') return fmtVol(Math.round(q));
    return Math.round(q / (inst.lot || 1)).toLocaleString('en-IN');
  }

  function showLots(idx) {
    const el = $('lotsBox');
    const inst = current();
    if (!inst || !S.bars.length) { el.innerHTML = ''; return; }
    const i = idx >= 0 ? idx : S.bars.length - 1;
    const parts = [];
    const f = S.flowBars[i];
    if (S.ind.bs && f && f.b + f.s > 0) {
      const d = f.b - f.s;
      const unit = inst.unit === 'lots' ? ' lots' : '';
      parts.push(`<span class="up">B ${fmtQty(f.b, inst)}</span> · <span class="down">S ${fmtQty(f.s, inst)}</span> · ` +
        `<b class="${d >= 0 ? 'up' : 'down'}">Δ ${d >= 0 ? '+' : '−'}${fmtQty(Math.abs(d), inst)}${unit}</b>` +
        (f.est ? ' <span class="muted">(est.)</span>' : ' <span class="muted">(live)</span>'));
    } else if (S.ind.bs && inst.flowKey) {
      parts.push(`<span class="muted">B/S: ${S.flowMin.size ? 'no trades split in this candle' : 'collects live during market hours'}</span>`);
    }
    const k = S.strip && S.strip[i];
    if (k) {
      const names = inst.stripKind === 'futures' ? STRIP_LONG_FUT : STRIP_LONG_OPT;
      parts.push(`<span style="color:${window.EVChart.STRIP_COLORS[k.kind]}">${names[k.kind]} · OI ${k.dOi > 0 ? '+' : '−'}${fmtQty(Math.abs(k.dOi), inst)}${inst.unit === 'lots' ? ' lots' : ''}</span>`);
    }
    const w = S.wbBars && S.wbBars[i];
    if (w && S.ind.wb) {
      const q = (v) => fmtQty(v, inst);
      parts.push(`<span style="color:#ff9800">W+ ${q(w.wa)}</span> <span style="color:#29b6f6">W− ${q(w.we)}</span> ` +
        `<span style="color:#66bb6a">B+ ${q(w.ba)}</span> <span style="color:#90a4ae">B− ${q(w.be)}</span>`);
    }
    el.innerHTML = parts.join('<i class="dot"></i>');
    // order book pressure (live only)
    const bk = $('bookBar');
    if (S.book && S.book.buy + S.book.sell > 0 && S.ind.bs) {
      const pb = Math.round((S.book.buy / (S.book.buy + S.book.sell)) * 100);
      bk.classList.add('show');
      bk.querySelector('.bb').style.width = pb + '%';
      bk.querySelector('.bl').textContent = `Bids ${pb}%`;
      bk.querySelector('.sl').textContent = `${100 - pb}% Asks`;
    } else bk.classList.remove('show');
  }

  /* ---------- crosshair OHLC ---------- */
  function showOhlc(bar, i) {
    const el = $('ohlc');
    const b = bar || S.bars[S.bars.length - 1];
    if (!b) { el.innerHTML = ''; return; }
    const idx = bar ? i : S.bars.length - 1;
    const prev = S.bars[idx - 1];
    const dec = decFor(b.c);
    const chg = prev ? b.c - prev.c : b.c - b.o;
    const pct = prev ? (chg / prev.c) * 100 : (chg / b.o) * 100;
    const cls = chg >= 0 ? 'up' : 'down';
    let html = `O <b>${fmt(b.o, dec)}</b>H <b>${fmt(b.h, dec)}</b>L <b>${fmt(b.l, dec)}</b>C <b class="${cls}">${fmt(b.c, dec)}</b>` +
      `<span class="${cls}">${chg >= 0 ? '+' : ''}${fmt(chg, dec)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)</span>`;
    if (b.v > 0) html += ` &nbsp;V <b>${fmtVol(b.v)}</b>`;
    if (b.oi > 0) html += `OI <b>${fmtVol(b.oi)}</b>`;
    el.innerHTML = html;
    showLots(idx);
  }

  /* ---------- loading ---------- */
  function current() { return S.inst[S.mode]; }

  function clearChart(msg) {
    S.raw = []; S.bars = [];
    chart.emptyText = msg || 'No candles yet';
    chart.setData([], { intraday: true });
    $('qName').textContent = '—'; $('qSub').textContent = msg || ''; $('qLtp').textContent = '—'; $('qChg').textContent = '';
    $('ohlc').innerHTML = '';
  }

  function rangeFor(tf, short) {
    const now = D.istNow();
    const days = short ? (tf.daily ? 10 : 1) : tf.days;
    return { start: D.ymd(now - (days - 1) * 86400), end: D.ymd(now) };
  }

  async function fetchCandles(inst, tf, short) {
    const { start, end } = rangeFor(tf, short);
    const r = await EV.call('candles', {
      chartSymbols: inst.chartSymbols, exchange: inst.exchange, seriesType: inst.series,
      chartType: tf.chartType, start, end,
    });
    if (r && r.symbol && inst.chartSymbols[0] !== r.symbol) {
      // Remember which chart symbol worked so refreshes don't probe again.
      inst.chartSymbols = [r.symbol].concat(inst.chartSymbols.filter((s) => s !== r.symbol));
    }
    return D.parseRows((r && r.rows) || []);
  }

  function rebuild(keepView) {
    const tf = TF[S.tf];
    S.bars = D.resample(S.raw, tf);
    chart.opts.weekly = !!tf.weekly;
    chart.emptyText = 'No candles for this range';
    chart.setData(S.bars, { keepView, intraday: !!tf.minutes });
    applyIndicators();
    showOhlc(null);
  }

  async function loadChart() {
    const inst = current();
    if (!inst) return;
    if (!ready()) { updateBanner(); return; }
    const seq = ++S.reqSeq;
    const tf = TF[S.tf];
    $('qName').textContent = inst.title;
    $('qSub').textContent = inst.sub;
    $('qLtp').textContent = '—'; $('qChg').textContent = '';
    S.raw = []; S.bars = []; S.futRaw = []; S.book = null;
    if (S.flowKey !== inst.flowKey) { S.flowMin = new Map(); S.flowKey = inst.flowKey || null; }
    chart.setData([], { intraday: !!tf.minutes });
    overlay('Loading candles…', true);
    stopRefresh();
    try {
      const rows = await fetchCandles(inst, tf, false);
      if (seq !== S.reqSeq) return;
      S.raw = rows;
      rebuild(false);
      overlay(rows.length ? '' : 'No candles returned for this instrument and range.', false);
      startFlow(inst, seq);
      loadFutures(inst, seq, false);
      if (!S.chain || S.chain.inst !== inst) setupChain(inst); else renderWalls();
    } catch (e) {
      if (seq !== S.reqSeq) return;
      handleError(e);
      return;
    }
    updateQuote(inst, seq);
    startRefresh();
  }

  async function updateQuote(inst, seq) {
    let ltp = null, prev = null;
    try {
      const q = await EV.call('ltp', { items: [{ exchange: inst.ltpExchange, token: inst.token, symbol: inst.chartSymbols[0] }] });
      if (q && q[0] && q[0].ltp > 0) { ltp = q[0].ltp; prev = q[0].prev_close || null; }
    } catch (e) { /* fall back to the last candle */ }
    if (seq !== S.reqSeq) return;
    const last = S.bars[S.bars.length - 1];
    if (ltp == null && last) ltp = last.c;
    if (ltp == null) return;
    const dec = decFor(ltp);
    $('qLtp').textContent = fmt(ltp, dec);
    if (prev) {
      const chg = ltp - prev, pct = (chg / prev) * 100;
      $('qChg').textContent = `${chg >= 0 ? '+' : ''}${fmt(chg, dec)} (${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%)`;
      $('qChg').className = 'q-chg ' + (chg >= 0 ? 'up' : 'down');
      $('qLtp').className = 'q-ltp ' + (chg >= 0 ? 'up' : 'down');
    } else {
      $('qChg').textContent = ''; $('qLtp').className = 'q-ltp';
    }
  }

  function handleError(e) {
    const msg = e.message || String(e);
    if (/AUTH|401|403|token|session/i.test(msg)) {
      overlay('Session expired. Please login to HDFC Sky again.', false);
      refreshStatus();
    } else if (/429|rate/i.test(msg)) {
      overlay('HDFC Sky is rate-limiting requests. Try again in a few seconds.', false);
    } else {
      overlay(msg, false);
    }
  }

  /* ---------- buyers / sellers feed ---------- */
  async function startFlow(inst, seq) {
    S.priceKey = inst.priceKey || null;
    const keys = [...new Set([inst.flowKey, inst.priceKey].filter(Boolean))];
    if (!keys.length) return;
    try {
      const r = await EV.call('flowWatch', { keys });
      if (seq !== S.reqSeq || S.flowKey !== inst.flowKey) return;
      const rows = ((r && r.history) || {})[inst.flowKey] || [];
      for (const [t, b, sQty] of rows) S.flowMin.set(t, [b, sQty]);
      if (rows.length) rebuild(true);
    } catch (e) {
      if (/AUTH/.test(e.message || '')) handleError(e);
    }
  }

  let flowRedraw = 0;
  EV.on('flow', (p) => {
    if (!p) return;
    let changed = false;
    if (p.key === S.priceKey && p.ltp > 0) changed = livePrice(p.ltp) || changed;
    if (p.key === S.flowKey) {
      for (const [t, b, sQty] of p.rows || []) S.flowMin.set(t, [b, sQty]);
      S.book = { buy: p.bookBuy || 0, sell: p.bookSell || 0 };
      changed = true;
    }
    const now = Date.now();
    if (changed && now - flowRedraw > 900 && S.bars.length) { flowRedraw = now; rebuild(true); }
  });

  // Live ticks build the forming 1-minute candle between the 20-second refreshes,
  // so signals can fire inside a candle instead of after it.
  function livePrice(ltp) {
    const tf = TF[S.tf];
    if (!tf.minutes || !D.isMarketOpen() || !S.raw.length) return false;
    const now = D.istNow();
    const t = now - (now % 60);
    const last = S.raw[S.raw.length - 1];
    if (last.t === t) { last.c = ltp; last.h = Math.max(last.h, ltp); last.l = Math.min(last.l, ltp); }
    else if (t > last.t && Math.floor(t / 86400) === Math.floor(last.t / 86400)) {
      S.raw.push({ t, o: last.c, h: Math.max(last.c, ltp), l: Math.min(last.c, ltp), c: ltp, v: 0, oi: last.oi });
    } else return false;
    S.liveT = t;
    return true;
  }

  EV.on('feed', (p) => {
    S.feedStatus = p.status;
    updateConn();
    if (p.status === 'error') toast('Live feed: ' + (p.detail || 'error'), 4000);
  });

  function updateConn() {
    const st = S.status || {};
    const on = !!st.loggedIn;
    const map = { connected: 'Live feed', connecting: 'Connecting…', disconnected: 'Feed offline', error: 'Feed error' };
    $('connText').textContent = st.demo ? 'Demo data' : !on ? 'Offline' : (map[S.feedStatus] || 'HDFC Sky');
    $('conn').classList.toggle('on', on && (st.demo || S.feedStatus === 'connected' || !S.feedStatus));
  }

  async function loadFutures(inst, seq, short) {
    if (!inst.oiSource || (!S.ind.strip && !S.ind.bs)) return;
    try {
      const rows = await fetchCandles(inst.oiSource, TF[S.tf], short);
      if (seq !== S.reqSeq) return;
      S.futRaw = short ? D.mergeRaw(S.futRaw, rows) : rows;
      rebuild(true);
    } catch (e) { /* strip simply stays off */ }
  }

  /* ---------- live refresh ---------- */
  function stopRefresh() { clearInterval(S.refreshTimer); S.refreshTimer = null; $('refreshNote').textContent = ''; }

  function startRefresh() {
    stopRefresh();
    if (!D.isMarketOpen()) { $('refreshNote').textContent = 'Market closed'; return; }
    $('refreshNote').textContent = 'Live · 20s';
    S.refreshTimer = setInterval(tick, REFRESH_MS);
  }

  async function tick() {
    if (document.hidden || S.loading) return;
    if (!D.isMarketOpen()) { startRefresh(); return; }
    const inst = current();
    if (!inst) return;
    const seq = S.reqSeq;
    S.loading = true;
    try {
      const fresh = await fetchCandles(inst, TF[S.tf], true);
      if (seq !== S.reqSeq) return;
      S.raw = D.mergeRaw(S.raw, fresh);
      rebuild(true);
      updateQuote(inst, seq);
      loadFutures(inst, seq, true);
    } catch (e) {
      if (/AUTH|401|403|token|session/i.test(e.message || '')) { stopRefresh(); handleError(e); }
    } finally {
      S.loading = false;
    }
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden && S.refreshTimer) tick(); });

  /* ---------- boot ---------- */
  let booted = false;
  async function boot() {
    if (!ready()) { clearChart(''); return; }
    booted = true;
    overlay('');
    setMode(S.mode);
  }

  // Called by Android when the app returns to the foreground.
  EV.on('resume', async () => {
    const st = await refreshStatus();
    if (st.loggedIn && !booted) boot();
  });

  (async function init() {
    const st = await refreshStatus();
    EV.call('pendingLink').then((p) => { if (p && Object.keys(p).length) setTimeout(() => openLink(p), 1500); }).catch(() => {});
    setMode(S.mode, false);
    if (st.loggedIn && st.master && st.master.ready && st.master.date !== D.ymd(D.istNow())) {
      downloadMaster(); // daily refresh keeps new expiries and strikes available
    } else {
      boot();
    }
  })();
})();
