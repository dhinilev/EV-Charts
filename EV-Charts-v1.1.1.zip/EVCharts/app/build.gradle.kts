plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.evgroup.evcharts"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.evgroup.evcharts"
        minSdk = 26
        targetSdk = 34
        versionCode = 3
        versionName = "1.1.1"
    }

    signingConfigs {
        // Fixed key kept in the repo so every GitHub build installs over the previous one.
        create("ev") {
            storeFile = file("ev-charts.keystore")
            storePassword = "evcharts"
            keyAlias = "evcharts"
            keyPassword = "evcharts"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("ev")
        }
        debug {
            signingConfig = signingConfigs.getByName("ev")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
