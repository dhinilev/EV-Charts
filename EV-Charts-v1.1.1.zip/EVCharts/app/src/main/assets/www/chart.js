/*
 * EV Charts — candlestick chart engine (canvas, no external libraries).
 *
 * Times are "IST wall-clock seconds stored as UTC", so all date formatting
 * uses getUTC*() and never shifts with the phone's own time zone.
 *
 * Gestures: drag = pan, pinch / mouse wheel = zoom, long-press = crosshair,
 * tap = hide crosshair, double-tap = jump back to the latest candle.
 */
(function () {
  'use strict';

  const STRIP_COLORS = { WA: '#ff9800', WE: '#29b6f6', BA: '#66bb6a', BE: '#78909c' };
  const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  function niceStep(range, targetLines) {
    const raw = range / Math.max(1, targetLines);
    const pow = Math.pow(10, Math.floor(Math.log10(raw)));
    const f = raw / pow;
    const nice = f < 1.5 ? 1 : f < 2.5 ? 2 : f < 3.5 ? 2.5 : f < 7.5 ? 5 : 10;
    return nice * pow;
  }

  function decimalsFor(step) {
    if (step >= 1) return step % 1 === 0 ? 0 : 1;
    return Math.min(4, Math.ceil(-Math.log10(step)) + 1);
  }

  function fmtPrice(v, dec) {
    return v.toLocaleString('en-IN', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }

  function cssVar(name, fallback) {
    const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
    return v || fallback;
  }

  class EVChart {
    constructor(canvas, opts) {
      this.canvas = canvas;
      this.ctx = canvas.getContext('2d');
      this.opts = Object.assign({ onCrosshair: null, intraday: true }, opts || {});
      this.bars = [];
      this.overlays = [];
      this.levels = [];
      this.flow = null;      // per bar {b, s} buyer / seller quantity
      this.cvd = null;       // per bar cumulative delta
      this.strip = null;     // per bar {kind} writers / buyers from OI
      this.showSplit = true; // split candle bodies into buyers (green) and sellers (red)
      this.showVolume = true;
      this.spacing = 8;
      this.rightOffset = 4;
      this.crosshair = null; // {x, y}
      this.axisW = 64;
      this.timeH = 22;
      this.dpr = window.devicePixelRatio || 1;
      this._pending = false;
      this._pointers = new Map();
      this._readTheme();
      this._bindEvents();
      this.resize();
      if (window.ResizeObserver) {
        new ResizeObserver(() => this.resize()).observe(canvas.parentElement || canvas);
      } else {
        window.addEventListener('resize', () => this.resize());
      }
    }

    _readTheme() {
      this.c = {
        bg: cssVar('--bg', '#0b0f14'),
        grid: cssVar('--grid', 'rgba(255,255,255,0.06)'),
        text: cssVar('--muted', '#8b98a9'),
        up: cssVar('--up', '#26a69a'),
        down: cssVar('--down', '#ef5350'),
        cross: cssVar('--cross', 'rgba(230,236,245,0.55)'),
        tag: cssVar('--panel-2', '#1c2430'),
        sep: cssVar('--sep', 'rgba(245,179,1,0.10)'),
      };
    }

    /* ---------- public API ---------- */

    setData(bars, { keepView = false, intraday = true } = {}) {
      const prevLen = this.bars.length;
      this.bars = bars || [];
      this.opts.intraday = intraday;
      if (!keepView) {
        this.rightOffset = 4;
        this.spacing = intraday ? 7 : 9;
        this.crosshair = null;
      } else if (this.rightOffset < 0 && this.bars.length > prevLen) {
        // Stay on the same historical bars when new candles arrive while the
        // user is looking at the past.
        this.rightOffset -= this.bars.length - prevLen;
      }
      this._clampView();
      this.render();
    }

    setOverlays(list) { this.overlays = list || []; this.render(); }
    setLevels(list) { this.levels = list || []; this.render(); }
    setVolume(on) { this.showVolume = !!on; this.render(); }
    setFlow(flow, cvd, on) { this.flow = flow; this.cvd = cvd; this.showSplit = !!on; this.render(); }
    setStrip(strip) { this.strip = strip; this.render(); }
    goLatest() { this.rightOffset = 4; this._clampView(); this.render(); }

    resize() {
      const rect = this.canvas.getBoundingClientRect();
      this.dpr = window.devicePixelRatio || 1;
      this.W = Math.max(50, rect.width);
      this.H = Math.max(50, rect.height);
      this.canvas.width = Math.round(this.W * this.dpr);
      this.canvas.height = Math.round(this.H * this.dpr);
      this._clampView();
      this.render();
    }

    render() {
      if (this._pending) return;
      this._pending = true;
      requestAnimationFrame(() => { this._pending = false; this._draw(); });
    }

    /* ---------- geometry ---------- */

    get plotW() { return this.W - this.axisW; }
    get plotH() { return this.H - this.timeH; }

    xOf(i) {
      const last = this.bars.length - 1;
      return this.plotW - (last - i + this.rightOffset + 0.5) * this.spacing;
    }

    indexAt(x) {
      const last = this.bars.length - 1;
      return last + this.rightOffset + 0.5 - (this.plotW - x) / this.spacing;
    }

    _clampView() {
      const n = this.bars.length;
      const perScreen = this.plotW / this.spacing;
      const minRo = -Math.max(0, n - 5);
      const maxRo = Math.max(4, perScreen * 0.6);
      this.rightOffset = Math.min(maxRo, Math.max(minRo, this.rightOffset));
    }

    _visibleRange() {
      const n = this.bars.length;
      const from = Math.max(0, Math.floor(this.indexAt(0)));
      const to = Math.min(n - 1, Math.ceil(this.indexAt(this.plotW)));
      return [from, to];
    }

    /* ---------- drawing ---------- */

    _draw() {
      const ctx = this.ctx;
      const { W, H, dpr } = this;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = this.c.bg;
      ctx.fillRect(0, 0, W, H);
      ctx.font = '11px system-ui, -apple-system, Roboto, sans-serif';
      ctx.textBaseline = 'middle';

      const bars = this.bars;
      if (!bars.length) {
        ctx.fillStyle = this.c.text;
        ctx.textAlign = 'center';
        ctx.fillText(this.emptyText || 'No candles yet', W / 2, H / 2);
        return;
      }

      const [from, to] = this._visibleRange();
      if (to < from) return;

      // ---- price scale from visible candles + overlays + levels
      let lo = Infinity, hi = -Infinity, vmax = 0;
      for (let i = from; i <= to; i++) {
        const b = bars[i];
        if (b.l < lo) lo = b.l;
        if (b.h > hi) hi = b.h;
        if (b.v > vmax) vmax = b.v;
      }
      for (const ov of this.overlays) {
        for (let i = from; i <= to; i++) {
          const v = ov.values[i];
          if (v == null || !isFinite(v)) continue;
          if (v < lo) lo = v;
          if (v > hi) hi = v;
        }
      }
      if (!isFinite(lo) || !isFinite(hi)) return;
      if (hi === lo) { hi += 1; lo -= 1; }
      const pad = (hi - lo) * 0.08;

      // Buyer/seller pane (replaces the volume overlay once flow exists)
      let flowVisible = false;
      if (this.showSplit && this.flow) {
        for (let i = from; i <= to; i++) if (this.flow[i]) { flowVisible = true; break; }
      }
      let stripVisible = false;
      if (this.strip) {
        for (let i = from; i <= to; i++) if (this.strip[i]) { stripVisible = true; break; }
      }
      const paneH = flowVisible ? Math.round(this.plotH * 0.22) : 0;
      const stripH = stripVisible ? 8 : 0;
      const volZone = !flowVisible && this.showVolume && vmax > 0 ? this.plotH * 0.18 : 0;
      const top = 8, bottom = this.plotH - 6 - paneH - stripH - volZone * 0.55;
      this._priceBottom = bottom + 3;
      const pMax = hi + pad, pMin = lo - pad;
      const yOf = (p) => top + (pMax - p) / (pMax - pMin) * (bottom - top);
      this._yOf = yOf;
      this._pOf = (y) => pMax - (y - top) / (bottom - top) * (pMax - pMin);

      const step = niceStep(pMax - pMin, Math.max(3, Math.round(this.plotH / 70)));
      const dec = decimalsFor(step);
      this._dec = Math.max(dec, bars[bars.length - 1].c < 100 ? 2 : dec);

      // ---- grid + price labels
      ctx.strokeStyle = this.c.grid;
      ctx.lineWidth = 1;
      ctx.fillStyle = this.c.text;
      ctx.textAlign = 'left';
      for (let p = Math.ceil(pMin / step) * step; p <= pMax; p += step) {
        const y = Math.round(yOf(p)) + 0.5;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.plotW, y); ctx.stroke();
        ctx.fillText(fmtPrice(p, dec), this.plotW + 6, y);
      }

      // ---- day separators (intraday) + time labels
      this._drawTimeAxis(from, to);

      // ---- clip to plot
      ctx.save();
      ctx.beginPath(); ctx.rect(0, 0, this.plotW, this.plotH); ctx.clip();

      // volume
      if (volZone > 0) {
        const vBase = this.plotH;
        const bw = Math.max(1, this.spacing * 0.7);
        for (let i = from; i <= to; i++) {
          const b = bars[i];
          const h = (b.v / vmax) * volZone;
          ctx.fillStyle = (b.c >= b.o ? this.c.up : this.c.down) + '40';
          ctx.fillRect(this.xOf(i) - bw / 2, vBase - h, bw, h);
        }
      }

      // writers / buyers strip
      if (stripVisible) {
        const sy = this.plotH - paneH - stripH;
        const sw = Math.max(1, this.spacing - (this.spacing > 4 ? 1 : 0));
        for (let i = from; i <= to; i++) {
          const k = this.strip[i];
          if (!k) continue;
          ctx.fillStyle = STRIP_COLORS[k.kind] || 'transparent';
          ctx.fillRect(this.xOf(i) - sw / 2, sy + 1, sw, stripH - 3);
        }
      }

      // buyers vs sellers pane + cumulative delta
      if (flowVisible) {
        const pTop = this.plotH - paneH + 4, pBot = this.plotH - 3;
        const mid = (pTop + pBot) / 2, half = (pBot - pTop) / 2 - 1;
        ctx.strokeStyle = this.c.grid;
        ctx.beginPath(); ctx.moveTo(0, this.plotH - paneH + 0.5); ctx.lineTo(this.plotW, this.plotH - paneH + 0.5); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, Math.round(mid) + 0.5); ctx.lineTo(this.plotW, Math.round(mid) + 0.5); ctx.stroke();
        let fmax = 0, cmin = Infinity, cmax = -Infinity;
        for (let i = from; i <= to; i++) {
          const f = this.flow[i];
          if (f) fmax = Math.max(fmax, f.b, f.s);
          const c = this.cvd && this.cvd[i];
          if (c != null) { cmin = Math.min(cmin, c); cmax = Math.max(cmax, c); }
        }
        const fbw = Math.max(1, this.spacing * 0.7);
        if (fmax > 0) {
          for (let i = from; i <= to; i++) {
            const f = this.flow[i];
            if (!f) continue;
            const x = this.xOf(i) - fbw / 2;
            const hb = (f.b / fmax) * half, hs = (f.s / fmax) * half;
            const a = f.est ? '70' : 'd0';
            ctx.fillStyle = this.c.up + a; ctx.fillRect(x, mid - hb, fbw, hb);
            ctx.fillStyle = this.c.down + a; ctx.fillRect(x, mid, fbw, hs);
          }
        }
        if (this.cvd && isFinite(cmin) && cmax > cmin) {
          ctx.strokeStyle = cssVar('--cvd', '#e6ecf5'); ctx.lineWidth = 1.3;
          ctx.beginPath();
          let pen = false, lastDay = null;
          for (let i = from; i <= to; i++) {
            const c = this.cvd[i];
            const day = Math.floor(bars[i].t / 86400);
            if (c == null || (lastDay !== null && day !== lastDay)) { pen = false; lastDay = day; if (c == null) continue; }
            lastDay = day;
            const y = pBot - ((c - cmin) / (cmax - cmin)) * (pBot - pTop);
            if (pen) ctx.lineTo(this.xOf(i), y); else { ctx.moveTo(this.xOf(i), y); pen = true; }
          }
          ctx.stroke();
        }
        ctx.fillStyle = this.c.text; ctx.textAlign = 'left';
        ctx.fillText('Buyers ▲ / Sellers ▼ · CVD', 4, this.plotH - paneH + 11);
      }

      // key levels (previous day high/low/close etc.)
      for (const lv of this.levels) {
        if (lv.value < pMin || lv.value > pMax) continue;
        const y = Math.round(yOf(lv.value)) + 0.5;
        ctx.strokeStyle = lv.color; ctx.setLineDash([2, 4]); ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(this.plotW, y); ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = lv.color; ctx.textAlign = 'left';
        ctx.fillText(lv.label, 4, y - 7);
      }

      // candles
      const bw = Math.max(1, Math.min(this.spacing * 0.72, this.spacing - 1));
      for (let i = from; i <= to; i++) {
        const b = bars[i];
        const x = this.xOf(i);
        const col = b.c >= b.o ? this.c.up : this.c.down;
        ctx.strokeStyle = col; ctx.fillStyle = col; ctx.lineWidth = 1;
        const xr = Math.round(x) + 0.5;
        ctx.beginPath(); ctx.moveTo(xr, yOf(b.h)); ctx.lineTo(xr, yOf(b.l)); ctx.stroke();
        const yo = yOf(b.o), yc = yOf(b.c);
        const bt = Math.min(yo, yc), bh = Math.max(1, Math.abs(yc - yo));
        const f = this.showSplit && this.flow ? this.flow[i] : null;
        if (f && f.b + f.s > 0 && bw >= 3) {
          // Buyers fill the body from the bottom (green), sellers from the top (red).
          const tot = f.b + f.s;
          const h = Math.max(bh, 3), top0 = bh < 3 ? bt - (3 - bh) / 2 : bt;
          const hb = h * (f.b / tot);
          ctx.globalAlpha = f.est ? 0.72 : 1; // estimated split is drawn a little softer than live
          ctx.fillStyle = this.c.down; ctx.fillRect(x - bw / 2, top0, bw, h - hb);
          ctx.fillStyle = this.c.up; ctx.fillRect(x - bw / 2, top0 + h - hb, bw, hb);
          ctx.globalAlpha = 1;
          if (bw >= 5) {
            ctx.strokeStyle = col === this.c.up ? '#c8f7ef' : '#ffd0cf'; ctx.lineWidth = 1;
            ctx.strokeRect(Math.round(x - bw / 2) + 0.5, Math.round(top0) + 0.5, Math.round(bw) - 1, Math.max(1, Math.round(h) - 1));
          }
        } else if (bw >= 2) ctx.fillRect(x - bw / 2, bt, bw, bh);
        else { ctx.beginPath(); ctx.moveTo(xr, bt); ctx.lineTo(xr, bt + bh); ctx.stroke(); }
      }

      // overlays (EMA / VWAP)
      for (const ov of this.overlays) {
        ctx.strokeStyle = ov.color; ctx.lineWidth = ov.width || 1.4;
        ctx.beginPath();
        let pen = false, lastDay = null;
        for (let i = Math.max(0, from - 1); i <= Math.min(bars.length - 1, to + 1); i++) {
          const v = ov.values[i];
          if (v == null || !isFinite(v)) { pen = false; continue; }
          const day = Math.floor(bars[i].t / 86400);
          if (ov.breakDaily && lastDay !== null && day !== lastDay) pen = false;
          lastDay = day;
          const x = this.xOf(i), y = yOf(v);
          if (pen) ctx.lineTo(x, y); else { ctx.moveTo(x, y); pen = true; }
        }
        ctx.stroke();
      }
      ctx.restore();

      // ---- last price tag
      const lastBar = bars[bars.length - 1];
      const ly = Math.round(yOf(lastBar.c)) + 0.5;
      const lcol = lastBar.c >= lastBar.o ? this.c.up : this.c.down;
      if (ly > 0 && ly < this.plotH) {
        ctx.strokeStyle = lcol; ctx.setLineDash([3, 3]);
        ctx.beginPath(); ctx.moveTo(0, ly); ctx.lineTo(this.plotW, ly); ctx.stroke();
        ctx.setLineDash([]);
        this._tag(this.plotW, ly, fmtPrice(lastBar.c, this._dec), lcol, '#fff');
      }

      // ---- crosshair
      if (this.crosshair) this._drawCrosshair(yOf);
    }

    _tag(x, y, text, bg, fg) {
      const ctx = this.ctx;
      const h = 18;
      ctx.fillStyle = bg;
      ctx.fillRect(x, y - h / 2, this.axisW, h);
      ctx.fillStyle = fg;
      ctx.textAlign = 'left';
      ctx.fillText(text, x + 6, y);
    }

    _fmtTime(t, withDate) {
      const d = new Date(t * 1000);
      const dd = String(d.getUTCDate()).padStart(2, '0');
      const mon = MONTHS[d.getUTCMonth()];
      if (!this.opts.intraday) {
        if (this.opts.weekly) return `${dd} ${mon} '${String(d.getUTCFullYear()).slice(2)}`;
        return withDate ? `${dd} ${mon} '${String(d.getUTCFullYear()).slice(2)}` : `${dd} ${mon}`;
      }
      const hm = `${String(d.getUTCHours()).padStart(2, '0')}:${String(d.getUTCMinutes()).padStart(2, '0')}`;
      return withDate ? `${dd} ${mon} ${hm}` : hm;
    }

    _drawTimeAxis(from, to) {
      const ctx = this.ctx;
      const bars = this.bars;
      const every = Math.max(1, Math.ceil(78 / this.spacing));
      ctx.textAlign = 'center';
      ctx.fillStyle = this.c.text;
      const yText = this.plotH + this.timeH / 2;
      const taken = []; // x positions already labelled
      const free = (x, gap) => taken.every((t) => Math.abs(t - x) >= gap);

      // Pass 1 (intraday): day separators win over ordinary time labels.
      if (this.opts.intraday) {
        for (let i = Math.max(from, 1); i <= to; i++) {
          const b = bars[i];
          if (Math.floor(bars[i - 1].t / 86400) === Math.floor(b.t / 86400)) continue;
          const x = this.xOf(i);
          ctx.strokeStyle = this.c.sep;
          ctx.beginPath(); ctx.moveTo(Math.round(x) + 0.5, 0); ctx.lineTo(Math.round(x) + 0.5, this.plotH); ctx.stroke();
          if (x < 24 || x > this.plotW - 24 || !free(x, 58)) continue;
          const d = new Date(b.t * 1000);
          ctx.fillStyle = cssVar('--accent', '#f5b301');
          ctx.fillText(`${String(d.getUTCDate()).padStart(2, '0')} ${MONTHS[d.getUTCMonth()]}`, x, yText);
          taken.push(x);
        }
      }

      // Pass 2: regular time / date labels in the gaps.
      ctx.fillStyle = this.c.text;
      for (let i = from; i <= to; i++) {
        if (i % every !== 0) continue;
        const x = this.xOf(i);
        if (x < 20 || x > this.plotW - 20 || !free(x, 64)) continue;
        ctx.strokeStyle = this.c.grid;
        ctx.beginPath(); ctx.moveTo(Math.round(x) + 0.5, 0); ctx.lineTo(Math.round(x) + 0.5, this.plotH); ctx.stroke();
        ctx.fillText(this._fmtTime(bars[i].t, false), x, yText);
        taken.push(x);
      }
    }

    _drawCrosshair(yOf) {
      const ctx = this.ctx;
      const n = this.bars.length;
      const i = Math.max(0, Math.min(n - 1, Math.round(this.indexAt(this.crosshair.x) - 0.5 + 0.5)));
      const x = Math.round(this.xOf(i)) + 0.5;
      const y = Math.max(0, Math.min(this.plotH, this.crosshair.y));
      ctx.strokeStyle = this.c.cross; ctx.lineWidth = 1; ctx.setLineDash([4, 4]);
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, this.plotH); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(0, Math.round(y) + 0.5); ctx.lineTo(this.plotW, Math.round(y) + 0.5); ctx.stroke();
      ctx.setLineDash([]);
      if (y <= this._priceBottom) this._tag(this.plotW, y, fmtPrice(this._pOf(y), this._dec), this.c.tag, '#e6ecf5');
      const label = this._fmtTime(this.bars[i].t, true);
      ctx.font = '11px system-ui, -apple-system, Roboto, sans-serif';
      const tw = ctx.measureText(label).width + 12;
      const tx = Math.max(0, Math.min(this.plotW - tw, x - tw / 2));
      ctx.fillStyle = this.c.tag;
      ctx.fillRect(tx, this.plotH, tw, this.timeH);
      ctx.fillStyle = '#e6ecf5'; ctx.textAlign = 'center';
      ctx.fillText(label, tx + tw / 2, this.plotH + this.timeH / 2);
      if (this._lastCrossIdx !== i && this.opts.onCrosshair) {
        this._lastCrossIdx = i;
        this.opts.onCrosshair(this.bars[i], i);
      }
    }

    _setCrosshair(x, y) {
      this.crosshair = x == null ? null : { x, y };
      if (!this.crosshair) {
        this._lastCrossIdx = null;
        if (this.opts.onCrosshair) this.opts.onCrosshair(null, -1);
      }
      this.render();
    }

    /* ---------- gestures ---------- */

    _bindEvents() {
      const cv = this.canvas;
      cv.style.touchAction = 'none';
      let start = null, lastTap = 0, pressTimer = null, crossMode = false, pinch = null;

      const local = (e) => {
        const r = cv.getBoundingClientRect();
        return { x: e.clientX - r.left, y: e.clientY - r.top };
      };

      cv.addEventListener('pointerdown', (e) => {
        cv.setPointerCapture(e.pointerId);
        const p = local(e);
        this._pointers.set(e.pointerId, p);
        if (this._pointers.size === 2) {
          clearTimeout(pressTimer);
          const [a, b] = [...this._pointers.values()];
          pinch = { d: Math.hypot(a.x - b.x, a.y - b.y), spacing: this.spacing, cx: (a.x + b.x) / 2 };
          pinch.idx = this.indexAt(pinch.cx);
          start = null;
          return;
        }
        start = { x: p.x, y: p.y, time: Date.now(), ro: this.rightOffset, moved: false };
        crossMode = false;
        pressTimer = setTimeout(() => {
          if (start && !start.moved) { crossMode = true; this._setCrosshair(p.x, p.y); }
        }, 320);
      });

      cv.addEventListener('pointermove', (e) => {
        if (!this._pointers.has(e.pointerId)) return;
        const p = local(e);
        this._pointers.set(e.pointerId, p);
        if (pinch && this._pointers.size === 2) {
          const [a, b] = [...this._pointers.values()];
          const d = Math.hypot(a.x - b.x, a.y - b.y);
          this._zoomAround(pinch.cx, pinch.idx, pinch.spacing * d / Math.max(1, pinch.d));
          return;
        }
        if (!start) return;
        const dx = p.x - start.x, dy = p.y - start.y;
        if (!start.moved && Math.hypot(dx, dy) > 6) { start.moved = true; if (!crossMode) clearTimeout(pressTimer); }
        if (crossMode) { this._setCrosshair(p.x, p.y); return; }
        if (start.moved) {
          this.rightOffset = start.ro - dx / this.spacing;
          this._clampView();
          if (this.crosshair) this._setCrosshair(null);
          this.render();
        }
      });

      const end = (e) => {
        this._pointers.delete(e.pointerId);
        clearTimeout(pressTimer);
        if (this._pointers.size < 2) pinch = null;
        if (!start) return;
        const quick = Date.now() - start.time < 280;
        if (!start.moved && quick && !crossMode) {
          const now = Date.now();
          if (now - lastTap < 320) { this.goLatest(); this._setCrosshair(null); }
          else if (this.crosshair) this._setCrosshair(null);
          else this._setCrosshair(start.x, start.y);
          lastTap = now;
        }
        start = null;
      };
      cv.addEventListener('pointerup', end);
      cv.addEventListener('pointercancel', end);

      cv.addEventListener('wheel', (e) => {
        e.preventDefault();
        const p = local(e);
        this._zoomAround(p.x, this.indexAt(p.x), this.spacing * (e.deltaY < 0 ? 1.12 : 1 / 1.12));
      }, { passive: false });
    }

    _zoomAround(cx, idx, spacing) {
      this.spacing = Math.max(2, Math.min(42, spacing));
      const last = this.bars.length - 1;
      this.rightOffset = (this.plotW - cx) / this.spacing - (last - idx) - 0.5;
      this._clampView();
      this.render();
    }
  }

  window.EVChart = EVChart;
  window.EVChart.STRIP_COLORS = STRIP_COLORS;
})();
