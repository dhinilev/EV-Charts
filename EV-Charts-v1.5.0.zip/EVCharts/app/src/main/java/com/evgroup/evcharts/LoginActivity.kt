package com.evgroup.evcharts

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient

/**
 * Shows HDFC Sky's own login + OTP page. When HDFC redirects to the app's
 * registered redirect URL, the request token is picked off that URL and handed
 * back to MainActivity. The redirect URL itself is never actually loaded.
 */
class LoginActivity : Activity() {

    private var done = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val loginUrl = intent.getStringExtra(EXTRA_LOGIN_URL) ?: return finish()
        val redirect = intent.getStringExtra(EXTRA_REDIRECT) ?: return finish()

        val web = WebView(this)
        setContentView(web)
        title = "HDFC Sky login"
        CookieManager.getInstance().setAcceptCookie(true)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                catchRedirect(request.url.toString(), redirect)

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean =
                catchRedirect(url, redirect)

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (catchRedirect(url, redirect)) view.stopLoading()
                else super.onPageStarted(view, url, favicon)
            }
        }
        web.loadUrl(loginUrl)
    }

    private fun catchRedirect(url: String, redirect: String): Boolean {
        if (done || !sameTarget(url, redirect)) return false
        val uri = Uri.parse(url)
        val token = listOf("request_token", "requestToken", "request-token", "code")
            .firstNotNullOfOrNull { uri.getQueryParameter(it)?.takeIf { v -> v.isNotBlank() } }
        done = true
        val data = Intent()
        if (token != null) data.putExtra(EXTRA_TOKEN, token)
        else data.putExtra(EXTRA_ERROR, uri.getQueryParameter("error_description") ?: uri.getQueryParameter("error")
            ?: "HDFC Sky did not send a request token")
        setResult(RESULT_OK, data)
        finish()
        return true
    }

    /** Same scheme + host + path, ignoring the query string and a trailing slash. */
    private fun sameTarget(url: String, redirect: String): Boolean {
        val a = Uri.parse(url); val b = Uri.parse(redirect)
        return a.scheme.equals(b.scheme, true) && a.host.equals(b.host, true) &&
            (a.path ?: "").trimEnd('/') == (b.path ?: "").trimEnd('/')
    }

    companion object {
        const val EXTRA_LOGIN_URL = "login_url"
        const val EXTRA_REDIRECT = "redirect"
        const val EXTRA_TOKEN = "request_token"
        const val EXTRA_ERROR = "error"
    }
}
