/*
 * EV Charts — pattern markers, BUY CE / BUY PE signals, and walls / magnets.
 * Pure functions (no DOM), so they can be tested outside the app.
 *
 * Times are IST wall-clock seconds stored as UTC (see data.js).
 */
(function () {
  'use strict';

  const DAY = 86400;
  const tod = (t) => t % DAY; // seconds since IST midnight
  const T0930 = 9 * 3600 + 30 * 60;
  const T1500 = 15 * 3600;

  const DEFAULTS = {
    on: true,          // signals on / off
    alerts: true,      // phone notification for a new signal
    pdh: true, orb: true, vwap: true, ema: true, absorb: true,
    rr1: 2,            // T1 at 2R
    rr2: 4,            // T2 at 4R
    maxSlPct: 25,      // option premium: stop never more than 25% away
    minFlow: 55,       // buyers must be at least 55% of the candle's volume (sellers for PE)
    maxPerDay: 4,      // at most 4 signals a day
  };
  // Breakout levels fire only on their FIRST break of the day; VWAP / EMA at most twice.
  const PER_DAY_LIMIT = { pdh: 1, pdl: 1, orbH: 1, orbL: 1, vwapUp: 2, vwapDn: 2, emaUp: 2, emaDn: 2, absorbUp: 2, absorbDn: 2 };

  const SETUP_NAMES = {
    pdh: 'Prev-day high breakout', pdl: 'Prev-day low breakdown',
    orbH: 'Opening-range breakout', orbL: 'Opening-range breakdown',
    vwapUp: 'VWAP reclaim', vwapDn: 'VWAP loss',
    emaUp: 'EMA 9/21 cross up', emaDn: 'EMA 9/21 cross down',
    absorbUp: 'Absorption reversal (sellers absorbed)', absorbDn: 'Absorption reversal (buyers absorbed)',
  };

  /* ---------- helpers ---------- */

  function atrSeries(bars, period) {
    const out = new Array(bars.length).fill(null);
    let prev = null;
    for (let i = 0; i < bars.length; i++) {
      const b = bars[i];
      const pc = i > 0 ? bars[i - 1].c : b.c;
      const tr = Math.max(b.h - b.l, Math.abs(b.h - pc), Math.abs(b.l - pc));
      prev = prev == null ? tr : (prev * (period - 1) + tr) / period;
      out[i] = prev;
    }
    return out;
  }

  // Opening range (09:15–09:30) per day from 1-minute candles: day -> {h, l}
  function openingRanges(raw) {
    const map = new Map();
    for (const b of raw) {
      const s = tod(b.t);
      if (s < 9 * 3600 + 15 * 60 || s >= T0930) continue;
      const d = Math.floor(b.t / DAY);
      const r = map.get(d);
      if (!r) map.set(d, { h: b.h, l: b.l });
      else { r.h = Math.max(r.h, b.h); r.l = Math.min(r.l, b.l); }
    }
    return map;
  }

  // Previous trading day high / low / close for every day present in raw candles
  function prevDayMap(raw) {
    const days = [];
    let cur = null;
    for (const b of raw) {
      const d = Math.floor(b.t / DAY);
      if (!cur || cur.d !== d) { cur = { d, h: b.h, l: b.l, c: b.c }; days.push(cur); }
      else { cur.h = Math.max(cur.h, b.h); cur.l = Math.min(cur.l, b.l); cur.c = b.c; }
    }
    const map = new Map();
    for (let k = 1; k < days.length; k++) map.set(days[k].d, days[k - 1]);
    return map;
  }

  /* ---------- pattern markers ---------- */

  /*
   * absorb  : heavy one-sided LIVE flow but price went the other way (big player absorbing)
   * reject  : long wick on a wide candle (price rejected from a level)
   * div     : new 20-bar high/low in price that cumulative delta does not confirm
   */
  function patterns(bars, flow, cvd) {
    const out = [];
    if (bars.length < 5) return out;
    const avgRange = (i) => {
      let s = 0, n = 0;
      for (let k = Math.max(0, i - 20); k < i; k++) { s += bars[k].h - bars[k].l; n++; }
      return n ? s / n : 0;
    };
    const lastDiv = { 1: -99, '-1': -99 };
    for (let i = 1; i < bars.length; i++) {
      const b = bars[i];
      const range = b.h - b.l;
      const ar = avgRange(i);
      const f = flow && flow[i];

      if (f && !f.est && f.b + f.s > 0) {
        const d = (f.b - f.s) / (f.b + f.s);
        if (d >= 0.3 && b.c <= b.o) out.push({ i, type: 'absorb', dir: -1, text: 'Buyers absorbed' });
        else if (d <= -0.3 && b.c >= b.o) out.push({ i, type: 'absorb', dir: 1, text: 'Sellers absorbed' });
      }

      if (ar > 0 && range >= 1.3 * ar) {
        const lowerWick = Math.min(b.o, b.c) - b.l;
        const upperWick = b.h - Math.max(b.o, b.c);
        if (lowerWick >= 0.55 * range) out.push({ i, type: 'reject', dir: 1, text: 'Rejected lower prices' });
        else if (upperWick >= 0.55 * range) out.push({ i, type: 'reject', dir: -1, text: 'Rejected higher prices' });
      }

      if (cvd && cvd[i] != null && i >= 20) {
        let hiP = -Infinity, loP = Infinity, hiC = -Infinity, loC = Infinity, ok = true;
        const day = Math.floor(b.t / DAY);
        for (let k = i - 20; k < i; k++) {
          if (cvd[k] == null || Math.floor(bars[k].t / DAY) !== day) { ok = false; break; }
          hiP = Math.max(hiP, bars[k].h); loP = Math.min(loP, bars[k].l);
          hiC = Math.max(hiC, cvd[k]); loC = Math.min(loC, cvd[k]);
        }
        if (ok) {
          if (b.h > hiP && cvd[i] < hiC && i - lastDiv['-1'] > 5) { out.push({ i, type: 'div', dir: -1, text: 'New high without buyers (CVD)' }); lastDiv['-1'] = i; }
          if (b.l < loP && cvd[i] > loC && i - lastDiv[1] > 5) { out.push({ i, type: 'div', dir: 1, text: 'New low without sellers (CVD)' }); lastDiv[1] = i; }
        }
      }
    }
    return out;
  }

  /* ---------- signals ---------- */

  /*
   * ctx = {
   *   bars, raw (1-minute), flow, strip, ema9, ema21, vwap,
   *   kind: 'index' | 'option' | 'stock',  closed: number of closed bars,
   *   stripKind: 'option' | 'futures' | null, settings, tick
   * }
   * Returns { signals: [...], stats }
   */
  function signals(ctx) {
    const st = Object.assign({}, DEFAULTS, ctx.settings || {});
    const bars = ctx.bars;
    const n = Math.min(ctx.closed == null ? bars.length : ctx.closed, bars.length);
    const out = [];
    if (!st.on || n < 25) return { signals: out, stats: stats(out) };

    const atr = atrSeries(bars, 14);
    const pdm = prevDayMap(ctx.raw || bars);
    const orm = openingRanges(ctx.raw || []);
    const marks = patterns(bars, ctx.flow, null).filter((m) => m.type === 'absorb');
    const absorbAt = new Map(marks.map((m) => [m.i, m.dir]));
    const dirs = ctx.kind === 'index' ? [1, -1] : [1];
    const tick = ctx.tick || 0.05;
    let open = null, cool = -1;
    const used = new Map(); // "day|setup" -> times fired (or level already broken)
    const perDay = new Map();
    const bump = (key) => used.set(key, (used.get(key) || 0) + 1);

    for (let i = 1; i < n; i++) {
      const b = bars[i], p = bars[i - 1];

      // ---- manage an open trade on this bar
      if (open) {
        step(open, b, i, bars);
        if (open.status !== 'open') { cool = i + 2; open = null; }
        continue;
      }
      if (i <= cool) continue;
      const s = tod(b.t);
      if (s < T0930 || s > T1500 - 300) continue; // 09:30 – 14:55 only
      if (Math.floor(p.t / DAY) !== Math.floor(b.t / DAY)) continue; // no first bar of a day

      const day = Math.floor(b.t / DAY);
      const pd = pdm.get(day);
      const orb = orm.get(day);

      if ((perDay.get(day) || 0) >= st.maxPerDay) continue;

      for (const dir of dirs) {
        const crossed = (lvl) => lvl != null && (dir > 0 ? p.c <= lvl && b.c > lvl : p.c >= lvl && b.c < lvl);
        const fresh = (name) => (used.get(day + '|' + name) || 0) < PER_DAY_LIMIT[name];
        // A breakout level counts as "used" the first time price crosses it, signal or not.
        const brk = (name, lvl) => {
          if (!crossed(lvl)) return false;
          const ok = fresh(name);
          bump(day + '|' + name);
          return ok;
        };
        let setup = null;
        if (st.pdh && pd && brk(dir > 0 ? 'pdh' : 'pdl', dir > 0 ? pd.h : pd.l)) setup = dir > 0 ? 'pdh' : 'pdl';
        else if (st.orb && orb && brk(dir > 0 ? 'orbH' : 'orbL', dir > 0 ? orb.h : orb.l)) setup = dir > 0 ? 'orbH' : 'orbL';
        else if (st.vwap && ctx.vwap && ctx.vwap[i] != null && i >= 4 &&
          dir * (b.c - ctx.vwap[i]) > 0 &&
          [1, 2, 3].every((k) => ctx.vwap[i - k] != null && dir * (bars[i - k].c - ctx.vwap[i - k]) < 0)) setup = dir > 0 ? 'vwapUp' : 'vwapDn';
        else if (st.ema && ctx.ema9 && ctx.ema9[i] != null && ctx.ema21[i] != null && ctx.ema9[i - 1] != null && ctx.ema21[i - 1] != null &&
          dir * (ctx.ema9[i] - ctx.ema21[i]) > 0 && dir * (ctx.ema9[i - 1] - ctx.ema21[i - 1]) <= 0) setup = dir > 0 ? 'emaUp' : 'emaDn';
        else if (st.absorb && absorbAt.get(i - 1) === dir && dir * (b.c - (dir > 0 ? p.h : p.l)) > 0) setup = dir > 0 ? 'absorbUp' : 'absorbDn';
        if (!setup) continue;
        if (!/^(pdh|pdl|orb)/.test(setup)) { if (!fresh(setup)) continue; bump(day + '|' + setup); }

        // ---- confirmations
        const range = b.h - b.l;
        if (!(dir * (b.c - b.o) > 0 && Math.abs(b.c - b.o) >= 0.4 * range)) continue; // strong candle in the trade's direction
        const f = ctx.flow && ctx.flow[i];
        let share = null;
        if (f && f.b + f.s > 0) {
          share = f.b / (f.b + f.s);
          const need = st.minFlow / 100;
          if (dir > 0 ? share < need : share > 1 - need) continue; // buyers / sellers must agree
        }
        const k = ctx.strip && ctx.strip[i] ? ctx.strip[i].kind : null;
        if (k) {
          // option chart (buying this option): writers adding against us = no trade
          if (ctx.stripKind === 'option' && k === 'WA') continue;
          if (ctx.stripKind === 'futures') {
            if (dir > 0 && (k === 'WA' || k === 'BE')) continue; // short buildup / long unwinding
            if (dir < 0 && (k === 'BA' || k === 'WE')) continue; // long buildup / short covering
          }
        }

        // ---- levels
        const a = atr[i] || range;
        const swing = dir > 0 ? Math.min(b.l, p.l, bars[i - 2] ? bars[i - 2].l : b.l) : Math.max(b.h, p.h, bars[i - 2] ? bars[i - 2].h : b.h);
        let risk = dir * (b.c - swing) + tick;
        risk = Math.max(risk, 0.3 * a);
        risk = Math.min(risk, 1.5 * a);
        if (ctx.kind === 'option') risk = Math.min(risk, b.c * st.maxSlPct / 100);
        if (!(risk > 0)) continue;
        const entry = b.c;
        const sig = {
          i, t: b.t, dir, setup, name: SETUP_NAMES[setup],
          entry, risk,
          sl: round(entry - dir * risk, tick), t1: round(entry + dir * st.rr1 * risk, tick), t2: round(entry + dir * st.rr2 * risk, tick),
          slNow: null, share, strip: k, status: 'open', t1Hit: false, exitI: null, exitPx: null, r: 0,
          rr1: st.rr1, rr2: st.rr2,
        };
        sig.slNow = sig.sl;
        out.push(sig);
        perDay.set(day, (perDay.get(day) || 0) + 1);
        open = sig;
        break;
      }
    }
    // a trade still open at the end of a past day (or after today's close) is closed at the last candle
    if (open && n > 0) {
      const last = bars[n - 1];
      if (ctx.sessionOver || Math.floor(last.t / DAY) !== Math.floor(open.t / DAY)) closeAt(open, n - 1, bars, 'eod');
    }
    return { signals: out, stats: stats(out) };
  }

  function round(v, tick) { return Math.round(v / tick) * tick; }

  // Walk one bar forward for an open trade. Stop is checked before targets (conservative).
  function step(sig, b, i, bars) {
    const prev = bars[i - 1];
    if (Math.floor(prev.t / DAY) !== Math.floor(b.t / DAY)) { closeAt(sig, i - 1, bars, 'eod'); return; }
    const d = sig.dir;
    const worst = d > 0 ? b.l : b.h;
    const best = d > 0 ? b.h : b.l;
    if (d * (worst - sig.slNow) <= 0) {
      sig.status = sig.t1Hit ? 'be' : 'sl';
      sig.exitI = i; sig.exitPx = sig.slNow;
      sig.r = sig.t1Hit ? sig.rr1 / 2 : -1; // half booked at T1, rest out at entry
      return;
    }
    if (!sig.t1Hit && d * (best - sig.t1) >= 0) { sig.t1Hit = true; sig.slNow = sig.entry; sig.t1I = i; }
    if (sig.t1Hit && d * (best - sig.t2) >= 0) {
      sig.status = 't2'; sig.exitI = i; sig.exitPx = sig.t2;
      sig.r = (sig.rr1 + sig.rr2) / 2;
    }
  }

  function closeAt(sig, i, bars, why) {
    const px = bars[i].c;
    const r = sig.dir * (px - sig.entry) / sig.risk;
    sig.status = why; sig.exitI = i; sig.exitPx = px;
    sig.r = sig.t1Hit ? (sig.rr1 + r) / 2 : r;
  }

  function stats(list) {
    const done = list.filter((s) => s.status !== 'open');
    const wins = done.filter((s) => s.r > 0).length;
    const total = done.reduce((a, s) => a + s.r, 0);
    return {
      count: list.length, closed: done.length, wins,
      winRate: done.length ? Math.round((wins / done.length) * 100) : null,
      avgR: done.length ? total / done.length : null, totalR: total,
      open: list.find((s) => s.status === 'open') || null,
    };
  }

  /* ---------- walls & magnets ---------- */

  /*
   * chain: [{strike, ce:{oi, tot:[wa,we,ba,be], recent:[...]}, pe:{...}}]
   * Wall   = biggest OI strike on each side of spot (calls above = resistance, puts below = support).
   *          Weakening when writers exited more than they added in the last 15 minutes.
   * Magnet = strike where buyers added the most OI today (calls above spot pull up, puts below pull down).
   */
  function wallsAndMagnets(chain, spot) {
    const res = { walls: [], magnets: [] };
    if (!chain || !chain.length || !spot) return res;
    const pick = (side, test) => chain.filter((r) => r[side] && r[side].oi > 0 && test(r.strike))
      .sort((a, b) => b[side].oi - a[side].oi);
    const ceUp = pick('ce', (k) => k >= spot);
    const peDn = pick('pe', (k) => k <= spot);
    const mkWall = (row, side, role, rank) => {
      const x = row[side];
      const tot = x.tot || [0, 0, 0, 0], rec = x.recent || [0, 0, 0, 0];
      const netToday = tot[0] - tot[1];
      const weak = rec[1] > rec[0] && rec[1] > x.oi * 0.02;
      const building = rec[0] > rec[1] && rec[0] > x.oi * 0.01;
      return { strike: row.strike, side, role, rank, oi: x.oi, netToday, weak, building };
    };
    ceUp.slice(0, 2).forEach((r, k) => res.walls.push(mkWall(r, 'ce', 'resistance', k)));
    peDn.slice(0, 2).forEach((r, k) => res.walls.push(mkWall(r, 'pe', 'support', k)));

    const mag = (side, test) => chain.filter((r) => r[side] && r[side].tot && test(r.strike))
      .map((r) => ({ strike: r.strike, side, add: r[side].tot[2] - r[side].tot[3], recent: r[side].recent ? r[side].recent[2] : 0 }))
      .filter((m) => m.add > 0)
      .sort((a, b) => b.add - a.add)[0];
    const up = mag('ce', (k) => k > spot);
    const dn = mag('pe', (k) => k < spot);
    if (up) res.magnets.push(Object.assign(up, { pull: 'up' }));
    if (dn) res.magnets.push(Object.assign(dn, { pull: 'down' }));
    return res;
  }

  const api = { DEFAULTS, SETUP_NAMES, patterns, signals, wallsAndMagnets, atrSeries, openingRanges, prevDayMap };
  if (typeof window !== 'undefined') window.EVSignals = api;
  if (typeof module !== 'undefined') module.exports = api;
})();
